(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "XMLNode", null, null, 'org.opensourcephysics.controls.XMLProperty');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.type=6;
this.className="java.lang.Object";
},1);

C$.$fields$=[['I',['type'],'S',['name','className'],'O',['parent','org.opensourcephysics.controls.XMLProperty']]]

Clazz.newMeth(C$, 'getParentProperty$',  function () {
return this.parent;
});

Clazz.newMeth(C$, 'getPropertyType$',  function () {
return this.type;
});

Clazz.newMeth(C$, 'setValue$S',  function (stringValue) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:02 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
