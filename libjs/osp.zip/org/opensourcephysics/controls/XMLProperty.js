(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "XMLProperty");

C$.$fields$=[[]
,['O',['types','String[]']]]

Clazz.newMeth(C$, 'getTypeName$I',  function (type) {
return (type == -1 ? "object" : C$.types[type]);
}, 1);

Clazz.newMeth(C$, 'getTypeCode$S',  function (type) {
switch (type) {
case "int":
return 0;
case "double":
return 1;
case "boolean":
return 2;
case "string":
return 3;
case "array":
return 4;
case "collection":
return 5;
case "object":
return 6;
default:
return -1;
}
}, 1);

Clazz.newMeth(C$, 'getDataType$O',  function (obj) {
if (obj == null ) {
return -1;
}if (Clazz.instanceOf(obj, "java.lang.String")) {
return 3;
} else if (Clazz.instanceOf(obj, "java.util.Collection")) {
return 5;
} else if (obj.getClass$().isArray$()) {
var componentType=obj.getClass$().getComponentType$();
while (componentType.isArray$()){
componentType=componentType.getComponentType$();
}
var type=componentType.getName$();
if ((type.indexOf$S(".") == -1) && ("intdoubleboolean".indexOf$S(type) == -1) ) {
return -1;
}return 4;
} else if (Clazz.instanceOf(obj, "java.lang.Double")) {
return 1;
} else if (Clazz.instanceOf(obj, "java.lang.Integer")) {
return 0;
} else {
return 6;
}}, 1);

C$.$static$=function(){C$.$static$=0;
C$.types=Clazz.array(String, -1, ["int", "double", "boolean", "string", "array", "collection", "object"]);
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:02 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
