(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),p$1={},I$=[[0,'java.awt.Cursor','java.awt.Color','java.awt.Rectangle','org.opensourcephysics.display.DisplayRes','org.opensourcephysics.display.dialogs.ScaleInspector','org.opensourcephysics.tools.FontSizer','org.opensourcephysics.display.OSPRuntime','java.awt.KeyboardFocusManager','org.opensourcephysics.display.DrawingPanel','java.util.Collection','javax.swing.JPopupMenu','java.awt.geom.AffineTransform','java.util.ArrayList','java.awt.image.BufferedImage','org.opensourcephysics.display.MessageDrawable','org.opensourcephysics.display.TextPanel','org.opensourcephysics.numerics.Util',['org.opensourcephysics.display.DrawingPanel','.CMController'],['org.opensourcephysics.display.DrawingPanel','.OptionController'],['org.opensourcephysics.display.DrawingPanel','.ZoomBox'],'org.opensourcephysics.display.axes.CoordinateStringBuilder',['org.opensourcephysics.display.DrawingPanel','.GlassPanel'],'org.opensourcephysics.display.OSPLayout','javax.swing.Timer','java.awt.BorderLayout','org.opensourcephysics.js.JSUtil','java.awt.Dimension','java.awt.event.ComponentAdapter','java.text.NumberFormat','org.opensourcephysics.tools.ToolsRes',['org.opensourcephysics.display.DrawingPanel','.PopupmenuListener'],'javax.swing.JMenuItem','javax.swing.SwingUtilities','org.opensourcephysics.controls.OSPLog','java.awt.RenderingHints','org.opensourcephysics.display.MeasuredImage','org.opensourcephysics.display.dialogs.XMLDrawingPanelInspector','org.opensourcephysics.display.dialogs.DrawingPanelInspector',['java.awt.geom.Rectangle2D','.Double'],['org.opensourcephysics.display.DrawingPanel','.DrawingPanelLoader']]],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DrawingPanel", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.JPanel', ['java.awt.event.ActionListener', 'org.opensourcephysics.display.Renderable']);
C$.$classes$=[['CMController',2],['ZoomBox',1],['PopupmenuListener',0],['OptionController',0],['GlassPanel',0],['DrawingPanelLoader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.popupmenu=Clazz.new_($I$(11,1));
this.leftGutter=0;
this.topGutter=0;
this.rightGutter=0;
this.bottomGutter=0;
this.leftGutterPreferred=0;
this.topGutterPreferred=0;
this.rightGutterPreferred=0;
this.bottomGutterPreferred=0;
this.clipAtGutter=true;
this.adjustableGutter=false;
this.bgColor=Clazz.new_($I$(2,1).c$$I$I$I,[239, 239, 255]);
this.antialiasTextOn=false;
this.antialiasShapeOn=false;
this.squareAspect=false;
this.autoscaleX=true;
this.autoscaleY=true;
this.autoscaleXMin=true;
this.autoscaleXMax=true;
this.autoscaleYMin=true;
this.autoscaleYMax=true;
this.autoscaleMargin=0.0;
this.xminPreferred=-10.0;
this.xmaxPreferred=10.0;
this.yminPreferred=-10.0;
this.ymaxPreferred=10.0;
this.xfloor=NaN;
this.xceil=NaN;
this.yfloor=NaN;
this.yceil=NaN;
this.xmin=this.xminPreferred;
this.xmax=this.xmaxPreferred;
this.ymin=this.yminPreferred;
this.ymax=this.xmaxPreferred;
this.fixedPixelPerUnit=false;
this.xPixPerUnit=1;
this.yPixPerUnit=1;
this.pixelTransform=Clazz.new_($I$(12,1));
this.pixelMatrix=Clazz.array(Double.TYPE, [6]);
this.drawableList=Clazz.new_($I$(13,1));
this.validImage=false;
this.offscreenImage=Clazz.new_($I$(14,1).c$$I$I$I,[1, 1, 1]);
this.workingImage=this.offscreenImage;
this.buffered=false;
this.messages=Clazz.new_($I$(15,1));
this.trMessageBox=Clazz.new_($I$(16,1));
this.tlMessageBox=Clazz.new_($I$(16,1));
this.brMessageBox=Clazz.new_($I$(16,1));
this.blMessageBox=Clazz.new_($I$(16,1));
this.scientificFormat=$I$(17).newDecimalFormat$S("0.###E0");
this.decimalFormat=$I$(17).newDecimalFormat$S("0.00");
this.mouseController=Clazz.new_($I$(18,1),[this, null]);
this.showCoordinates=false;
this.optionController=Clazz.new_($I$(19,1),[this, null]);
this.zoomBox=Clazz.new_($I$(20,1),[this, null]);
this.enableZoom=true;
this.fixedScale=false;
this.dimensionSetter=null;
this.viewRect=null;
this.coordinateStrBuilder=$I$(21).createCartesian$();
this.glassPanel=Clazz.new_($I$(22,1),[this, null]);
this.glassPanelLayout=Clazz.new_($I$(23,1));
this.refreshDelay=100;
this.refreshTimer=Clazz.new_($I$(24,1).c$$I$java_awt_event_ActionListener,[this.refreshDelay, this]);
this.imageRatio=1.0;
this.xLeftMarginPercentage=0.0;
this.xRightMarginPercentage=0.0;
this.yTopMarginPercentage=0.0;
this.yBottomMarginPercentage=0.0;
this.logScaleX=false;
this.logScaleY=false;
this.zoomDelay=40;
this.runImageCheck=((P$.DrawingPanel$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "DrawingPanel$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]]

Clazz.newMeth(C$, 'run$', function () {
p$1.workingImage.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], []);
});
})()
), Clazz.new_(P$.DrawingPanel$1.$init$,[this, null]));
this.visibleRect=Clazz.new_($I$(3,1));
this.doNow=((P$.DrawingPanel$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "DrawingPanel$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]]

Clazz.newMeth(C$, 'run$', function () {
this.b$['javax.swing.JComponent'].computeVisibleRect$java_awt_Rectangle.apply(this.b$['javax.swing.JComponent'], [this.b$['org.opensourcephysics.display.DrawingPanel'].visibleRect]);
this.b$['javax.swing.JComponent'].paintImmediately$java_awt_Rectangle.apply(this.b$['javax.swing.JComponent'], [this.b$['org.opensourcephysics.display.DrawingPanel'].visibleRect]);
});
})()
), Clazz.new_(P$.DrawingPanel$2.$init$,[this, null]));
this.trDP=Clazz.new_($I$(12,1));
},1);

C$.$fields$=[['Z',['clipAtGutter','adjustableGutter','antialiasTextOn','antialiasShapeOn','squareAspect','autoscaleX','autoscaleY','autoscaleXMin','autoscaleXMax','autoscaleYMin','autoscaleYMax','fixedPixelPerUnit','validImage','buffered','showCoordinates','enableZoom','fixedScale','logScaleX','logScaleY'],'D',['autoscaleMargin','xminPreferred','xmaxPreferred','yminPreferred','ymaxPreferred','xfloor','xceil','yfloor','yceil','xmin','xmax','ymin','ymax','xPixPerUnit','yPixPerUnit','imageRatio','xLeftMarginPercentage','xRightMarginPercentage','yTopMarginPercentage','yBottomMarginPercentage','dxmin','dxmax','dymin','dymax'],'I',['leftGutter','topGutter','rightGutter','bottomGutter','leftGutterPreferred','topGutterPreferred','rightGutterPreferred','bottomGutterPreferred','$width','$height','refreshDelay','zoomDelay','zoomCount'],'J',['currentTime'],'O',['popupmenu','javax.swing.JPopupMenu','propertiesItem','javax.swing.JMenuItem','+autoscaleItem','+scaleItem','+zoomInItem','+zoomOutItem','+snapshotItem','bgColor','java.awt.Color','pixelTransform','java.awt.geom.AffineTransform','pixelMatrix','double[]','drawableList','java.util.ArrayList','offscreenImage','java.awt.image.BufferedImage','+workingImage','messages','org.opensourcephysics.display.MessageDrawable','trMessageBox','org.opensourcephysics.display.TextPanel','+tlMessageBox','+brMessageBox','+blMessageBox','scientificFormat','java.text.DecimalFormat','+decimalFormat','mouseController','javax.swing.event.MouseInputAdapter','+optionController','zoomBox','org.opensourcephysics.display.DrawingPanel.ZoomBox','customInspector','java.awt.Window','dimensionSetter','org.opensourcephysics.display.Dimensioned','viewRect','java.awt.Rectangle','coordinateStrBuilder','org.opensourcephysics.display.axes.CoordinateStringBuilder','glassPanel','org.opensourcephysics.display.DrawingPanel.GlassPanel','glassPanelLayout','org.opensourcephysics.display.OSPLayout','refreshTimer','javax.swing.Timer','vidCap','org.opensourcephysics.tools.VideoTool','zoomTimer','javax.swing.Timer','guiChangeListener','java.beans.PropertyChangeListener','runImageCheck','Runnable','visibleRect','java.awt.Rectangle','doNow','Runnable','trDP','java.awt.geom.AffineTransform']]
,['Z',['RECORD_PAINT_TIMES']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.glassPanel.setLayout$java_awt_LayoutManager(this.glassPanelLayout);
C$.superclazz.prototype.setLayout$java_awt_LayoutManager.apply(this, [Clazz.new_($I$(25,1))]);
this.glassPanel.add$java_awt_Component$O(this.trMessageBox, "TopRightCorner");
this.glassPanel.add$java_awt_Component$O(this.tlMessageBox, "TopLeftCorner");
this.glassPanel.add$java_awt_Component$O(this.brMessageBox, "BottomRightCorner");
this.glassPanel.add$java_awt_Component$O(this.blMessageBox, "BottomLeftCorner");
this.glassPanel.setOpaque$Z(false);
if (!$I$(26).isJS) C$.superclazz.prototype.add$java_awt_Component$O.apply(this, [this.glassPanel, "Center"]);
this.setBackground$java_awt_Color(this.bgColor);
this.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(27,1).c$$I$I,[300, 300]));
this.showCoordinates=true;
this.addMouseListener$java_awt_event_MouseListener(this.mouseController);
this.addMouseMotionListener$java_awt_event_MouseMotionListener(this.mouseController);
this.addOptionController$();
this.addComponentListener$java_awt_event_ComponentListener(((P$.DrawingPanel$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "DrawingPanel$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.ComponentAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'componentResized$java_awt_event_ComponentEvent', function (e) {
this.b$['org.opensourcephysics.display.DrawingPanel'].invalidateImage$.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], []);
});
})()
), Clazz.new_($I$(28,1),[this, null],P$.DrawingPanel$3)));
this.buildPopupmenu$();
this.refreshTimer.setRepeats$Z(false);
this.refreshTimer.setCoalesce$Z(true);
this.setFontLevel$I($I$(6).getLevel$());
this.zoomTimer=Clazz.new_([this.zoomDelay, ((P$.DrawingPanel$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "DrawingPanel$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.display.DrawingPanel'].zoomBox.xlast=this.b$['org.opensourcephysics.display.DrawingPanel'].zoomBox.xstop=this.b$['org.opensourcephysics.display.DrawingPanel'].zoomBox.xstart=0;
this.b$['org.opensourcephysics.display.DrawingPanel'].zoomBox.ylast=this.b$['org.opensourcephysics.display.DrawingPanel'].zoomBox.ystop=this.b$['org.opensourcephysics.display.DrawingPanel'].zoomBox.ystart=0;
this.b$['org.opensourcephysics.display.DrawingPanel'].zoomBox.visible=this.b$['org.opensourcephysics.display.DrawingPanel'].zoomBox.dragged=false;
var steps=4;
if (this.b$['org.opensourcephysics.display.DrawingPanel'].zoomCount < steps) {
this.b$['org.opensourcephysics.display.DrawingPanel'].zoomCount++;
var xmin=this.b$['org.opensourcephysics.display.DrawingPanel'].getXMin$.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], []) + this.b$['org.opensourcephysics.display.DrawingPanel'].dxmin / steps;
var xmax=this.b$['org.opensourcephysics.display.DrawingPanel'].getXMax$.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], []) + this.b$['org.opensourcephysics.display.DrawingPanel'].dxmax / steps;
var ymin=this.b$['org.opensourcephysics.display.DrawingPanel'].getYMin$.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], []) + this.b$['org.opensourcephysics.display.DrawingPanel'].dymin / steps;
var ymax=this.b$['org.opensourcephysics.display.DrawingPanel'].getYMax$.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], []) + this.b$['org.opensourcephysics.display.DrawingPanel'].dymax / steps;
this.b$['org.opensourcephysics.display.DrawingPanel'].setPreferredMinMax$D$D$D$D.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], [xmin, xmax, ymin, ymax]);
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
} else {
this.b$['org.opensourcephysics.display.DrawingPanel'].zoomTimer.stop$();
this.b$['org.opensourcephysics.display.DrawingPanel'].invalidateImage$.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], []);
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
}});
})()
), Clazz.new_(P$.DrawingPanel$4.$init$,[this, null]))],$I$(24,1).c$$I$java_awt_event_ActionListener);
this.zoomTimer.setInitialDelay$I(0);
this.guiChangeListener=((P$.DrawingPanel$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "DrawingPanel$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.beans.PropertyChangeListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
if (e.getPropertyName$().equals$O("level")) {
var level=(e.getNewValue$()).intValue$();
this.b$['org.opensourcephysics.display.DrawingPanel'].setFontLevel$I.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], [level]);
} else if (e.getPropertyName$().equals$O("locale")) {
var locale=e.getNewValue$();
var format=$I$(29).getInstance$java_util_Locale(locale);
$I$(7,"setDefaultDecimalSeparator$C",[format.getDecimalFormatSymbols$().getDecimalSeparator$()]);
this.b$['org.opensourcephysics.display.DrawingPanel'].refreshDecimalSeparators$.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], []);
this.b$['org.opensourcephysics.display.DrawingPanel'].refreshGUI$.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], []);
}});
})()
), Clazz.new_(P$.DrawingPanel$5.$init$,[this, null]));
$I$(6).addPropertyChangeListener$S$java_beans_PropertyChangeListener("level", this.guiChangeListener);
$I$(30).addPropertyChangeListener$S$java_beans_PropertyChangeListener("locale", this.guiChangeListener);
}, 1);

Clazz.newMeth(C$, 'refreshGUI$', function () {
this.zoomInItem.setText$S($I$(4).getString$S("DisplayPanel.Zoom_in_menu_item"));
this.zoomOutItem.setText$S($I$(4).getString$S("DisplayPanel.Zoom_out_menu_item"));
this.scaleItem.setText$S($I$(4).getString$S("DrawingFrame.Scale_menu_item"));
this.autoscaleItem.setText$S($I$(4).getString$S("DrawingFrame.Autoscale_menu_item"));
this.snapshotItem.setText$S($I$(4).getString$S("DisplayPanel.Snapshot_menu_item"));
this.propertiesItem.setText$S($I$(4).getString$S("DrawingFrame.InspectMenuItem"));
});

Clazz.newMeth(C$, 'refreshDecimalSeparators$', function () {
this.scientificFormat.setDecimalFormatSymbols$java_text_DecimalFormatSymbols($I$(7).getDecimalFormatSymbols$());
this.decimalFormat.setDecimalFormatSymbols$java_text_DecimalFormatSymbols($I$(7).getDecimalFormatSymbols$());
});

Clazz.newMeth(C$, 'setFontLevel$I', function (level) {
var font=$I$(6).getResizedFont$java_awt_Font$I(this.trMessageBox.$font, level);
this.trMessageBox.$font=font;
this.tlMessageBox.$font=font;
this.brMessageBox.$font=font;
this.blMessageBox.$font=font;
this.invalidateImage$();
this.repaint$();
});

Clazz.newMeth(C$, 'setFontFactor$D', function (factor) {
var font=$I$(6).getResizedFont$java_awt_Font$D(this.trMessageBox.$font, factor);
this.trMessageBox.$font=font;
this.tlMessageBox.$font=font;
this.brMessageBox.$font=font;
this.blMessageBox.$font=font;
this.invalidateImage$();
this.repaint$();
});

Clazz.newMeth(C$, 'buildPopupmenu$', function () {
this.popupmenu.removeAll$();
this.popupmenu.setEnabled$Z(true);
var listener=Clazz.new_($I$(31,1),[this, null]);
if (this.isZoom$()) {
this.zoomInItem=Clazz.new_([$I$(4).getString$S("DisplayPanel.Zoom_in_menu_item")],$I$(32,1).c$$S);
this.zoomInItem.addActionListener$java_awt_event_ActionListener(listener);
this.popupmenu.add$javax_swing_JMenuItem(this.zoomInItem);
this.zoomOutItem=Clazz.new_([$I$(4).getString$S("DisplayPanel.Zoom_out_menu_item")],$I$(32,1).c$$S);
this.zoomOutItem.addActionListener$java_awt_event_ActionListener(listener);
this.popupmenu.add$javax_swing_JMenuItem(this.zoomOutItem);
}if (!this.isFixedScale$()) {
this.autoscaleItem=Clazz.new_([$I$(4).getString$S("DrawingFrame.Autoscale_menu_item")],$I$(32,1).c$$S);
this.autoscaleItem.addActionListener$java_awt_event_ActionListener(listener);
this.popupmenu.add$javax_swing_JMenuItem(this.autoscaleItem);
this.scaleItem=Clazz.new_([$I$(4).getString$S("DrawingFrame.Scale_menu_item")],$I$(32,1).c$$S);
this.scaleItem.addActionListener$java_awt_event_ActionListener(listener);
this.popupmenu.add$javax_swing_JMenuItem(this.scaleItem);
this.popupmenu.addSeparator$();
}this.snapshotItem=Clazz.new_([$I$(4).getString$S("DisplayPanel.Snapshot_menu_item")],$I$(32,1).c$$S);
this.snapshotItem.addActionListener$java_awt_event_ActionListener(listener);
this.popupmenu.add$javax_swing_JMenuItem(this.snapshotItem);
this.popupmenu.addSeparator$();
this.propertiesItem=Clazz.new_([$I$(4).getString$S("DrawingFrame.InspectMenuItem")],$I$(32,1).c$$S);
this.propertiesItem.addActionListener$java_awt_event_ActionListener(listener);
this.popupmenu.add$javax_swing_JMenuItem(this.propertiesItem);
});

Clazz.newMeth(C$, 'setAutoscaleMargin$D', function (_autoscaleMargin) {
if (this.autoscaleMargin == _autoscaleMargin ) {
return;
}this.autoscaleMargin=_autoscaleMargin;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setXMarginPercentage$D', function (_percentage) {
if ((this.xLeftMarginPercentage == _percentage ) && (this.xRightMarginPercentage == _percentage ) ) {
return;
}this.xLeftMarginPercentage=this.xRightMarginPercentage=_percentage;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setXMarginPercentage$D$D', function (_leftPercentage, _rightPercentage) {
if ((this.xLeftMarginPercentage == _leftPercentage ) && (this.xRightMarginPercentage == _rightPercentage ) ) {
return;
}this.xLeftMarginPercentage=_leftPercentage;
this.xRightMarginPercentage=_rightPercentage;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setXLeftMarginPercentage$D', function (_percentage) {
if (this.xLeftMarginPercentage == _percentage ) {
return;
}this.xLeftMarginPercentage=_percentage;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setXRightMarginPercentage$D', function (_percentage) {
if (this.xRightMarginPercentage == _percentage ) {
return;
}this.xRightMarginPercentage=_percentage;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setYMarginPercentage$D', function (_percentage) {
if ((this.yTopMarginPercentage == _percentage ) && (this.yBottomMarginPercentage == _percentage ) ) {
return;
}this.yTopMarginPercentage=this.yBottomMarginPercentage=_percentage;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setYMarginPercentage$D$D', function (_bottomPercentage, _topPercentage) {
if ((this.yBottomMarginPercentage == _bottomPercentage ) && (this.yTopMarginPercentage == _topPercentage ) ) {
return;
}this.yTopMarginPercentage=_topPercentage;
this.yBottomMarginPercentage=_bottomPercentage;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setYTopMarginPercentage$D', function (_percentage) {
if (this.yTopMarginPercentage == _percentage ) {
return;
}this.yTopMarginPercentage=_percentage;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setYBottomMarginPercentage$D', function (_percentage) {
if (this.yBottomMarginPercentage == _percentage ) {
return;
}this.yBottomMarginPercentage=_percentage;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setClipAtGutter$Z', function (clip) {
if (this.clipAtGutter == clip ) {
return;
}this.clipAtGutter=clip;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'isClipAtGutter$', function () {
return this.clipAtGutter;
});

Clazz.newMeth(C$, 'setAdjustableGutter$Z', function (adjustable) {
if (this.adjustableGutter == adjustable ) {
return;
}this.adjustableGutter=adjustable;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'isAdjustableGutter$', function () {
return this.adjustableGutter;
});

Clazz.newMeth(C$, 'setMouseCursor$java_awt_Cursor', function (cursor) {
var c=this.getTopLevelAncestor$();
this.setCursor$java_awt_Cursor(cursor);
if (c != null ) {
c.setCursor$java_awt_Cursor(cursor);
}});

Clazz.newMeth(C$, 'checkWorkingImage$', function () {
if ($I$(33).isEventDispatchThread$()) {
return p$1.workingImage.apply(this, []);
}try {
$I$(33).invokeAndWait$Runnable(this.runImageCheck);
return true;
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
$I$(34,"finest$S",["Exception in Check Working Image:" + ex.toString()]);
return false;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'workingImage', function () {
var r=this.getBounds$();
var width=(r.getWidth$()|0);
var height=(r.getHeight$()|0);
if ((width <= 2) || (height <= 2) ) {
return false;
}if ((this.workingImage == null ) || (width != this.workingImage.getWidth$()) || (height != this.workingImage.getHeight$())  ) {
this.workingImage=this.getGraphicsConfiguration$().createCompatibleImage$I$I(width, height);
this.invalidateImage$();
}if (this.workingImage == null ) {
this.invalidateImage$();
return false;
}return true;
}, p$1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (evt) {
if (!this.isValidImage$()) {
this.render$();
}});

Clazz.newMeth(C$, 'isIconified$', function () {
var c=this.getTopLevelAncestor$();
if (Clazz.instanceOf(c, "java.awt.Frame")) {
return ((c).getExtendedState$() & 1) == 1;
}return false;
});

Clazz.newMeth(C$, 'render$', function () {
if (!this.isShowing$() || this.isIconified$() ) {
return this.offscreenImage;
}if (this.buffered && this.checkWorkingImage$() ) {
this.validImage=true;
this.render$java_awt_image_BufferedImage(this.workingImage);
var temp=this.offscreenImage;
this.offscreenImage=this.workingImage;
this.workingImage=temp;
}try {
if ($I$(33).isEventDispatchThread$()) {
this.doNow.run$();
} else {
$I$(33).invokeAndWait$Runnable(this.doNow);
}} catch (e$$) {
if (Clazz.exceptionOf(e$$,"java.lang.reflect.InvocationTargetException")){
var ex1 = e$$;
{
}
} else if (Clazz.exceptionOf(e$$,"InterruptedException")){
var ex1 = e$$;
{
}
} else {
throw e$$;
}
}
if (this.vidCap != null ) {
if (this.buffered) {
this.vidCap.addFrame$java_awt_image_BufferedImage(this.offscreenImage);
} else {
if (this.vidCap.isRecording$()) {
this.vidCap.addFrame$java_awt_image_BufferedImage(this.render$());
}}}return this.offscreenImage;
});

Clazz.newMeth(C$, 'render$java_awt_image_BufferedImage', function (image) {
var osg=image.getGraphics$();
this.imageRatio=(this.getWidth$() <= 0 ) ? 1 : image.getWidth$() / this.getWidth$();
if (osg != null ) {
this.paintEverything$java_awt_Graphics(osg);
if (image === this.workingImage ) {
this.zoomBox.paint$java_awt_Graphics(osg);
}if (!$I$(26).isJS) {
var viewRect=this.viewRect;
if (viewRect != null ) {
var r=Clazz.new_([0, 0, image.getWidth$java_awt_image_ImageObserver(null), image.getHeight$java_awt_image_ImageObserver(null)],$I$(3,1).c$$I$I$I$I);
this.glassPanel.setBounds$java_awt_Rectangle(r);
this.glassPanelLayout.checkLayoutRect$java_awt_Container$java_awt_Rectangle(this.glassPanel, r);
this.glassPanel.render$java_awt_Graphics(osg);
this.glassPanel.setBounds$java_awt_Rectangle(viewRect);
this.glassPanelLayout.checkLayoutRect$java_awt_Container$java_awt_Rectangle(this.glassPanel, viewRect);
} else {
this.glassPanel.render$java_awt_Graphics(osg);
}}osg.dispose$();
}this.imageRatio=1.0;
return image;
});

Clazz.newMeth(C$, 'getWidth$', function () {
return ((this.imageRatio * C$.superclazz.prototype.getWidth$.apply(this, []))|0);
});

Clazz.newMeth(C$, 'getHeight$', function () {
return ((this.imageRatio * C$.superclazz.prototype.getHeight$.apply(this, []))|0);
});

Clazz.newMeth(C$, 'getImageRatio$', function () {
return this.imageRatio;
});

Clazz.newMeth(C$, 'invalidateImage$', function () {
this.validImage=false;
});

Clazz.newMeth(C$, 'validateImage$', function () {
this.validImage=true;
});

Clazz.newMeth(C$, 'isValidImage$', function () {
return this.validImage;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
var resetBuffered=this.buffered;
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
this.paintEverything$java_awt_Graphics(g);
this.buffered=resetBuffered;
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
if ($I$(7).disableAllDrawing) {
g.setColor$java_awt_Color(this.bgColor);
g.setColor$java_awt_Color($I$(2).RED);
g.fillRect$I$I$I$I(0, 0, this.getWidth$(), this.getHeight$());
return;
}this.viewRect=this.findViewRect$();
if (this.buffered) {
if (!this.validImage || (this.getWidth$() != this.offscreenImage.getWidth$()) || (this.getHeight$() != this.offscreenImage.getHeight$())  ) {
if ((this.getWidth$() != this.offscreenImage.getWidth$()) || (this.getHeight$() != this.offscreenImage.getHeight$()) ) {
g.setColor$java_awt_Color($I$(2).WHITE);
g.setColor$java_awt_Color($I$(2).CYAN);
g.fillRect$I$I$I$I(0, 0, this.getWidth$(), this.getHeight$());
} else {
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.offscreenImage, 0, 0, null);
}this.refreshTimer.start$();
} else {
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.offscreenImage, 0, 0, null);
}} else {
this.validImage=true;
this.paintEverything$java_awt_Graphics(g);
}this.zoomBox.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'getViewRect$', function () {
return this.viewRect;
});

Clazz.newMeth(C$, 'findViewRect$', function () {
var rect=null;
var c=this.getParent$();
while (c != null ){
if (Clazz.instanceOf(c, "javax.swing.JViewport")) {
rect=(c).getViewRect$();
this.glassPanel.setBounds$java_awt_Rectangle(rect);
this.glassPanelLayout.checkLayoutRect$java_awt_Container$java_awt_Rectangle(this.glassPanel, rect);
break;
}c=c.getParent$();
}
return rect;
});

Clazz.newMeth(C$, 'computeGutters$', function () {
if (this.dimensionSetter != null ) {
var interiorDimension=this.dimensionSetter.getInterior$org_opensourcephysics_display_DrawingPanel(this);
if (interiorDimension != null ) {
this.squareAspect=false;
this.leftGutter=this.rightGutter=(Math.max(0, this.getWidth$() - interiorDimension.width)/2|0);
this.topGutter=this.bottomGutter=(Math.max(0, this.getHeight$() - interiorDimension.height)/2|0);
}}});

Clazz.newMeth(C$, 'paintFirst$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color(this.getBackground$());
g.fillRect$I$I$I$I(0, 0, this.getWidth$(), this.getHeight$());
g.setColor$java_awt_Color($I$(2).black);
});

Clazz.newMeth(C$, 'paintLast$java_awt_Graphics', function (g) {
});

Clazz.newMeth(C$, 'paintEverything$java_awt_Graphics', function (g) {
C$.RECORD_PAINT_TIMES=false;
if (C$.RECORD_PAINT_TIMES) {
var time=System.currentTimeMillis$();
System.out.println$S("DrawingPanel elapsed time(s)=" + (new Double(((time - this.currentTime)|0) / 1000.0).toString()));
this.currentTime=time;
}this.computeGutters$();
var tempList=this.getDrawables$();
this.scale$java_util_ArrayList(tempList);
this.setPixelScale$();
if (!$I$(26).isJS && $I$(7).setRenderingHints ) {
if (this.antialiasTextOn) {
(g).setRenderingHint$java_awt_RenderingHints_Key$O($I$(35).KEY_TEXT_ANTIALIASING, $I$(35).VALUE_TEXT_ANTIALIAS_ON);
} else {
(g).setRenderingHint$java_awt_RenderingHints_Key$O($I$(35).KEY_TEXT_ANTIALIASING, $I$(35).VALUE_TEXT_ANTIALIAS_OFF);
}if (this.antialiasShapeOn) {
(g).setRenderingHint$java_awt_RenderingHints_Key$O($I$(35).KEY_ANTIALIASING, $I$(35).VALUE_ANTIALIAS_ON);
} else {
(g).setRenderingHint$java_awt_RenderingHints_Key$O($I$(35).KEY_ANTIALIASING, $I$(35).VALUE_ANTIALIAS_OFF);
}}if (!this.validImage) {
return;
}this.paintFirst$java_awt_Graphics(g);
if (!this.validImage) {
return;
}this.paintDrawableList$java_awt_Graphics$java_util_ArrayList(g, tempList);
if (!this.validImage) {
return;
}this.paintLast$java_awt_Graphics(g);
if (C$.RECORD_PAINT_TIMES) {
System.out.println$S("DrawingPanel paint time (ms)=" + ((System.currentTimeMillis$() - this.currentTime)|0) + '\n' );
}});

Clazz.newMeth(C$, 'setAutoscaleX$Z', function (autoscale) {
if ((this.autoscaleX == autoscale ) && (this.autoscaleXMax == autoscale ) && (this.autoscaleXMin == autoscale )  ) {
return;
}this.autoscaleX=this.autoscaleXMax=this.autoscaleXMin=autoscale;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'isAutoscaleX$', function () {
return this.autoscaleX;
});

Clazz.newMeth(C$, 'isAutoscaleXMax$', function () {
return this.autoscaleXMax;
});

Clazz.newMeth(C$, 'isAutoscaleXMin$', function () {
return this.autoscaleXMin;
});

Clazz.newMeth(C$, 'setAutoscaleY$Z', function (autoscale) {
if ((this.autoscaleY == autoscale ) && (this.autoscaleYMax == autoscale ) && (this.autoscaleYMin == autoscale )  ) {
return;
}this.autoscaleY=this.autoscaleYMax=this.autoscaleYMin=autoscale;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'isAutoscaleY$', function () {
return this.autoscaleY;
});

Clazz.newMeth(C$, 'isAutoscaleYMax$', function () {
return this.autoscaleYMax;
});

Clazz.newMeth(C$, 'isAutoscaleYMin$', function () {
return this.autoscaleYMin;
});

Clazz.newMeth(C$, 'isLogScaleX$', function () {
return this.logScaleX;
});

Clazz.newMeth(C$, 'isLogScaleY$', function () {
return this.logScaleY;
});

Clazz.newMeth(C$, 'setBounds$I$I$I$I', function (x, y, width, height) {
if ((this.getBounds$().x == x) && (this.getBounds$().y == y) && (this.getBounds$().width == width) && (this.getBounds$().height == height)  ) {
return;
}C$.superclazz.prototype.setBounds$I$I$I$I.apply(this, [x, y, width, height]);
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setBounds$java_awt_Rectangle', function (r) {
if (this.getBounds$().equals$O(r)) {
return;
}C$.superclazz.prototype.setBounds$java_awt_Rectangle.apply(this, [r]);
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setBuffered$Z', function (_buffered) {
if (this.buffered == _buffered ) {
return;
}this.buffered=_buffered;
if (this.buffered) {
this.setDoubleBuffered$Z(false);
} else {
this.workingImage=Clazz.new_($I$(14,1).c$$I$I$I,[1, 1, 1]);
this.offscreenImage=this.workingImage;
this.setDoubleBuffered$Z(true);
}this.invalidateImage$();
});

Clazz.newMeth(C$, 'isBuffered$', function () {
return this.buffered;
});

Clazz.newMeth(C$, 'setVisible$Z', function (vis) {
if (this.isVisible$() == vis ) {
return;
}C$.superclazz.prototype.setVisible$Z.apply(this, [vis]);
this.invalidateImage$();
});

Clazz.newMeth(C$, 'limitAutoscaleX$D$D', function (floor, ceil) {
if (ceil - floor < 1.4E-45 ) {
floor=0.9 * floor - 1.4E-45;
ceil=1.1 * ceil + 1.4E-45;
}this.xfloor=floor;
this.xceil=ceil;
});

Clazz.newMeth(C$, 'limitAutoscaleY$D$D', function (floor, ceil) {
if (ceil - floor < 1.4E-45 ) {
floor=0.9 * floor - 1.4E-45;
ceil=1.1 * ceil + 1.4E-45;
}this.yfloor=floor;
this.yceil=ceil;
});

Clazz.newMeth(C$, 'setPixelsPerUnit$Z$D$D', function (enable, xPixPerUnit, yPixPerUnit) {
if ((this.fixedPixelPerUnit == enable ) && (this.xPixPerUnit == xPixPerUnit ) && (this.yPixPerUnit == yPixPerUnit )  ) {
return;
}this.fixedPixelPerUnit=enable;
this.xPixPerUnit=xPixPerUnit;
this.yPixPerUnit=yPixPerUnit;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setPreferredMinMax$D$D$D$D$Z', function (xmin, xmax, ymin, ymax, invalidateImage) {
this.autoscaleX=this.autoscaleXMin=this.autoscaleXMax=false;
this.autoscaleY=this.autoscaleYMin=this.autoscaleYMax=false;
if ((this.xminPreferred == xmin ) && (this.xmaxPreferred == xmax ) && (this.yminPreferred == ymin ) && (this.ymaxPreferred == ymax )  ) {
return;
}if (Double.isNaN$D(xmin)) {
this.autoscaleXMin=true;
xmin=this.xminPreferred;
}if (Double.isNaN$D(xmax)) {
this.autoscaleXMax=true;
xmax=this.xmaxPreferred;
}this.autoscaleX=this.autoscaleXMin || this.autoscaleXMax ;
if (xmin == xmax ) {
xmin=0.9 * xmin - 0.5;
xmax=1.1 * xmax + 0.5;
}this.xminPreferred=xmin;
this.xmaxPreferred=xmax;
if (Double.isNaN$D(ymin)) {
this.autoscaleYMin=true;
ymin=this.yminPreferred;
}if (Double.isNaN$D(ymax)) {
this.autoscaleYMax=true;
ymax=this.ymaxPreferred;
}this.autoscaleY=this.autoscaleYMin || this.autoscaleYMax ;
if (ymin == ymax ) {
ymin=0.9 * ymin - 0.5;
ymax=1.1 * ymax + 0.5;
}this.yminPreferred=ymin;
this.ymaxPreferred=ymax;
if (invalidateImage) {
this.invalidateImage$();
}});

Clazz.newMeth(C$, 'setPreferredMinMax$D$D$D$D', function (xmin, xmax, ymin, ymax) {
this.setPreferredMinMax$D$D$D$D$Z(xmin, xmax, ymin, ymax, false);
});

Clazz.newMeth(C$, 'setPreferredMinMaxX$D$D', function (xmin, xmax) {
this.autoscaleX=this.autoscaleXMin=this.autoscaleXMax=false;
if ((this.xminPreferred == xmin ) && (this.xmaxPreferred == xmax ) ) {
return;
}if (Double.isNaN$D(xmin)) {
this.autoscaleXMin=true;
xmin=this.xminPreferred;
}if (Double.isNaN$D(xmax)) {
this.autoscaleXMax=true;
xmax=this.xmaxPreferred;
}this.autoscaleX=this.autoscaleXMin || this.autoscaleXMax ;
if (xmin == xmax ) {
xmin=0.9 * xmin - 0.5;
xmax=1.1 * xmax + 0.5;
}this.xminPreferred=xmin;
this.xmaxPreferred=xmax;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setPreferredMinMaxY$D$D', function (ymin, ymax) {
this.autoscaleY=this.autoscaleYMin=this.autoscaleYMax=false;
if ((this.yminPreferred == ymin ) && (this.ymaxPreferred == ymax ) ) {
return;
}if (Double.isNaN$D(ymin)) {
this.autoscaleYMin=true;
ymin=this.yminPreferred;
}if (Double.isNaN$D(ymax)) {
this.autoscaleYMax=true;
ymax=this.ymaxPreferred;
}this.autoscaleY=this.autoscaleYMin || this.autoscaleYMax ;
if (ymin == ymax ) {
ymin=0.9 * ymin - 0.5;
ymax=1.1 * ymax + 0.5;
}this.yminPreferred=ymin;
this.ymaxPreferred=ymax;
this.invalidateImage$();
});

Clazz.newMeth(C$, 'setSquareAspect$Z', function (val) {
if (this.squareAspect == val ) {
return;
}this.squareAspect=val;
this.invalidateImage$();
this.repaint$();
});

Clazz.newMeth(C$, 'isSquareAspect$', function () {
return this.squareAspect;
});

Clazz.newMeth(C$, 'setAntialiasTextOn$Z', function (on) {
this.antialiasTextOn=on;
});

Clazz.newMeth(C$, 'isAntialiasTextOn$', function () {
return this.antialiasTextOn;
});

Clazz.newMeth(C$, 'setAntialiasShapeOn$Z', function (on) {
this.antialiasShapeOn=on;
});

Clazz.newMeth(C$, 'isAntialiasShapeOn$', function () {
return this.antialiasShapeOn;
});

Clazz.newMeth(C$, 'isPointInside$D$D', function (x, y) {
if (this.xmin < this.xmax ) {
if (x < this.xmin ) {
return false;
}if (x > this.xmax ) {
return false;
}} else {
if (x > this.xmin ) {
return false;
}if (x < this.xmax ) {
return false;
}}if (this.ymin < this.ymax ) {
if (y < this.ymin ) {
return false;
}if (y > this.ymax ) {
return false;
}} else {
if (y > this.ymin ) {
return false;
}if (y < this.ymax ) {
return false;
}}return true;
});

Clazz.newMeth(C$, 'isFixedScale$', function () {
return this.fixedScale;
});

Clazz.newMeth(C$, 'setFixedScale$Z', function (fixed) {
if (this.fixedScale == fixed ) {
return;
}this.fixedScale=fixed;
this.buildPopupmenu$();
});

Clazz.newMeth(C$, 'isZoom$', function () {
return this.enableZoom && !this.isFixedScale$() ;
});

Clazz.newMeth(C$, 'setZoom$Z', function (_enableZoom) {
if (this.enableZoom == _enableZoom ) {
return;
}this.enableZoom=_enableZoom;
this.buildPopupmenu$();
});

Clazz.newMeth(C$, 'zoomOut$', function () {
var xPix=((this.zoomBox.xstart + this.zoomBox.xstop)/2|0);
var yPix=((this.zoomBox.ystart + this.zoomBox.ystop)/2|0);
var xCenter=this.pixToX$I(xPix);
var yCenter=this.pixToY$I(yPix);
var dx=Math.abs(this.xmax - this.xmin);
var dy=Math.abs(this.ymax - this.ymin);
this.dxmin=xCenter - dx - this.getXMin$() ;
this.dxmax=xCenter + dx - this.getXMax$();
this.dymin=yCenter - dy - this.getYMin$() ;
this.dymax=yCenter + dy - this.getYMax$();
this.zoomCount=0;
this.zoomTimer.start$();
});

Clazz.newMeth(C$, 'getZoomBox$', function () {
return this.zoomBox;
});

Clazz.newMeth(C$, 'zoomIn$', function () {
this.dxmin=this.pixToX$I(Math.min(this.zoomBox.xstart, this.zoomBox.xstop)) - this.getXMin$();
this.dxmax=this.pixToX$I(Math.max(this.zoomBox.xstart, this.zoomBox.xstop)) - this.getXMax$();
this.dymin=this.pixToY$I(Math.max(this.zoomBox.ystart, this.zoomBox.ystop)) - this.getYMin$();
this.dymax=this.pixToY$I(Math.min(this.zoomBox.ystart, this.zoomBox.ystop)) - this.getYMax$();
this.zoomCount=0;
this.zoomTimer.start$();
});

Clazz.newMeth(C$, 'snapshot$', function () {
var w=(this.isVisible$()) ? this.getWidth$() : this.getPreferredSize$().width;
var h=(this.isVisible$()) ? this.getHeight$() : this.getPreferredSize$().height;
if ((w == 0) || (h == 0) ) {
return;
}var image=Clazz.new_($I$(14,1).c$$I$I$I,[w, h, 2]);
this.render$java_awt_image_BufferedImage(image);
var mi=Clazz.new_([image, this.pixToX$I(0), this.pixToX$I(w), this.pixToY$I(h), this.pixToY$I(0)],$I$(36,1).c$$java_awt_image_BufferedImage$D$D$D$D);
var frame=null;
try {
var c=Clazz.forName("org.opensourcephysics.frames.ImageFrame");
var constructors=c.getConstructors$();
for (var i=0; i < constructors.length; i++) {
var parameters=constructors[i].getParameterTypes$();
if (parameters.length == 1 && parameters[0] === Clazz.getClass($I$(36))  ) {
frame=constructors[i].newInstance$OA(Clazz.array(java.lang.Object, -1, [mi]));
break;
}}
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
ex.printStackTrace$();
} else {
throw ex;
}
}
if (frame == null ) return;
frame.setTitle$S($I$(4).getString$S("Snapshot.Title"));
frame.setDefaultCloseOperation$I(2);
frame.setKeepHidden$Z(false);
$I$(6,"setFonts$O$I",[frame, $I$(6).getLevel$()]);
frame.pack$();
frame.setVisible$Z(true);
});

Clazz.newMeth(C$, 'hasInspector$', function () {
return (this.popupmenu != null ) && this.popupmenu.isEnabled$() ;
});

Clazz.newMeth(C$, 'enableInspector$Z', function (isEnabled) {
this.popupmenu.setEnabled$Z(isEnabled);
});

Clazz.newMeth(C$, 'getPopupMenu$', function () {
return this.popupmenu;
});

Clazz.newMeth(C$, 'setPopupMenu$javax_swing_JPopupMenu', function (menu) {
this.popupmenu=menu;
});

Clazz.newMeth(C$, 'showInspector$', function () {
if (this.customInspector == null ) {
$I$(37).getInspector$org_opensourcephysics_display_DrawingPanel(this);
} else {
this.customInspector.setVisible$Z(true);
}});

Clazz.newMeth(C$, 'hideInspector$', function () {
if (this.customInspector == null ) {
$I$(38).hideInspector$();
} else {
this.customInspector.setVisible$Z(false);
}});

Clazz.newMeth(C$, 'setCustomInspector$java_awt_Window', function (w) {
if (this.customInspector != null ) {
this.customInspector.setVisible$Z(false);
}this.customInspector=w;
});

Clazz.newMeth(C$, 'setVideoTool$org_opensourcephysics_tools_VideoTool', function (videoCap) {
if (this.vidCap != null ) {
this.vidCap.setVisible$Z(false);
}this.vidCap=videoCap;
if (this.vidCap != null ) {
this.setBuffered$Z(true);
}});

Clazz.newMeth(C$, 'getVideoTool$', function () {
return this.vidCap;
});

Clazz.newMeth(C$, 'getAspectRatio$', function () {
return (this.pixelMatrix[3] == 1 ) ? 1 : Math.abs(this.pixelMatrix[0] / this.pixelMatrix[3]);
});

Clazz.newMeth(C$, 'getXPixPerUnit$', function () {
return this.pixelMatrix[0];
});

Clazz.newMeth(C$, 'getYPixPerUnit$', function () {
return -this.pixelMatrix[3];
});

Clazz.newMeth(C$, 'getMaxPixPerUnit$', function () {
return Math.max(Math.abs(this.pixelMatrix[0]), Math.abs(this.pixelMatrix[3]));
});

Clazz.newMeth(C$, 'getXMin$', function () {
return this.xmin;
});

Clazz.newMeth(C$, 'getPreferredXMin$', function () {
return this.xminPreferred;
});

Clazz.newMeth(C$, 'getXMax$', function () {
return this.xmax;
});

Clazz.newMeth(C$, 'getPreferredXMax$', function () {
return this.xmaxPreferred;
});

Clazz.newMeth(C$, 'getYMax$', function () {
return this.ymax;
});

Clazz.newMeth(C$, 'getPreferredYMax$', function () {
return this.ymaxPreferred;
});

Clazz.newMeth(C$, 'getYMin$', function () {
return this.ymin;
});

Clazz.newMeth(C$, 'getPreferredYMin$', function () {
return this.yminPreferred;
});

Clazz.newMeth(C$, 'getCoordinateStringBuilder$', function () {
return this.coordinateStrBuilder;
});

Clazz.newMeth(C$, 'setCoordinateStringBuilder$org_opensourcephysics_display_axes_CoordinateStringBuilder', function (builder) {
this.coordinateStrBuilder=builder;
});

Clazz.newMeth(C$, 'getScale$', function () {
this.setPixelScale$();
return Clazz.new_($I$(39,1).c$$D$D$D$D,[this.xmin, this.ymin, this.xmax - this.xmin, this.ymax - this.ymin]);
});

Clazz.newMeth(C$, 'getMeasure$', function () {
var xmin=1.7976931348623157E308;
var xmax=-1.7976931348623157E308;
var ymin=1.7976931348623157E308;
var ymax=-1.7976931348623157E308;
var measurableFound=false;
var tempList=this.getDrawables$();
for (var i=0, n=tempList.size$(); i < n; i++) {
var obj=tempList.get$I(i);
if (!(Clazz.instanceOf(obj, "org.opensourcephysics.display.Measurable")) || !(obj).isMeasured$() ) {
continue;
}var measurable=obj;
var gxmax=measurable.getXMax$();
var gxmin=measurable.getXMin$();
if (this.logScaleX && (Clazz.instanceOf(measurable, "org.opensourcephysics.display.LogMeasurable")) ) {
gxmax=(measurable).getXMaxLogscale$();
gxmin=(measurable).getXMinLogscale$();
}var gymax=measurable.getYMax$();
var gymin=measurable.getYMin$();
if (this.logScaleY && (Clazz.instanceOf(measurable, "org.opensourcephysics.display.LogMeasurable")) ) {
gymax=(measurable).getYMaxLogscale$();
gymin=(measurable).getYMinLogscale$();
}if (!Double.isNaN$D(gxmax) && !Double.isNaN$D(gxmin) && !Double.isNaN$D(gymax) && !Double.isNaN$D(gymin)  ) {
xmin=Math.min(xmin, gxmin);
xmax=Math.max(xmax, gxmax);
ymin=Math.min(ymin, gymin);
ymax=Math.max(ymax, gymax);
measurableFound=true;
}}
if (measurableFound) {
return Clazz.new_($I$(39,1).c$$D$D$D$D,[xmin, ymin, xmax - xmin, ymax - ymin]);
}return Clazz.new_($I$(39,1).c$$D$D$D$D,[0, 0, 0, 0]);
});

Clazz.newMeth(C$, 'getPixelTransform$', function () {
return this.pixelTransform;
});

Clazz.newMeth(C$, 'getPixelTransform$java_awt_geom_AffineTransform', function (tr) {
tr.setTransform$java_awt_geom_AffineTransform(this.pixelTransform);
return tr;
});

Clazz.newMeth(C$, 'getPixelMatrix$', function () {
return this.pixelMatrix;
});

Clazz.newMeth(C$, 'setPixelScale$', function () {
this.xmin=this.xminPreferred;
this.xmax=this.xmaxPreferred;
this.ymin=this.yminPreferred;
this.ymax=this.ymaxPreferred;
this.leftGutter=this.leftGutterPreferred;
this.topGutter=this.topGutterPreferred;
this.rightGutter=this.rightGutterPreferred;
this.bottomGutter=this.bottomGutterPreferred;
this.$width=this.getWidth$();
this.$height=this.getHeight$();
if (this.fixedPixelPerUnit) {
this.xmin=(this.xmaxPreferred + this.xminPreferred) / 2 - Math.max(this.$width - this.leftGutter - this.rightGutter - 1 , 1) / this.xPixPerUnit / 2 ;
this.xmax=(this.xmaxPreferred + this.xminPreferred) / 2 + Math.max(this.$width - this.leftGutter - this.rightGutter - 1 , 1) / this.xPixPerUnit / 2 ;
this.ymin=(this.ymaxPreferred + this.yminPreferred) / 2 - Math.max(this.$height - this.bottomGutter - this.topGutter - 1 , 1) / this.yPixPerUnit / 2 ;
this.ymax=(this.ymaxPreferred + this.yminPreferred) / 2 + Math.max(this.$height - this.bottomGutter - this.topGutter - 1 , 1) / this.yPixPerUnit / 2 ;
this.pixelTransform.setTransform$D$D$D$D$D$D(this.xPixPerUnit, 0, 0, -this.yPixPerUnit, -this.xmin * this.xPixPerUnit + this.leftGutter, this.ymax * this.yPixPerUnit + this.topGutter);
this.pixelTransform.getMatrix$DA(this.pixelMatrix);
return;
}this.xPixPerUnit=Math.max(this.$width - this.leftGutter - this.rightGutter , 1) / (this.xmax - this.xmin);
this.yPixPerUnit=Math.max(this.$height - this.bottomGutter - this.topGutter , 1) / (this.ymax - this.ymin);
if (this.squareAspect) {
var stretch=Math.abs(this.xPixPerUnit / this.yPixPerUnit);
if (stretch >= 1 ) {
stretch=Math.min(stretch, this.$width);
this.xmin=this.xminPreferred - (this.xmaxPreferred - this.xminPreferred) * (stretch - 1) / 2.0;
this.xmax=this.xmaxPreferred + (this.xmaxPreferred - this.xminPreferred) * (stretch - 1) / 2.0;
this.xPixPerUnit=Math.max(this.$width - this.leftGutter - this.rightGutter , 1) / (this.xmax - this.xmin);
} else {
stretch=Math.max(stretch, 1.0 / this.$height);
this.ymin=this.yminPreferred - (this.ymaxPreferred - this.yminPreferred) * (1.0 / stretch - 1) / 2.0;
this.ymax=this.ymaxPreferred + (this.ymaxPreferred - this.yminPreferred) * (1.0 / stretch - 1) / 2.0;
this.yPixPerUnit=Math.max(this.$height - this.bottomGutter - this.topGutter , 1) / (this.ymax - this.ymin);
}}this.pixelTransform.setTransform$D$D$D$D$D$D(this.xPixPerUnit, 0, 0, -this.yPixPerUnit, -this.xmin * this.xPixPerUnit + this.leftGutter, this.ymax * this.yPixPerUnit + this.topGutter);
this.pixelTransform.getMatrix$DA(this.pixelMatrix);
});

Clazz.newMeth(C$, 'recomputeTransform$', function () {
this.xPixPerUnit=Math.max(this.$width - this.leftGutter - this.rightGutter , 1) / (this.xmax - this.xmin);
this.yPixPerUnit=Math.max(this.$height - this.bottomGutter - this.topGutter , 1) / (this.ymax - this.ymin);
this.pixelTransform.setTransform$D$D$D$D$D$D(this.xPixPerUnit, 0, 0, -this.yPixPerUnit, -this.xmin * this.xPixPerUnit + this.leftGutter, this.ymax * this.yPixPerUnit + this.topGutter);
this.pixelTransform.getMatrix$DA(this.pixelMatrix);
});

Clazz.newMeth(C$, 'project$DA$DA', function (coordinate, pixel) {
switch (coordinate.length) {
case 2:
case 3:
pixel[0]=this.xToGraphics$D(coordinate[0]);
pixel[1]=this.yToGraphics$D(coordinate[1]);
break;
case 4:
pixel[0]=this.xToGraphics$D(coordinate[0]);
pixel[1]=this.yToGraphics$D(coordinate[1]);
pixel[2]=this.xPixPerUnit * coordinate[2];
pixel[3]=this.yPixPerUnit * coordinate[3];
break;
case 6:
pixel[0]=this.xToGraphics$D(coordinate[0]);
pixel[1]=this.yToGraphics$D(coordinate[1]);
pixel[2]=this.xPixPerUnit * coordinate[3];
pixel[3]=this.yPixPerUnit * coordinate[4];
break;
default:
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Method project not supported for this length."]);
}
return pixel;
});

Clazz.newMeth(C$, 'pixToX$I', function (pix) {
return this.xmin + (pix - this.leftGutter) / this.xPixPerUnit;
});

Clazz.newMeth(C$, 'xToPix$D', function (x) {
var pix=this.pixelMatrix[0] * x + this.pixelMatrix[4];
if (pix > 2147483647 ) {
return 2147483647;
}if (pix < -2147483648 ) {
return -2147483648;
}return (Math.floor(pix)|0);
});

Clazz.newMeth(C$, 'xToGraphics$D', function (x) {
var pix=(this.pixelMatrix[0] * x + this.pixelMatrix[4]);
if (pix > 2147483647 ) {
return 2147483647;
}if (pix < -2147483648 ) {
return -2147483648;
}return pix;
});

Clazz.newMeth(C$, 'pixToY$I', function (pix) {
return this.ymax - (pix - this.topGutter) / this.yPixPerUnit;
});

Clazz.newMeth(C$, 'yToPix$D', function (y) {
var pix=this.pixelMatrix[3] * y + this.pixelMatrix[5];
if (pix > 2147483647 ) {
return 2147483647;
}if (pix < -2147483648 ) {
return -2147483648;
}return (Math.floor(pix)|0);
});

Clazz.newMeth(C$, 'yToGraphics$D', function (y) {
var pix=(this.pixelMatrix[3] * y + this.pixelMatrix[5]);
if (pix > 2147483647 ) {
return 2147483647;
}if (pix < -2147483648 ) {
return -2147483648;
}return pix;
});

Clazz.newMeth(C$, 'scale$', function () {
var tempList=this.getDrawables$();
this.scale$java_util_ArrayList(tempList);
});

Clazz.newMeth(C$, 'scale$java_util_ArrayList', function (tempList) {
if (this.autoscaleX) {
this.scaleX$java_util_ArrayList(tempList);
}if (this.autoscaleY) {
this.scaleY$java_util_ArrayList(tempList);
}});

Clazz.newMeth(C$, 'measure$', function () {
var tempList=this.getDrawables$();
this.scaleX$java_util_ArrayList(tempList);
this.scaleY$java_util_ArrayList(tempList);
this.setPixelScale$();
this.invalidateImage$();
});

Clazz.newMeth(C$, 'scaleX$', function () {
var tempList=this.getDrawables$();
this.scaleX$java_util_ArrayList(tempList);
});

Clazz.newMeth(C$, 'scaleX$java_util_ArrayList', function (tempList) {
var newXMin=1.7976931348623157E308;
var newXMax=-1.7976931348623157E308;
var measurableFound=false;
for (var i=0, n=tempList.size$(); i < n; i++) {
var obj=tempList.get$I(i);
if (!(Clazz.instanceOf(obj, "org.opensourcephysics.display.Measurable"))) {
continue;
}var measurable=obj;
if (!measurable.isMeasured$()) {
continue;
}var xmi=measurable.getXMin$();
var xma=measurable.getXMax$();
if (this.logScaleX && (Clazz.instanceOf(measurable, "org.opensourcephysics.display.LogMeasurable")) ) {
xmi=(measurable).getXMinLogscale$();
xma=(measurable).getXMaxLogscale$();
}if (!Double.isNaN$D(xmi) && !Double.isNaN$D(xma) ) {
newXMin=Math.min(newXMin, xmi);
newXMin=Math.min(newXMin, xma);
newXMax=Math.max(newXMax, xma);
newXMax=Math.max(newXMax, xmi);
measurableFound=true;
}}
if (measurableFound) {
if (this.logScaleX && ((this.xLeftMarginPercentage > 0.0 ) || (this.xRightMarginPercentage > 0.0 ) ) ) {
newXMax *= 1 + this.xRightMarginPercentage / 100.0;
newXMin /= 1 + this.xLeftMarginPercentage / 100.0;
} else if (!this.logScaleX && ((this.xLeftMarginPercentage > 0.0 ) || (this.xRightMarginPercentage > 0.0 ) ) ) {
var xMed=(newXMin + newXMax) / 2;
var xLen=(newXMax - newXMin) / 2;
newXMax=xMed + xLen * (1.0 + this.xRightMarginPercentage / 100.0);
newXMin=xMed - xLen * (1.0 + this.xLeftMarginPercentage / 100.0);
}if (newXMax - newXMin < 1.4E-45 ) {
if (Double.isNaN$D(this.xfloor)) {
newXMin=0.9 * newXMin - 0.5;
} else {
newXMin=Math.min(newXMin, this.xfloor);
}if (Double.isNaN$D(this.xceil)) {
newXMax=1.1 * newXMax + 0.5;
} else {
newXMax=Math.max(newXMax, this.xceil);
}}var range=Math.max(newXMax - newXMin, 1.4E-45);
while (Math.abs((newXMax + range) / range) > 100000.0 ){
range *= 2;
newXMin -= range;
newXMax += range;
}
if (this.autoscaleXMin) {
this.xminPreferred=newXMin - this.autoscaleMargin * range;
}if (this.autoscaleXMax) {
this.xmaxPreferred=newXMax + this.autoscaleMargin * range;
}} else {
if (!Double.isNaN$D(this.xfloor) && this.autoscaleXMin ) {
this.xminPreferred=this.xfloor;
}if (!Double.isNaN$D(this.xceil) && this.autoscaleXMax ) {
this.xmaxPreferred=this.xceil;
}}if (!Double.isNaN$D(this.xfloor)) {
this.xminPreferred=Math.min(this.xfloor, this.xminPreferred);
}if (!Double.isNaN$D(this.xceil)) {
this.xmaxPreferred=Math.max(this.xceil, this.xmaxPreferred);
}if (Math.abs(this.xmaxPreferred - this.xminPreferred) < 1.4E-45 ) {
this.xminPreferred=0.9 * this.xmaxPreferred - 1.4E-45;
this.xmaxPreferred=1.1 * this.xmaxPreferred + 1.4E-45;
}});

Clazz.newMeth(C$, 'scaleY$', function () {
var tempList=this.getDrawables$();
this.scaleY$java_util_ArrayList(tempList);
});

Clazz.newMeth(C$, 'scaleY$java_util_ArrayList', function (tempList) {
var newYMin=1.7976931348623157E308;
var newYMax=-1.7976931348623157E308;
var measurableFound=false;
for (var i=0, n=tempList.size$(); i < n; i++) {
var obj=tempList.get$I(i);
if (!(Clazz.instanceOf(obj, "org.opensourcephysics.display.Measurable"))) {
continue;
}var measurable=obj;
if (!measurable.isMeasured$()) {
continue;
}var ymi=measurable.getYMin$();
var yma=measurable.getYMax$();
if (this.logScaleY && (Clazz.instanceOf(measurable, "org.opensourcephysics.display.LogMeasurable")) ) {
yma=(measurable).getYMaxLogscale$();
ymi=(measurable).getYMinLogscale$();
}if (!Double.isNaN$D(ymi) && !Double.isNaN$D(yma) ) {
newYMin=Math.min(newYMin, ymi);
newYMin=Math.min(newYMin, yma);
newYMax=Math.max(newYMax, yma);
newYMax=Math.max(newYMax, ymi);
measurableFound=true;
}}
if (measurableFound) {
if (this.logScaleY && ((this.yTopMarginPercentage > 0.0 ) || (this.yBottomMarginPercentage > 0.0 ) ) ) {
newYMax *= 1.0 + this.yTopMarginPercentage / 100.0;
newYMin /= 1.0 + this.yBottomMarginPercentage / 100.0;
} else if (!this.logScaleY && ((this.yTopMarginPercentage > 0.0 ) || (this.yBottomMarginPercentage > 0.0 ) ) ) {
var yMed=(newYMin + newYMax) / 2;
var yLen=(newYMax - newYMin) / 2;
newYMax=yMed + yLen * (1.0 + this.yTopMarginPercentage / 100.0);
newYMin=yMed - yLen * (1.0 + this.yBottomMarginPercentage / 100.0);
}if (newYMax - newYMin < 1.4E-45 ) {
if (Double.isNaN$D(this.yfloor)) {
newYMin=0.9 * newYMin - 0.5;
} else {
newYMin=Math.min(newYMin, this.yfloor);
}if (Double.isNaN$D(this.yceil)) {
newYMax=1.1 * newYMax + 0.5;
} else {
newYMax=Math.max(newYMax, this.yceil);
}}var range=Math.max(newYMax - newYMin, 1.4E-45);
while (Math.abs((newYMax + range) / range) > 100000.0 ){
range *= 2;
newYMin -= range;
newYMax += range;
}
if (this.autoscaleYMin) {
this.yminPreferred=newYMin - this.autoscaleMargin * range;
}if (this.autoscaleYMax) {
this.ymaxPreferred=newYMax + this.autoscaleMargin * range;
}} else {
if (!Double.isNaN$D(this.yfloor) && this.autoscaleYMin ) {
this.yminPreferred=this.yfloor;
}if (!Double.isNaN$D(this.yceil) && this.autoscaleYMax ) {
this.ymaxPreferred=this.yceil;
}}if (!Double.isNaN$D(this.yfloor)) {
this.yminPreferred=Math.min(this.yfloor, this.yminPreferred);
}if (!Double.isNaN$D(this.yceil)) {
this.ymaxPreferred=Math.max(this.yceil, this.ymaxPreferred);
}if (Math.abs(this.ymaxPreferred - this.yminPreferred) < 1.4E-45 ) {
this.yminPreferred=0.9 * this.ymaxPreferred - 1.4E-45;
this.ymaxPreferred=1.1 * this.ymaxPreferred + 1.4E-45;
}});

Clazz.newMeth(C$, 'paintDrawableList$java_awt_Graphics$java_util_ArrayList', function (g, tempList) {
if (tempList == null ) {
return;
}var w=this.getWidth$() - this.leftGutter - this.rightGutter ;
var h=this.getHeight$() - this.bottomGutter - this.topGutter ;
if ((w < 0) || (h < 0) ) {
return;
}var g2=g.create$();
if (this.clipAtGutter) {
g2.clipRect$I$I$I$I(this.leftGutter, this.topGutter, w, h);
}if (!tempList.isEmpty$() && (Clazz.instanceOf(tempList.get$I(0), "org.opensourcephysics.display.False3D")) ) {
tempList.get$I(0).draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics(this, g2);
} else {
for (var i=0, n=tempList.size$(); i < n; i++) {
if (!this.validImage) {
break;
}tempList.get$I(i).draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics(this, g2);
}
}if (!$I$(26).isJS) this.messages.draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics(this, g2);
g2.dispose$();
});

Clazz.newMeth(C$, 'getGlassPanel$', function () {
return this.glassPanel;
});

Clazz.newMeth(C$, 'setIgnoreRepaint$Z', function (ignoreRepaint) {
C$.superclazz.prototype.setIgnoreRepaint$Z.apply(this, [ignoreRepaint]);
this.glassPanel.setIgnoreRepaint$Z(ignoreRepaint);
});

Clazz.newMeth(C$, 'getDimensionSetter$', function () {
return this.dimensionSetter;
});

Clazz.newMeth(C$, 'addDrawable$org_opensourcephysics_display_Drawable', function (drawable) {
{
if ((drawable != null ) && !this.drawableList.contains$O(drawable) ) {
this.drawableList.add$O(drawable);
this.invalidateImage$();
}}if (Clazz.instanceOf(drawable, "org.opensourcephysics.display.Dimensioned")) {
this.dimensionSetter=(drawable);
}});

Clazz.newMeth(C$, 'addDrawables$java_util_Collection', function (drawables) {
{
var it=drawables.iterator$();
while (it.hasNext$()){
var obj=it.next$();
if (Clazz.instanceOf(obj, "org.opensourcephysics.display.Drawable")) {
this.addDrawable$org_opensourcephysics_display_Drawable(obj);
}}
}});

Clazz.newMeth(C$, 'addDrawableAtIndex$I$org_opensourcephysics_display_Drawable', function (index, drawable) {
{
if ((drawable != null ) && !this.drawableList.contains$O(drawable) ) {
this.drawableList.add$I$O(index, drawable);
this.invalidateImage$();
}}if (Clazz.instanceOf(drawable, "org.opensourcephysics.display.Dimensioned")) {
this.dimensionSetter=(drawable);
}});

Clazz.newMeth(C$, 'replaceDrawable$org_opensourcephysics_display_Drawable$org_opensourcephysics_display_Drawable', function (oldDrawable, newDrawable) {
{
if ((oldDrawable != null ) && this.drawableList.contains$O(oldDrawable) ) {
var i=this.drawableList.indexOf$O(oldDrawable);
this.drawableList.set$I$O(i, newDrawable);
if (Clazz.instanceOf(newDrawable, "org.opensourcephysics.display.Dimensioned")) {
this.dimensionSetter=(newDrawable);
}} else {
this.addDrawable$org_opensourcephysics_display_Drawable(newDrawable);
}}});

Clazz.newMeth(C$, 'removeDrawable$org_opensourcephysics_display_Drawable', function (drawable) {
{
this.drawableList.remove$O(drawable);
}if (Clazz.instanceOf(drawable, "org.opensourcephysics.display.Dimensioned")) {
this.dimensionSetter=null;
}});

Clazz.newMeth(C$, 'removeObjectsOfClass$Class', function (c) {
{
var it=this.drawableList.iterator$();
while (it.hasNext$()){
var element=it.next$();
if (element.getClass$() === c ) {
it.remove$();
if (Clazz.instanceOf(element, "org.opensourcephysics.display.Dimensioned")) {
this.dimensionSetter=null;
}}}
}});

Clazz.newMeth(C$, 'removeDrawables$Class', function (c) {
{
var it=this.drawableList.iterator$();
while (it.hasNext$()){
var element=it.next$();
if (c.isInstance$O(element)) {
it.remove$();
if (Clazz.instanceOf(element, "org.opensourcephysics.display.Dimensioned")) {
this.dimensionSetter=null;
}}}
}});

Clazz.newMeth(C$, 'removeOptionController$', function () {
this.removeMouseListener$java_awt_event_MouseListener(this.optionController);
this.removeMouseMotionListener$java_awt_event_MouseMotionListener(this.optionController);
});

Clazz.newMeth(C$, 'addOptionController$', function () {
this.addMouseListener$java_awt_event_MouseListener(this.optionController);
this.addMouseMotionListener$java_awt_event_MouseMotionListener(this.optionController);
});

Clazz.newMeth(C$, 'clear$', function () {
{
this.drawableList.clear$();
}this.dimensionSetter=null;
});

Clazz.newMeth(C$, 'getDrawables$', function () {
{
return Clazz.new_($I$(13,1).c$$java_util_Collection,[this.drawableList]);
}});

Clazz.newMeth(C$, 'getDrawables$Class', function (type) {
var all=null;
{
all=Clazz.new_($I$(13,1).c$$java_util_Collection,[this.drawableList]);
}var objects=Clazz.new_($I$(13,1));
for (var d, $d = all.iterator$(); $d.hasNext$()&&((d=($d.next$())),1);) {
if (type.isInstance$O(d)) {
objects.add$O(type.cast$O(d));
}}
return objects;
});

Clazz.newMeth(C$, 'getObjectOfClass$Class', function (type) {
var all=null;
{
all=Clazz.new_($I$(13,1).c$$java_util_Collection,[this.drawableList]);
}var objects=Clazz.new_($I$(13,1));
for (var d, $d = all.iterator$(); $d.hasNext$()&&((d=($d.next$())),1);) {
if (d.getClass$() === type ) {
objects.add$O(type.cast$O(d));
}}
return objects;
});

Clazz.newMeth(C$, 'getGutters$', function () {
return Clazz.array(Integer.TYPE, -1, [this.leftGutter, this.topGutter, this.rightGutter, this.bottomGutter]);
});

Clazz.newMeth(C$, 'setGutters$IA', function (gutters) {
this.leftGutter=gutters[0];
this.topGutter=gutters[1];
this.rightGutter=gutters[2];
this.bottomGutter=gutters[3];
});

Clazz.newMeth(C$, 'setGutters$I$I$I$I', function (left, top, right, bottom) {
this.leftGutter=left;
this.topGutter=top;
this.rightGutter=right;
this.bottomGutter=bottom;
});

Clazz.newMeth(C$, 'setPreferredGutters$I$I$I$I', function (left, top, right, bottom) {
this.leftGutterPreferred=this.leftGutter=left;
this.topGutterPreferred=this.topGutter=top;
this.rightGutterPreferred=this.rightGutter=right;
this.bottomGutterPreferred=this.bottomGutter=bottom;
});

Clazz.newMeth(C$, 'resetGutters$', function () {
this.leftGutter=this.leftGutterPreferred;
this.topGutter=this.topGutterPreferred;
this.rightGutter=this.rightGutterPreferred;
this.bottomGutter=this.bottomGutterPreferred;
});

Clazz.newMeth(C$, 'getBottomGutter$', function () {
return this.bottomGutter;
});

Clazz.newMeth(C$, 'getTopGutter$', function () {
return this.topGutter;
});

Clazz.newMeth(C$, 'getLeftGutter$', function () {
return this.leftGutter;
});

Clazz.newMeth(C$, 'getRightGutter$', function () {
return this.rightGutter;
});

Clazz.newMeth(C$, 'setMessage$S', function (msg) {
this.brMessageBox.setText$S(msg);
this.messages.setMessage$S(msg);
});

Clazz.newMeth(C$, 'setMessage$S$I', function (msg, location) {
switch (location) {
case 0:
this.blMessageBox.setText$S(msg);
this.messages.setMessage$S$I(msg, 0);
break;
case 1:
this.brMessageBox.setText$S(msg);
this.messages.setMessage$S$I(msg, 1);
break;
case 2:
this.trMessageBox.setText$S(msg);
this.messages.setMessage$S$I(msg, 2);
break;
case 3:
this.tlMessageBox.setText$S(msg);
this.messages.setMessage$S$I(msg, 3);
break;
}
this.repaint$();
});

Clazz.newMeth(C$, 'setShowCoordinates$Z', function (show) {
if (this.showCoordinates && !show ) {
this.removeMouseListener$java_awt_event_MouseListener(this.mouseController);
this.removeMouseMotionListener$java_awt_event_MouseMotionListener(this.mouseController);
} else if (!this.showCoordinates && show ) {
this.addMouseListener$java_awt_event_MouseListener(this.mouseController);
this.addMouseMotionListener$java_awt_event_MouseMotionListener(this.mouseController);
}this.showCoordinates=show;
});

Clazz.newMeth(C$, 'isZoomEvent$java_awt_event_MouseEvent', function (e) {
return $I$(7).isPopupTrigger$java_awt_event_InputEvent(e);
});

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(40,1));
}, 1);

Clazz.newMeth(C$, 'transformPath2$java_awt_geom_GeneralPath', function (s) {
return this.pixelTransform.createTransformedShape$java_awt_Shape(s);
});

Clazz.newMeth(C$, 'transformShape2$java_awt_Shape', function (s) {
return this.pixelTransform.createTransformedShape$java_awt_Shape(s);
});

C$.$static$=function(){C$.$static$=0;
C$.RECORD_PAINT_TIMES=false;
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.DrawingPanel, "CMController", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.event.MouseInputAdapter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
var s=this.this$0.coordinateStrBuilder.getCoordinateString$org_opensourcephysics_display_DrawingPanel$java_awt_event_MouseEvent(this.this$0, e);
System.err.println$S(" pressed coortd==" + s);
this.this$0.blMessageBox.setText$S(s);
this.this$0.messages.setMessage$S$I(s, 0);
this.this$0.invalidateImage$.apply(this.this$0, []);
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.this$0.blMessageBox.setText$S(null);
this.this$0.messages.setMessage$S$I(null, 0);
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
});

Clazz.newMeth(C$, 'mouseEntered$java_awt_event_MouseEvent', function (e) {
if (this.this$0.showCoordinates) {
this.this$0.setMouseCursor$java_awt_Cursor.apply(this.this$0, [$I$(1).getPredefinedCursor$I(1)]);
}});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
this.this$0.setMouseCursor$java_awt_Cursor.apply(this.this$0, [$I$(1).getPredefinedCursor$I(0)]);
});

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
var s=this.this$0.coordinateStrBuilder.getCoordinateString$org_opensourcephysics_display_DrawingPanel$java_awt_event_MouseEvent(this.this$0, e);
System.err.println$S(" pressed coortd==" + s);
this.this$0.blMessageBox.setText$S(s);
this.this$0.messages.setMessage$S$I(s, 0);
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DrawingPanel, "ZoomBox", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.visible=false;
this.dragged=false;
this.showUndraggedBox=true;
},1);

C$.$fields$=[['Z',['visible','dragged','showUndraggedBox'],'I',['xstart','ystart','xstop','ystop','xlast','ylast']]]

Clazz.newMeth(C$, 'startZoom$I$I', function (xpix, ypix) {
if (!this.this$0.isZoom$.apply(this.this$0, [])) {
return;
}this.visible=true;
this.dragged=false;
this.xlast=this.xstop=this.xstart=xpix;
this.ylast=this.ystop=this.ystart=ypix;
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
});

Clazz.newMeth(C$, 'hide$', function () {
this.visible=false;
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
});

Clazz.newMeth(C$, 'setShowUndraggedBox$Z', function (show) {
this.showUndraggedBox=show;
});

Clazz.newMeth(C$, 'drag$I$I', function (xpix, ypix) {
if (!this.visible) {
return;
}this.dragged=true;
this.xstop=xpix;
this.ystop=ypix;
var g=this.b$['javax.swing.JComponent'].getGraphics$.apply(this.b$['javax.swing.JComponent'], []);
if (g == null ) {
return;
}g.setXORMode$java_awt_Color($I$(2).green);
g.drawRect$I$I$I$I(Math.min(this.xstart, this.xlast), Math.min(this.ystart, this.ylast), Math.abs(this.xlast - this.xstart), Math.abs(this.ylast - this.ystart));
this.xlast=this.xstop;
this.ylast=this.ystop;
g.drawRect$I$I$I$I(Math.min(this.xstart, this.xlast), Math.min(this.ystart, this.ylast), Math.abs(this.xlast - this.xstart), Math.abs(this.ylast - this.ystart));
g.setPaintMode$();
g.dispose$();
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) {
return;
}if ((this.xstop == this.xstart) || (this.ystop == this.ystart) ) {
return;
}g.setColor$java_awt_Color($I$(2).magenta);
g.drawRect$I$I$I$I(Math.min(this.xstart, this.xstop), Math.min(this.ystart, this.ystop), Math.abs(this.xstop - this.xstart), Math.abs(this.ystop - this.ystart));
});

Clazz.newMeth(C$, 'isDragged$', function () {
return this.dragged && (this.xstop != this.xstart) && (this.ystop != this.ystart)  ;
});

Clazz.newMeth(C$, 'isVisible$', function () {
return this.visible;
});

Clazz.newMeth(C$, 'reportZoom$', function () {
var xmin=Math.min(this.xstart, this.xstop);
var xmax=Math.max(this.xstart, this.xstop);
var ymin=Math.min(this.ystart, this.ystop);
var ymax=Math.max(this.ystart, this.ystop);
return Clazz.new_($I$(3,1).c$$I$I$I$I,[xmin, ymin, xmax - xmin, ymax - ymin]);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DrawingPanel, "PopupmenuListener", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.ActionListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (evt) {
this.this$0.zoomBox.visible=false;
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
var cmd=evt.getActionCommand$();
if (cmd.equals$O($I$(4).getString$S("DrawingFrame.InspectMenuItem"))) {
this.this$0.showInspector$.apply(this.this$0, []);
} else if (cmd.equals$O($I$(4).getString$S("DisplayPanel.Snapshot_menu_item"))) {
this.this$0.snapshot$.apply(this.this$0, []);
} else if (cmd.equals$O($I$(4).getString$S("DisplayPanel.Zoom_in_menu_item"))) {
this.this$0.setAutoscaleX$Z.apply(this.this$0, [false]);
this.this$0.setAutoscaleY$Z.apply(this.this$0, [false]);
this.this$0.zoomIn$.apply(this.this$0, []);
} else if (cmd.equals$O($I$(4).getString$S("DisplayPanel.Zoom_out_menu_item"))) {
this.this$0.setAutoscaleX$Z.apply(this.this$0, [false]);
this.this$0.setAutoscaleY$Z.apply(this.this$0, [false]);
this.this$0.zoomOut$.apply(this.this$0, []);
} else if (cmd.equals$O($I$(4).getString$S("DrawingFrame.Autoscale_menu_item"))) {
var nan=NaN;
this.this$0.setPreferredMinMax$D$D$D$D.apply(this.this$0, [nan, nan, nan, nan]);
} else if (cmd.equals$O($I$(4).getString$S("DrawingFrame.Scale_menu_item"))) {
var plotInspector=Clazz.new_($I$(5,1).c$$org_opensourcephysics_display_DrawingPanel,[this.this$0]);
plotInspector.setLocationRelativeTo$java_awt_Component(this.this$0);
plotInspector.updateDisplay$();
$I$(6,"setFonts$O$I",[plotInspector, $I$(6).getLevel$()]);
plotInspector.pack$();
plotInspector.setVisible$Z(true);
}});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DrawingPanel, "OptionController", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.event.MouseInputAdapter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
if (this.this$0.isZoomEvent$java_awt_event_MouseEvent.apply(this.this$0, [e])) {
this.this$0.zoomBox.startZoom$I$I(e.getX$(), e.getY$());
} else {
this.this$0.zoomBox.visible=false;
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
}});

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
this.this$0.zoomBox.drag$I$I(e.getX$(), e.getY$());
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
if (this.this$0.isZoomEvent$java_awt_event_MouseEvent.apply(this.this$0, [e]) && (this.this$0.popupmenu != null ) && this.this$0.popupmenu.isEnabled$()  ) {
if (this.this$0.isZoom$.apply(this.this$0, []) && !this.this$0.zoomBox.isDragged$() && this.this$0.zoomBox.showUndraggedBox  ) {
var dim=this.this$0.viewRect == null  ? this.b$['java.awt.Component'].getSize$.apply(this.b$['java.awt.Component'], []) : this.this$0.viewRect.getSize$();
dim.width-=this.this$0.getLeftGutter$.apply(this.this$0, []) + this.this$0.getRightGutter$.apply(this.this$0, []);
dim.height-=this.this$0.getTopGutter$.apply(this.this$0, []) + this.this$0.getBottomGutter$.apply(this.this$0, []);
this.this$0.zoomBox.xstart=e.getX$() - (dim.width/4|0);
this.this$0.zoomBox.xstop=e.getX$() + (dim.width/4|0);
this.this$0.zoomBox.ystart=e.getY$() - (dim.height/4|0);
this.this$0.zoomBox.ystop=e.getY$() + (dim.height/4|0);
this.this$0.zoomBox.visible=true;
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
}var popup=this.this$0.getPopupMenu$.apply(this.this$0, []);
if (popup != null ) popup.show$java_awt_Component$I$I(e.getComponent$(), e.getX$(), e.getY$());
return;
} else if ($I$(7).isPopupTrigger$java_awt_event_InputEvent(e) && (this.this$0.popupmenu == null ) && (this.this$0.customInspector != null )  ) {
this.this$0.customInspector.setVisible$Z(true);
return;
}});

Clazz.newMeth(C$, 'mouseMoved$java_awt_event_MouseEvent', function (e) {
var focuser=$I$(8).getCurrentKeyboardFocusManager$();
var focusOwner=focuser.getFocusOwner$();
if (focusOwner != null  && !(Clazz.instanceOf(focusOwner, "javax.swing.text.JTextComponent")) ) {
this.b$['javax.swing.JComponent'].requestFocusInWindow$.apply(this.b$['javax.swing.JComponent'], []);
}});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DrawingPanel, "GlassPanel", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JPanel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'render$java_awt_Graphics', function (g) {
try {
var c=this.this$0.glassPanelLayout.getComponents$();
for (var i=0, n=c.length; i < n; i++) {
if (c[i] == null ) {
continue;
}g.translate$I$I(c[i].getX$(), c[i].getY$());
c[i].print$java_awt_Graphics(g);
g.translate$I$I(-c[i].getX$(), -c[i].getY$());
}
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DrawingPanel, "DrawingPanelLoader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var panel=obj;
control.setValue$S$D("preferred x min", panel.getPreferredXMin$());
control.setValue$S$D("preferred x max", panel.getPreferredXMax$());
control.setValue$S$D("preferred y min", panel.getPreferredYMin$());
control.setValue$S$D("preferred y max", panel.getPreferredYMax$());
control.setValue$S$Z("autoscale x", panel.isAutoscaleX$());
control.setValue$S$Z("autoscale y", panel.isAutoscaleY$());
control.setValue$S$Z("square aspect", panel.isSquareAspect$());
control.setValue$S$O("drawables", panel.getDrawables$());
});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
var panel=Clazz.new_($I$(9,1));
var xmin=control.getDouble$S("preferred x min");
var xmax=control.getDouble$S("preferred x max");
var ymin=control.getDouble$S("preferred y min");
var ymax=control.getDouble$S("preferred y max");
panel.setPreferredMinMax$D$D$D$D(xmin, xmax, ymin, ymax);
if (control.getBoolean$S("autoscale x")) {
panel.setAutoscaleX$Z(true);
}if (control.getBoolean$S("autoscale y")) {
panel.setAutoscaleY$Z(true);
}return panel;
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var panel=obj;
var xmin=control.getDouble$S("preferred x min");
var xmax=control.getDouble$S("preferred x max");
var ymin=control.getDouble$S("preferred y min");
var ymax=control.getDouble$S("preferred y max");
panel.setPreferredMinMax$D$D$D$D(xmin, xmax, ymin, ymax);
panel.squareAspect=control.getBoolean$S("square aspect");
if (control.getBoolean$S("autoscale x")) {
panel.setAutoscaleX$Z(true);
}if (control.getBoolean$S("autoscale y")) {
panel.setAutoscaleY$Z(true);
}var drawables=Clazz.getClass($I$(10),['add$O','addAll$java_util_Collection','clear$','contains$O','containsAll$java_util_Collection','equals$O','hashCode$','isEmpty$','iterator$','parallelStream$','remove$O','removeAll$java_util_Collection','removeIf$java_util_function_Predicate','retainAll$java_util_Collection','size$','spliterator$','stream$','toArray$','toArray$OA']).cast$O(control.getObject$S("drawables"));
if (drawables != null ) {
panel.clear$();
var it=drawables.iterator$();
while (it.hasNext$()){
panel.addDrawable$org_opensourcephysics_display_Drawable(it.next$());
}
}return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-31 17:30:09 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
