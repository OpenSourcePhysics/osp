(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),p$1={},I$=[[0,'org.opensourcephysics.controls.XML','org.opensourcephysics.display.Dataset','org.opensourcephysics.display.HighlightableDataset','java.awt.Color','java.awt.Shape',['java.awt.geom.Rectangle2D','.Double'],['org.opensourcephysics.display.HighlightableDataset','.Loader']]],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HighlightableDataset", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.display.Dataset', 'org.opensourcephysics.display.Interactive');
C$.$classes$=[['Loader',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.highlighted=Clazz.array(Boolean.TYPE, [1]);
this.highlightColor=Clazz.new_($I$(4,1).c$$I$I$I$I,[255, 255, 0, 128]);
this.hitShapes=Clazz.array($I$(5), [0]);
this.hitIndex=-1;
this.screenCoordinates=Clazz.array(Double.TYPE, [2, null]);
},1);

C$.$fields$=[['I',['hitIndex'],'O',['highlighted','boolean[]','+previous','highlightColor','java.awt.Color','highlightShape','java.awt.Shape','hitShapes','java.awt.Shape[]','screenCoordinates','double[][]']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Color', function (markerColor) {
;C$.superclazz.c$$java_awt_Color.apply(this,[markerColor]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Color$java_awt_Color$Z', function (markerColor, lineColor, connected) {
;C$.superclazz.c$$java_awt_Color$java_awt_Color$Z.apply(this,[markerColor, lineColor, connected]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'append$D$D', function (x, y) {
C$.superclazz.prototype.append$D$D.apply(this, [x, y]);
p$1.adjustCapacity$I.apply(this, [this.xpoints.length]);
});

Clazz.newMeth(C$, 'append$DA$DA', function (xarray, yarray) {
C$.superclazz.prototype.append$DA$DA.apply(this, [xarray, yarray]);
p$1.adjustCapacity$I.apply(this, [this.xpoints.length]);
});

Clazz.newMeth(C$, 'clear$', function () {
C$.superclazz.prototype.clear$.apply(this, []);
this.previous=this.highlighted;
this.highlighted=Clazz.array(Boolean.TYPE, [this.xpoints.length]);
});

Clazz.newMeth(C$, 'restoreHighlights$', function () {
if ((this.previous != null ) && (this.previous.length == this.highlighted.length) ) {
this.highlighted=this.previous;
}});

Clazz.newMeth(C$, 'clearHighlights$', function () {
for (var i=0; i < this.highlighted.length; i++) {
this.highlighted[i]=false;
}
});

Clazz.newMeth(C$, 'setHighlighted$I$Z', function (i, highlight) {
if (i >= this.highlighted.length) {
p$1.adjustCapacity$I.apply(this, [i + 1]);
}this.highlighted[i]=highlight;
});

Clazz.newMeth(C$, 'isHighlighted$I', function (i) {
if (i >= this.highlighted.length) {
p$1.adjustCapacity$I.apply(this, [i + 1]);
}return this.highlighted[i];
});

Clazz.newMeth(C$, 'setHighlightColor$java_awt_Color', function (color) {
this.highlightColor=Clazz.new_([color.getRed$(), color.getGreen$(), color.getBlue$(), 128],$I$(4,1).c$$I$I$I$I);
});

Clazz.newMeth(C$, 'moveDatum$I', function (loc) {
C$.superclazz.prototype.moveDatum$I.apply(this, [loc]);
});

Clazz.newMeth(C$, 'adjustCapacity$I', function (minLength) {
var len=Math.max(this.xpoints.length, minLength);
if (this.highlighted.length == len) {
return;
}var temp=this.highlighted;
this.highlighted=Clazz.array(Boolean.TYPE, [len]);
var count=Math.min(temp.length, len);
System.arraycopy$O$I$O$I$I(temp, 0, this.highlighted, 0, count);
}, p$1);

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (drawingPanel, g) {
C$.superclazz.prototype.draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics.apply(this, [drawingPanel, g]);
var offset=this.getMarkerSize$() + 4;
var edge=2 * offset;
var g2=g.create$();
g2.setClip$I$I$I$I(drawingPanel.leftGutter - offset - 1 , drawingPanel.topGutter - offset - 1 , drawingPanel.getWidth$() - drawingPanel.leftGutter - drawingPanel.rightGutter  + 2 + 2 * offset, drawingPanel.getHeight$() - drawingPanel.bottomGutter - drawingPanel.topGutter  + 2 + 2 * offset);
var viewRect=drawingPanel.getViewRect$();
if (viewRect != null ) {
g2.clipRect$I$I$I$I(viewRect.x, viewRect.y, viewRect.x + viewRect.width, viewRect.y + viewRect.height);
}this.hitShapes=Clazz.array($I$(5), [this.index]);
var xValues=this.getXPoints$();
var yValues=this.getYPoints$();
if (this.screenCoordinates[0] == null  || this.screenCoordinates[0].length != this.index ) {
this.screenCoordinates[0]=Clazz.array(Double.TYPE, [this.index]);
this.screenCoordinates[1]=Clazz.array(Double.TYPE, [this.index]);
}for (var i=0; i < this.index; i++) {
if (Double.isNaN$D(yValues[i])) {
this.screenCoordinates[1][i]=NaN;
continue;
}var xp=drawingPanel.xToPix$D(xValues[i]);
var yp=drawingPanel.yToPix$D(yValues[i]);
this.screenCoordinates[0][i]=xp;
this.screenCoordinates[1][i]=yp;
this.hitShapes[i]=Clazz.new_($I$(6,1).c$$D$D$D$D,[xp - offset, yp - offset, edge, edge]);
if (!this.isHighlighted$I(i)) {
continue;
}g2.setColor$java_awt_Color(this.highlightColor);
g2.fill$java_awt_Shape(this.hitShapes[i]);
}
g2.dispose$();
});

Clazz.newMeth(C$, 'findInteractive$org_opensourcephysics_display_DrawingPanel$I$I', function (panel, xpix, ypix) {
var l=panel.getLeftGutter$();
var r=panel.getRightGutter$();
var t=panel.getTopGutter$();
var b=panel.getBottomGutter$();
var dim=panel.getSize$();
if ((xpix < l) || (xpix > dim.width - r) ) {
return null;
}if ((ypix < t) || (ypix > dim.height - b) ) {
return null;
}this.hitIndex=-1;
for (var i=0; i < this.hitShapes.length; i++) {
if (this.hitShapes[i] != null  && this.hitShapes[i].contains$D$D(xpix, ypix) ) {
this.hitIndex=i;
return this;
}}
return null;
});

Clazz.newMeth(C$, 'getHitIndex$', function () {
return this.hitIndex;
});

Clazz.newMeth(C$, 'getScreenCoordinates$', function () {
return this.screenCoordinates;
});

Clazz.newMeth(C$, 'setEnabled$Z', function (enabled) {
});

Clazz.newMeth(C$, 'isEnabled$', function () {
return true;
});

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
});

Clazz.newMeth(C$, 'setX$D', function (x) {
});

Clazz.newMeth(C$, 'setY$D', function (y) {
});

Clazz.newMeth(C$, 'getX$', function () {
if (this.hitIndex > -1) {
return this.xpoints[this.hitIndex];
}return NaN;
});

Clazz.newMeth(C$, 'getY$', function () {
if (this.hitIndex > -1) {
return this.ypoints[this.hitIndex];
}return NaN;
});

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(7,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.HighlightableDataset, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'org.opensourcephysics.controls.XMLLoader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
$I$(1,"getLoader$Class",[Clazz.getClass($I$(2))]).saveObject$org_opensourcephysics_controls_XMLControl$O(control, obj);
var data=obj;
control.setValue$S$O("highlighted", data.highlighted);
});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(3,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
$I$(1,"getLoader$Class",[Clazz.getClass($I$(2))]).loadObject$org_opensourcephysics_controls_XMLControl$O(control, obj);
var data=obj;
var highlighted=control.getObject$S("highlighted");
if (highlighted != null ) {
data.highlighted=highlighted;
}return data;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-31 17:30:09 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
