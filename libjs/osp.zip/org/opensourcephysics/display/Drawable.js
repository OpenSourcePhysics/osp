(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Drawable");
C$.$defaults$ = function(C$){

Clazz.newMeth(C$, 'isInteractive$',  function () {
return false;
});
};})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:03 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
