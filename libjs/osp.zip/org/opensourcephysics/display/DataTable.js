(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),p$1={},p$2={},p$3={},I$=[[0,'java.util.Arrays','java.util.ArrayList',['org.opensourcephysics.display.DataTable','.ModelFilterResult'],'org.opensourcephysics.display.DataTable',['org.opensourcephysics.display.DataTable','.DataTableElement'],'javax.swing.table.TableColumn','org.opensourcephysics.media.core.NumberField','java.awt.Color','java.text.NumberFormat','java.util.HashMap','javax.swing.JOptionPane','java.awt.BorderLayout','org.opensourcephysics.display.DisplayRes','javax.swing.JButton','javax.swing.JLabel','javax.swing.JTextField','javax.swing.AbstractAction','org.opensourcephysics.display.OSPRuntime','javax.swing.SwingUtilities','java.awt.event.KeyAdapter','java.awt.event.FocusAdapter','javax.swing.JScrollPane','java.awt.Dimension','javax.swing.JPanel','java.awt.GridLayout','javax.swing.BorderFactory','org.opensourcephysics.display.TeXParser','javax.swing.JList','org.opensourcephysics.display.DrawingPanel','org.opensourcephysics.display.DrawableTextLine','javax.swing.UIManager',['org.opensourcephysics.display.DataTable','.DoubleRenderer'],'javax.swing.Timer',['org.opensourcephysics.display.DataTable','.DefaultDataTableModel'],['org.opensourcephysics.display.DataTable','.HeaderRenderer'],['org.opensourcephysics.display.DataTable','.DataTableColumnModel'],'org.opensourcephysics.display.SortDecorator','java.awt.event.MouseAdapter',['org.opensourcephysics.display.DataTable','.PrecisionRenderer'],['org.opensourcephysics.display.DataTable','.UnitRenderer'],['org.opensourcephysics.display.DataTable','.NumberFormatDialog'],'java.awt.Toolkit',['org.opensourcephysics.display.DataTable','.RowNumberRenderer'],'javax.swing.event.TableModelEvent','java.util.TreeSet']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DataTable", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.JTable', 'java.awt.event.ActionListener');
C$.$classes$=[['DataTableElement',10],['DefaultDataTableModel',12],['ModelFilterResult',10],['DataTableColumnModel',2],['DoubleRenderer',12],['PrecisionRenderer',12],['RowNumberRenderer',12],['UnitRenderer',12],['NumberFormatDialog',1],['HeaderRenderer',1]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.precisionRenderersByColumnName=Clazz.new_($I$(10,1));
this.unitRenderersByColumnName=Clazz.new_($I$(10,1));
this.maximumFractionDigits=3;
this.refreshDelay=0;
this.refreshTimer=Clazz.new_($I$(33,1).c$$I$java_awt_event_ActionListener,[this.refreshDelay, this]);
this.labelColumnWidth=40;
this.minimumDataColumnWidth=24;
this.clickCountToSort=1;
},1);

C$.$fields$=[['I',['maximumFractionDigits','refreshDelay','labelColumnWidth','minimumDataColumnWidth','clickCountToSort'],'O',['decorator','org.opensourcephysics.display.SortDecorator','precisionRenderersByColumnName','java.util.HashMap','+unitRenderersByColumnName','dataTableModel','org.opensourcephysics.display.DataTableModel','rowNumberRenderer','org.opensourcephysics.display.DataTable.RowNumberRenderer','refreshTimer','javax.swing.Timer','formatDialog','org.opensourcephysics.display.DataTable.NumberFormatDialog']]
,['S',['NO_PATTERN','rowName'],'O',['PANEL_BACKGROUND','java.awt.Color','+LIGHT_BLUE','defaultDoubleRenderer','org.opensourcephysics.display.DataTable.DoubleRenderer']]]

Clazz.newMeth(C$, 'c$', function () {
C$.c$$org_opensourcephysics_display_DataTableModel.apply(this, [Clazz.new_($I$(34,1))]);
}, 1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_display_DataTableModel', function (model) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.refreshTimer.setRepeats$Z(false);
this.refreshTimer.setCoalesce$Z(true);
this.setModel$org_opensourcephysics_display_DataTableModel(model);
this.setColumnSelectionAllowed$Z(true);
this.setGridColor$java_awt_Color($I$(8).blue);
this.setSelectionBackground$java_awt_Color(C$.LIGHT_BLUE);
var header=this.getTableHeader$();
header.setForeground$java_awt_Color($I$(8).blue);
var headerRenderer=Clazz.new_([this, null, this.getTableHeader$().getDefaultRenderer$()],$I$(35,1).c$$javax_swing_table_TableCellRenderer);
this.getTableHeader$().setDefaultRenderer$javax_swing_table_TableCellRenderer(headerRenderer);
this.setSelectionForeground$java_awt_Color($I$(8).red);
this.setColumnModel$javax_swing_table_TableColumnModel(Clazz.new_($I$(36,1),[this, null]));
this.setSelectionMode$I(1);
this.setColumnSelectionAllowed$Z(true);
this.decorator=Clazz.new_([this.getModel$()],$I$(37,1).c$$javax_swing_table_TableModel);
this.setModel$javax_swing_table_TableModel(this.decorator);
header.addMouseListener$java_awt_event_MouseListener(((P$.DataTable$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTable$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
if (!$I$(18).isPopupTrigger$java_awt_event_InputEvent(e) && !e.isControlDown$() && !e.isShiftDown$() && e.getClickCount$() == this.b$['org.opensourcephysics.display.DataTable'].clickCountToSort  ) {
var tcm=this.b$['javax.swing.JTable'].getColumnModel$.apply(this.b$['javax.swing.JTable'], []);
var vc=tcm.getColumnIndexAtX$I(e.getX$());
var mc=this.b$['javax.swing.JTable'].convertColumnIndexToModel$I.apply(this.b$['javax.swing.JTable'], [vc]);
if (this.b$['org.opensourcephysics.display.DataTable'].decorator.getSortedColumn$() != mc) {
this.b$['org.opensourcephysics.display.DataTable'].sort$I.apply(this.b$['org.opensourcephysics.display.DataTable'], [mc]);
}}});
})()
), Clazz.new_($I$(38,1),[this, null],P$.DataTable$1)));
}, 1);

Clazz.newMeth(C$, 'setMaximumFractionDigits$S$I', function (columnName, maximumFractionDigits) {
this.precisionRenderersByColumnName.put$O$O(columnName, Clazz.new_($I$(39,1).c$$I,[maximumFractionDigits]));
});

Clazz.newMeth(C$, 'setFormatPattern$S$S', function (columnName, pattern) {
if ((pattern == null ) || pattern.equals$O("") ) {
this.precisionRenderersByColumnName.remove$O(columnName);
} else {
this.precisionRenderersByColumnName.put$O$O(columnName, Clazz.new_($I$(39,1).c$$S,[pattern]));
}this.firePropertyChange$S$O$O("format", null, columnName);
});

Clazz.newMeth(C$, 'setUnits$S$S$S', function (columnName, units, tooltip) {
if (units == null ) {
this.unitRenderersByColumnName.remove$O(columnName);
} else {
var renderer=this.precisionRenderersByColumnName.get$O(columnName);
if (renderer == null ) renderer=this.getDefaultRenderer$Class(Clazz.getClass(Double));
var unitRenderer=Clazz.new_($I$(40,1).c$$javax_swing_table_TableCellRenderer$S$S,[renderer, units, tooltip]);
this.unitRenderersByColumnName.put$O$O(columnName, unitRenderer);
}});

Clazz.newMeth(C$, 'getFormatPattern$S', function (columnName) {
var r=this.precisionRenderersByColumnName.get$O(columnName);
return (r == null ) ? "" : r.pattern;
});

Clazz.newMeth(C$, 'getFormattedColumnNames$', function () {
return this.precisionRenderersByColumnName.keySet$().toArray$OA(Clazz.array(String, [0]));
});

Clazz.newMeth(C$, 'getFormattedValueAt$I$I', function (row, col) {
var value=this.getValueAt$I$I(row, col);
if (value == null ) return null;
var renderer=this.getCellRenderer$I$I(row, col);
var c=renderer.getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I(this, value, false, false, 0, 0);
if (Clazz.instanceOf(c, "javax.swing.JLabel")) {
var s=(c).getText$().trim$();
if (Clazz.instanceOf(renderer, "org.opensourcephysics.display.DataTable.UnitRenderer")) {
var units=(renderer).units;
if (!"".equals$O(units)) {
var n=s.lastIndexOf$S(units);
if (n > -1) s=s.substring$I$I(0, n);
}}return s;
}return value;
});

Clazz.newMeth(C$, 'getFormatDialog$SA$SA', function (names, selected) {
if (this.formatDialog == null ) {
this.formatDialog=Clazz.new_($I$(41,1),[this, null]);
var dim=$I$(42).getDefaultToolkit$().getScreenSize$();
var x=((dim.width - this.formatDialog.getBounds$().width)/2|0);
var y=((dim.height - this.formatDialog.getBounds$().height)/2|0);
this.formatDialog.setLocation$I$I(x, y);
}this.formatDialog.setColumns$SA$SA(names, selected);
return this.formatDialog;
});

Clazz.newMeth(C$, 'sort$I', function (col) {
this.decorator.sort$I(col);
});

Clazz.newMeth(C$, 'getSortedColumn$', function () {
return this.decorator.getSortedColumn$();
});

Clazz.newMeth(C$, 'setMaximumFractionDigits$I', function (maximumFractionDigits) {
this.maximumFractionDigits=maximumFractionDigits;
this.setDefaultRenderer$Class$javax_swing_table_TableCellRenderer(Clazz.getClass(Double), Clazz.new_($I$(39,1).c$$I,[maximumFractionDigits]));
});

Clazz.newMeth(C$, 'getMaximumFractionDigits$', function () {
return this.maximumFractionDigits;
});

Clazz.newMeth(C$, 'setRowNumberVisible$Z', function (_rowNumberVisible) {
if (this.dataTableModel.isRowNumberVisible$() != _rowNumberVisible ) {
if (_rowNumberVisible && (this.rowNumberRenderer == null ) ) {
this.rowNumberRenderer=Clazz.new_($I$(43,1).c$$javax_swing_JTable,[this]);
}this.dataTableModel.setRowNumberVisible$Z(_rowNumberVisible);
}});

Clazz.newMeth(C$, 'setModel$org_opensourcephysics_display_DataTableModel', function (_model) {
C$.superclazz.prototype.setModel$javax_swing_table_TableModel.apply(this, [_model]);
this.dataTableModel=_model;
});

Clazz.newMeth(C$, 'setStride$javax_swing_table_TableModel$I', function (tableModel, stride) {
this.dataTableModel.setStride$javax_swing_table_TableModel$I(tableModel, stride);
});

Clazz.newMeth(C$, 'setColumnVisible$javax_swing_table_TableModel$I$Z', function (tableModel, columnIndex, b) {
this.dataTableModel.setColumnVisible$javax_swing_table_TableModel$I$Z(tableModel, columnIndex, b);
});

Clazz.newMeth(C$, 'isRowNumberVisible$', function () {
return this.dataTableModel.isRowNumberVisible$();
});

Clazz.newMeth(C$, 'getCellRenderer$I$I', function (row, column) {
var i=this.convertColumnIndexToModel$I(column);
if ((i == 0) && this.dataTableModel.isRowNumberVisible$() ) {
return this.rowNumberRenderer;
}var unitRenderer=null;
var baseRenderer=null;
try {
var tableColumn=this.getColumnModel$().getColumn$I(column);
unitRenderer=this.unitRenderersByColumnName.get$O(tableColumn.getHeaderValue$());
baseRenderer=tableColumn.getCellRenderer$();
if (baseRenderer == null ) {
var key=tableColumn.getHeaderValue$();
baseRenderer=this.precisionRenderersByColumnName.get$O(key);
if (baseRenderer == null  && key.endsWith$S("\'") ) {
baseRenderer=this.precisionRenderersByColumnName.get$O(key.substring$I$I(0, key.length$() - 1));
}}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
if (baseRenderer == null ) {
if (this.getColumnClass$I(column).equals$O(Clazz.getClass(Double))) {
baseRenderer=C$.defaultDoubleRenderer;
} else {
baseRenderer=this.getDefaultRenderer$Class(this.getColumnClass$I(column));
}}if (unitRenderer != null ) {
unitRenderer.setBaseRenderer$javax_swing_table_TableCellRenderer(baseRenderer);
return unitRenderer;
}return baseRenderer;
});

Clazz.newMeth(C$, 'getPrecisionRenderer$S', function (columnName) {
return this.precisionRenderersByColumnName.get$O(columnName);
});

Clazz.newMeth(C$, 'setRefreshDelay$I', function (delay) {
if (delay > 0) {
this.refreshTimer.setDelay$I(delay);
this.refreshTimer.setInitialDelay$I(delay);
} else if (delay <= 0) {
this.refreshTimer.stop$();
}this.refreshDelay=delay;
});

Clazz.newMeth(C$, 'refreshTable$', function () {
if (this.refreshDelay > 0) {
this.refreshTimer.start$();
} else {
var doRefreshTable=((P$.DataTable$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTable$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
this.b$['org.opensourcephysics.display.DataTable'].actionPerformed$java_awt_event_ActionEvent.apply(this.b$['org.opensourcephysics.display.DataTable'], [null]);
});
})()
), Clazz.new_(P$.DataTable$2.$init$,[this, null]));
if ($I$(19).isEventDispatchThread$()) {
doRefreshTable.run$();
} else {
$I$(19).invokeLater$Runnable(doRefreshTable);
}}});

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (evt) {
try {
for (var key, $key = this.precisionRenderersByColumnName.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
var renderer=this.precisionRenderersByColumnName.get$O(key);
renderer.numberFormat.setDecimalFormatSymbols$java_text_DecimalFormatSymbols($I$(18).getDecimalFormatSymbols$());
}
C$.defaultDoubleRenderer.getFormat$().setDecimalFormatSymbols$java_text_DecimalFormatSymbols($I$(18).getDecimalFormatSymbols$());
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
var model=this.getColumnModel$();
var colCount=model.getColumnCount$();
var modelIndexes=Clazz.array(Integer.TYPE, [colCount]);
var columnWidths=Clazz.array(Integer.TYPE, [colCount]);
var columnNames=Clazz.new_($I$(2,1));
for (var i=0; i < colCount; i++) {
var column=model.getColumn$I(i);
modelIndexes[i]=column.getModelIndex$();
columnWidths[i]=column.getWidth$();
columnNames.add$O(column.getHeaderValue$());
}
this.tableChanged$javax_swing_event_TableModelEvent(Clazz.new_($I$(44,1).c$$javax_swing_table_TableModel$I,[this.dataTableModel, -1]));
var newCount=model.getColumnCount$();
var newColumnNames=Clazz.new_($I$(2,1));
for (var i=0; i < newCount; i++) {
var column=model.getColumn$I(i);
newColumnNames.add$O(column.getHeaderValue$());
}
var removedIndexes=Clazz.new_($I$(45,1));
for (var i=0; i < colCount; i++) {
if (!newColumnNames.contains$O(columnNames.get$I(i))) {
removedIndexes.add$O(new Integer(modelIndexes[i]));
}}
var addedIndexes=Clazz.new_($I$(45,1));
for (var i=0; i < newCount; i++) {
if (!columnNames.contains$O(newColumnNames.get$I(i))) {
addedIndexes.add$O(new Integer(i));
}}
while (!removedIndexes.isEmpty$()){
var n=(removedIndexes.last$()).valueOf();
removedIndexes.remove$O(new Integer(n));
var newModelIndexes=Clazz.array(Integer.TYPE, [colCount - 1]);
var newColumnWidths=Clazz.array(Integer.TYPE, [colCount - 1]);
var k=0;
for (var i=0; i < colCount; i++) {
if (modelIndexes[i] == n) continue;
if (modelIndexes[i] > n) {
newModelIndexes[k]=modelIndexes[i] - 1;
} else {
newModelIndexes[k]=modelIndexes[i];
}newColumnWidths[k]=columnWidths[i];
k++;
}
modelIndexes=newModelIndexes;
columnWidths=newColumnWidths;
colCount=modelIndexes.length;
}
while (!addedIndexes.isEmpty$()){
var n=(addedIndexes.first$()).valueOf();
addedIndexes.remove$O(new Integer(n));
var newModelIndexes=Clazz.array(Integer.TYPE, [colCount + 1]);
var newColumnWidths=Clazz.array(Integer.TYPE, [colCount + 1]);
for (var i=0; i < colCount; i++) {
if (modelIndexes[i] >= n) {
newModelIndexes[i]=modelIndexes[i] + 1;
} else {
newModelIndexes[i]=modelIndexes[i];
}newColumnWidths[i]=columnWidths[i];
}
newModelIndexes[colCount]=n;
newColumnWidths[colCount]=model.getColumn$I(n).getWidth$();
modelIndexes=newModelIndexes;
columnWidths=newColumnWidths;
colCount=modelIndexes.length;
}
 outer : for (var targetIndex=0; targetIndex < colCount; targetIndex++) {
for (var i=0; i < colCount; i++) {
if (model.getColumn$I(i).getModelIndex$() == modelIndexes[targetIndex]) {
model.moveColumn$I$I(i, targetIndex);
continue outer;
}}
}
for (var i=0; i < columnWidths.length; i++) {
model.getColumn$I(i).setPreferredWidth$I(columnWidths[i]);
model.getColumn$I(i).setWidth$I(columnWidths[i]);
}
});

Clazz.newMeth(C$, 'add$javax_swing_table_TableModel', function (tableModel) {
this.dataTableModel.add$javax_swing_table_TableModel(tableModel);
});

Clazz.newMeth(C$, 'remove$javax_swing_table_TableModel', function (tableModel) {
this.dataTableModel.remove$javax_swing_table_TableModel(tableModel);
});

Clazz.newMeth(C$, 'clear$', function () {
this.dataTableModel.clear$();
});

C$.$static$=function(){C$.$static$=0;
C$.PANEL_BACKGROUND=$I$(31).getColor$O("Panel.background");
C$.LIGHT_BLUE=Clazz.new_($I$(8,1).c$$I$I$I,[204, 204, 255]);
C$.NO_PATTERN=$I$(13).getString$S("DataTable.FormatDialog.NoFormat");
C$.rowName=$I$(13).getString$S("DataTable.Header.Row");
C$.defaultDoubleRenderer=Clazz.new_($I$(32,1));
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTable, "DataTableElement", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.stride=1;
},1);

C$.$fields$=[['I',['stride'],'O',['tableModel','javax.swing.table.TableModel','columnVisibilities','boolean[]']]]

Clazz.newMeth(C$, 'c$$javax_swing_table_TableModel', function (t) {
;C$.$init$.apply(this);
this.tableModel=t;
}, 1);

Clazz.newMeth(C$, 'setStride$I', function (_stride) {
this.stride=_stride;
});

Clazz.newMeth(C$, 'setColumnVisible$I$Z', function (columnIndex, visible) {
p$1.ensureCapacity$I.apply(this, [columnIndex + 1]);
this.columnVisibilities[columnIndex]=visible;
});

Clazz.newMeth(C$, 'getStride$', function () {
return this.stride;
});

Clazz.newMeth(C$, 'getColumnVisibilities$', function () {
return this.columnVisibilities;
});

Clazz.newMeth(C$, 'getColumnCount$', function () {
var count=0;
var numberOfColumns=this.tableModel.getColumnCount$();
p$1.ensureCapacity$I.apply(this, [numberOfColumns]);
for (var i=0; i < numberOfColumns; i++) {
var visible=this.columnVisibilities[i];
if (visible) {
count++;
}}
return count;
});

Clazz.newMeth(C$, 'getValueAt$I$I', function (rowIndex, columnIndex) {
return this.tableModel.getValueAt$I$I(rowIndex, columnIndex);
});

Clazz.newMeth(C$, 'getColumnName$I', function (columnIndex) {
return this.tableModel.getColumnName$I(columnIndex);
});

Clazz.newMeth(C$, 'getColumnClass$I', function (columnIndex) {
return this.tableModel.getColumnClass$I(columnIndex);
});

Clazz.newMeth(C$, 'getRowCount$', function () {
return this.tableModel.getRowCount$();
});

Clazz.newMeth(C$, 'ensureCapacity$I', function (minimumCapacity) {
if (this.columnVisibilities == null ) {
this.columnVisibilities=Clazz.array(Boolean.TYPE, [((minimumCapacity * 3)/2|0) + 1]);
$I$(1).fill$ZA$Z(this.columnVisibilities, true);
} else if (this.columnVisibilities.length < minimumCapacity) {
var temp=this.columnVisibilities;
this.columnVisibilities=Clazz.array(Boolean.TYPE, [((minimumCapacity * 3)/2|0) + 1]);
System.arraycopy$O$I$O$I$I(temp, 0, this.columnVisibilities, 0, temp.length);
$I$(1).fill$ZA$I$I$Z(this.columnVisibilities, temp.length, this.columnVisibilities.length, true);
}}, p$1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTable, "DefaultDataTableModel", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'org.opensourcephysics.display.DataTableModel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.dataTableElements=Clazz.new_($I$(2,1));
this.rowNumberVisible=false;
},1);

C$.$fields$=[['Z',['rowNumberVisible'],'O',['dataTableElements','java.util.ArrayList']]]

Clazz.newMeth(C$, 'setColumnVisible$javax_swing_table_TableModel$I$Z', function (tableModel, columnIndex, b) {
var dte=p$2.findElementContaining$javax_swing_table_TableModel.apply(this, [tableModel]);
dte.setColumnVisible$I$Z(columnIndex, b);
});

Clazz.newMeth(C$, 'setStride$javax_swing_table_TableModel$I', function (tableModel, stride) {
var dte=p$2.findElementContaining$javax_swing_table_TableModel.apply(this, [tableModel]);
dte.setStride$I(stride);
});

Clazz.newMeth(C$, 'setRowNumberVisible$Z', function (_rowNumberVisible) {
this.rowNumberVisible=_rowNumberVisible;
});

Clazz.newMeth(C$, 'setValueAt$O$I$I', function (value, rowIndex, columnIndex) {
if (this.dataTableElements.size$() == 0) {
return;
}if (this.rowNumberVisible) {
if (columnIndex == 0) {
return;
}}var mfr=$I$(3).find$Z$java_util_ArrayList$I(this.rowNumberVisible, this.dataTableElements, columnIndex);
var dte=mfr.tableElement;
var stride=dte.getStride$();
rowIndex=rowIndex * stride;
if (rowIndex >= dte.getRowCount$()) {
return;
}dte.tableModel.setValueAt$O$I$I(value, rowIndex, mfr.column);
});

Clazz.newMeth(C$, 'isRowNumberVisible$', function () {
return this.rowNumberVisible;
});

Clazz.newMeth(C$, 'getColumnName$I', function (columnIndex) {
if ((this.dataTableElements.size$() == 0) && !this.rowNumberVisible ) {
return null;
}if (this.rowNumberVisible) {
if (columnIndex == 0) {
return $I$(4).rowName;
}}var mfr=$I$(3).find$Z$java_util_ArrayList$I(this.rowNumberVisible, this.dataTableElements, columnIndex);
var dte=mfr.tableElement;
var name=dte.getColumnName$I(mfr.column);
return name;
});

Clazz.newMeth(C$, 'getRowCount$', function () {
var rowCount=0;
for (var i=0; i < this.dataTableElements.size$(); i++) {
var dte=this.dataTableElements.get$I(i);
var stride=dte.getStride$();
rowCount=Math.max(rowCount, ((dte.getRowCount$() + stride - 1)/stride|0));
}
return rowCount;
});

Clazz.newMeth(C$, 'getColumnCount$', function () {
var columnCount=0;
for (var i=0; i < this.dataTableElements.size$(); i++) {
var dte=this.dataTableElements.get$I(i);
columnCount+=dte.getColumnCount$();
}
if (this.rowNumberVisible) {
columnCount++;
}return columnCount;
});

Clazz.newMeth(C$, 'getValueAt$I$I', function (rowIndex, columnIndex) {
if (this.dataTableElements.size$() == 0) {
return null;
}if (this.rowNumberVisible) {
if (columnIndex == 0) {
return  new Integer(rowIndex);
}}var mfr=$I$(3).find$Z$java_util_ArrayList$I(this.rowNumberVisible, this.dataTableElements, columnIndex);
var dte=mfr.tableElement;
var stride=dte.getStride$();
rowIndex=rowIndex * stride;
if (rowIndex >= dte.getRowCount$()) {
return null;
}return dte.getValueAt$I$I(rowIndex, mfr.column);
});

Clazz.newMeth(C$, 'getColumnClass$I', function (columnIndex) {
if (this.rowNumberVisible) {
if (columnIndex == 0) {
return Clazz.getClass(Integer);
}}if ((columnIndex == 0) && this.rowNumberVisible ) {
columnIndex--;
}var mfr=$I$(3).find$Z$java_util_ArrayList$I(this.rowNumberVisible, this.dataTableElements, columnIndex);
var dte=mfr.tableElement;
return dte.getColumnClass$I(mfr.column);
});

Clazz.newMeth(C$, 'isCellEditable$I$I', function (rowIndex, columnIndex) {
return false;
});

Clazz.newMeth(C$, 'remove$javax_swing_table_TableModel', function (tableModel) {
var dte=p$2.findElementContaining$javax_swing_table_TableModel.apply(this, [tableModel]);
this.dataTableElements.remove$O(dte);
});

Clazz.newMeth(C$, 'clear$', function () {
this.dataTableElements.clear$();
});

Clazz.newMeth(C$, 'add$javax_swing_table_TableModel', function (tableModel) {
this.dataTableElements.add$O(Clazz.new_($I$(5,1).c$$javax_swing_table_TableModel,[tableModel]));
});

Clazz.newMeth(C$, 'addTableModelListener$javax_swing_event_TableModelListener', function (l) {
});

Clazz.newMeth(C$, 'removeTableModelListener$javax_swing_event_TableModelListener', function (l) {
});

Clazz.newMeth(C$, 'findElementContaining$javax_swing_table_TableModel', function (tableModel) {
for (var i=0; i < this.dataTableElements.size$(); i++) {
var dte=this.dataTableElements.get$I(i);
if (dte.tableModel === tableModel ) {
return dte;
}}
return null;
}, p$2);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTable, "ModelFilterResult", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['column'],'O',['tableElement','org.opensourcephysics.display.DataTable.DataTableElement']]]

Clazz.newMeth(C$, 'c$$org_opensourcephysics_display_DataTable_DataTableElement$I', function (_tableElement, _column) {
;C$.$init$.apply(this);
this.tableElement=_tableElement;
this.column=_column;
}, 1);

Clazz.newMeth(C$, 'find$Z$java_util_ArrayList$I', function (rowNumberVisible, dataTableElements, tableColumnIndex) {
if (rowNumberVisible) {
tableColumnIndex--;
}var totalColumns=0;
for (var i=0; i < dataTableElements.size$(); i++) {
var dte=dataTableElements.get$I(i);
p$1.ensureCapacity$I.apply(dte, [tableColumnIndex]);
var columnCount=dte.getColumnCount$();
totalColumns+=columnCount;
if (totalColumns > tableColumnIndex) {
var columnIndex=(columnCount + tableColumnIndex) - totalColumns;
var visible=dte.getColumnVisibilities$();
for (var j=0; j < tableColumnIndex; j++) {
if (!visible[j]) {
columnIndex++;
}}
return Clazz.new_(C$.c$$org_opensourcephysics_display_DataTable_DataTableElement$I,[dte, columnIndex]);
}}
return null;
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTable, "DataTableColumnModel", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.table.DefaultTableColumnModel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getColumn$I', function (columnIndex) {
var tableColumn;
try {
tableColumn=C$.superclazz.prototype.getColumn$I.apply(this, [columnIndex]);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
return Clazz.new_($I$(6,1));
} else {
throw ex;
}
}
var headerValue=tableColumn.getHeaderValue$();
if (headerValue == null ) {
return tableColumn;
} else if (headerValue.equals$O($I$(4).rowName) && (tableColumn.getModelIndex$() == 0) ) {
tableColumn.setMaxWidth$I(this.this$0.labelColumnWidth);
tableColumn.setMinWidth$I(this.this$0.labelColumnWidth);
tableColumn.setResizable$Z(false);
} else {
tableColumn.setMinWidth$I(this.this$0.minimumDataColumnWidth);
}return tableColumn;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTable, "DoubleRenderer", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'javax.swing.table.DefaultTableCellRenderer');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['numberField','org.opensourcephysics.media.core.NumberField']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.numberField=Clazz.new_($I$(7,1).c$$I,[0]);
this.setHorizontalAlignment$I(4);
this.setBackground$java_awt_Color($I$(8).WHITE);
}, 1);

Clazz.newMeth(C$, 'setValue$O', function (value) {
if (value == null ) {
this.setText$S("");
return;
}this.numberField.setValue$D((value).valueOf());
this.setText$S(this.numberField.getText$());
});

Clazz.newMeth(C$, 'getFormat$', function () {
return this.numberField.getFormat$();
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTable, "PrecisionRenderer", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'javax.swing.table.DefaultTableCellRenderer');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['pattern'],'O',['numberFormat','java.text.DecimalFormat']]]

Clazz.newMeth(C$, 'c$$I', function (precision) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.numberFormat=$I$(9).getInstance$();
this.numberFormat.setMaximumFractionDigits$I(precision);
this.setHorizontalAlignment$I(4);
this.setBackground$java_awt_Color($I$(8).WHITE);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (pattern) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.numberFormat=$I$(9).getInstance$();
this.numberFormat.applyPattern$S(pattern);
this.pattern=pattern;
this.setHorizontalAlignment$I(4);
}, 1);

Clazz.newMeth(C$, 'setPrecision$I', function (precision) {
this.numberFormat.setMaximumFractionDigits$I(precision);
});

Clazz.newMeth(C$, 'setValue$O', function (value) {
this.setText$S((value == null ) ? "" : this.numberFormat.format$O(value));
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTable, "RowNumberRenderer", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'javax.swing.JLabel', 'javax.swing.table.TableCellRenderer');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['table','javax.swing.JTable']]]

Clazz.newMeth(C$, 'c$$javax_swing_JTable', function (_table) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.table=_table;
this.setHorizontalAlignment$I(4);
this.setOpaque$Z(true);
this.setForeground$java_awt_Color($I$(8).black);
this.setBackground$java_awt_Color($I$(4).PANEL_BACKGROUND);
}, 1);

Clazz.newMeth(C$, 'getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I', function (table, value, isSelected, hasFocus, row, column) {
if (table.isRowSelected$I(row)) {
var i=table.getSelectedColumns$();
if ((i.length == 1) && (table.convertColumnIndexToModel$I(i[0]) == 0) ) {
this.setBackground$java_awt_Color($I$(4).PANEL_BACKGROUND);
} else {
this.setBackground$java_awt_Color($I$(8).gray);
}} else {
this.setBackground$java_awt_Color($I$(4).PANEL_BACKGROUND);
}this.setText$S(value.toString());
return this;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTable, "UnitRenderer", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'javax.swing.table.TableCellRenderer');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['units','tooltip'],'O',['baseRenderer','javax.swing.table.TableCellRenderer']]]

Clazz.newMeth(C$, 'c$$javax_swing_table_TableCellRenderer$S$S', function (renderer, units, tooltip) {
;C$.$init$.apply(this);
this.units=units;
this.tooltip=tooltip;
this.setBaseRenderer$javax_swing_table_TableCellRenderer(renderer);
}, 1);

Clazz.newMeth(C$, 'setBaseRenderer$javax_swing_table_TableCellRenderer', function (renderer) {
this.baseRenderer=renderer;
});

Clazz.newMeth(C$, 'getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I', function (table, value, isSelected, hasFocus, row, column) {
var c=this.baseRenderer.getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I(table, value, isSelected, hasFocus, row, column);
if (Clazz.instanceOf(c, "javax.swing.JLabel") && this.units != null  ) {
var label=c;
if (label.getText$() != null  && !label.getText$().equals$O("") ) label.setText$S(label.getText$() + this.units);
label.setToolTipText$S(this.tooltip);
}return c;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTable, "NumberFormatDialog", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.realNames=Clazz.new_($I$(10,1));
this.prevPatterns=Clazz.new_($I$(10,1));
},1);

C$.$fields$=[['O',['closeButton','javax.swing.JButton','+cancelButton','+helpButton','+applyButton','patternLabel','javax.swing.JLabel','+sampleLabel','patternField','javax.swing.JTextField','+sampleField','sampleFormat','java.text.DecimalFormat','displayedNames','String[]','realNames','java.util.Map','+prevPatterns','columnList','javax.swing.JList','columnScroller','javax.swing.JScrollPane']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$java_awt_Frame$Z.apply(this,[$I$(11).getFrameForComponent$java_awt_Component(this.this$0), true]);C$.$init$.apply(this);
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(12,1)));
this.setTitle$S($I$(13).getString$S("DataTable.NumberFormat.Dialog.Title"));
this.sampleFormat=$I$(9).getNumberInstance$();
this.closeButton=Clazz.new_([$I$(13).getString$S("Dialog.Button.Close.Text")],$I$(14,1).c$$S);
this.closeButton.addActionListener$java_awt_event_ActionListener(((P$.DataTable$NumberFormatDialog$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTable$NumberFormatDialog$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['java.awt.Dialog'].setVisible$Z.apply(this.b$['java.awt.Dialog'], [false]);
});
})()
), Clazz.new_(P$.DataTable$NumberFormatDialog$1.$init$,[this, null])));
this.applyButton=Clazz.new_([$I$(13).getString$S("Dialog.Button.Apply.Text")],$I$(14,1).c$$S);
this.applyButton.addActionListener$java_awt_event_ActionListener(((P$.DataTable$NumberFormatDialog$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTable$NumberFormatDialog$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].patternField.getAction$().actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_(P$.DataTable$NumberFormatDialog$2.$init$,[this, null])));
this.cancelButton=Clazz.new_([$I$(13).getString$S("GUIUtils.Cancel")],$I$(14,1).c$$S);
this.cancelButton.addActionListener$java_awt_event_ActionListener(((P$.DataTable$NumberFormatDialog$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTable$NumberFormatDialog$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
for (var displayedName, $displayedName = 0, $$displayedName = this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].displayedNames; $displayedName<$$displayedName.length&&((displayedName=($$displayedName[$displayedName])),1);$displayedName++) {
var name=this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].realNames.get$O(displayedName);
this.b$['org.opensourcephysics.display.DataTable'].setFormatPattern$S$S.apply(this.b$['org.opensourcephysics.display.DataTable'], [name, this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].prevPatterns.get$O(name)]);
}
this.b$['org.opensourcephysics.display.DataTable'].refreshTable$.apply(this.b$['org.opensourcephysics.display.DataTable'], []);
this.b$['java.awt.Dialog'].setVisible$Z.apply(this.b$['java.awt.Dialog'], [false]);
});
})()
), Clazz.new_(P$.DataTable$NumberFormatDialog$3.$init$,[this, null])));
this.helpButton=Clazz.new_([$I$(13).getString$S("GUIUtils.Help")],$I$(14,1).c$$S);
this.helpButton.addActionListener$java_awt_event_ActionListener(((P$.DataTable$NumberFormatDialog$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTable$NumberFormatDialog$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var tab="      ";
var nl=System.getProperty$S$S("line.separator", "/n");
$I$(11,"showMessageDialog$java_awt_Component$O$S$I",[this.b$['org.opensourcephysics.display.DataTable'].formatDialog, $I$(13).getString$S("DataTable.NumberFormat.Help.Message1") + nl + nl + tab + $I$(13).getString$S("DataTable.NumberFormat.Help.Message2") + nl + tab + $I$(13).getString$S("DataTable.NumberFormat.Help.Message3") + nl + tab + $I$(13).getString$S("DataTable.NumberFormat.Help.Message4") + nl + tab + $I$(13).getString$S("DataTable.NumberFormat.Help.Message5") + nl + nl + $I$(13).getString$S("DataTable.NumberFormat.Help.Message6") + " PI." , $I$(13).getString$S("DataTable.NumberFormat.Help.Title"), 1]);
});
})()
), Clazz.new_(P$.DataTable$NumberFormatDialog$4.$init$,[this, null])));
this.patternLabel=Clazz.new_([$I$(13).getString$S("DataTable.NumberFormat.Dialog.Label.Format")],$I$(15,1).c$$S);
this.sampleLabel=Clazz.new_([$I$(13).getString$S("DataTable.NumberFormat.Dialog.Label.Sample")],$I$(15,1).c$$S);
this.patternField=Clazz.new_($I$(16,1).c$$I,[6]);
this.patternField.setAction$javax_swing_Action(((P$.DataTable$NumberFormatDialog$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTable$NumberFormatDialog$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var pattern=this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].patternField.getText$();
if (pattern.indexOf$S($I$(4).NO_PATTERN) > -1) pattern="";
for (var i=1; i < 10; i++) {
pattern=pattern.replaceAll$S$S(String.valueOf$I(i), "0");
}
var i=pattern.indexOf$S("0e0");
if (i > -1) {
pattern=pattern.substring$I$I(0, i) + "0E0" + pattern.substring$I(i + 3) ;
}try {
p$3.showNumberFormatAndSample$S.apply(this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'], [pattern]);
var selectedColumns=this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].columnList.getSelectedValues$();
for (var displayedName, $displayedName = 0, $$displayedName = selectedColumns; $displayedName<$$displayedName.length&&((displayedName=($$displayedName[$displayedName])),1);$displayedName++) {
var name=this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].realNames.get$O(displayedName.toString());
this.b$['org.opensourcephysics.display.DataTable'].setFormatPattern$S$S.apply(this.b$['org.opensourcephysics.display.DataTable'], [name, pattern]);
}
this.b$['org.opensourcephysics.display.DataTable'].refreshTable$.apply(this.b$['org.opensourcephysics.display.DataTable'], []);
} catch (ex) {
if (Clazz.exceptionOf(ex,"RuntimeException")){
this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].patternField.setBackground$java_awt_Color(Clazz.new_($I$(8,1).c$$I$I$I,[255, 153, 153]));
this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].patternField.setText$S(pattern);
return;
} else {
throw ex;
}
}
});
})()
), Clazz.new_($I$(17,1),[this, null],P$.DataTable$NumberFormatDialog$5)));
this.patternField.addKeyListener$java_awt_event_KeyListener(((P$.DataTable$NumberFormatDialog$6||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTable$NumberFormatDialog$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
if (e.getKeyCode$() == 10) {
this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].patternField.setBackground$java_awt_Color($I$(8).white);
} else {
this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].patternField.setBackground$java_awt_Color($I$(8).yellow);
var runner=((P$.DataTable$NumberFormatDialog$6$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTable$NumberFormatDialog$6$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
var pattern=this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].patternField.getText$();
if (pattern.indexOf$S($I$(4).NO_PATTERN) > -1) pattern="";
for (var i=1; i < 10; i++) {
pattern=pattern.replaceAll$S$S(String.valueOf$I(i), "0");
}
var i=pattern.indexOf$S("0e0");
if (i > -1) {
pattern=pattern.substring$I$I(0, i) + "0E0" + pattern.substring$I(i + 3) ;
}if (pattern.equals$O("") || pattern.equals$O($I$(4).NO_PATTERN) ) {
var renderer=this.b$['org.opensourcephysics.display.DataTable'].getDefaultRenderer$Class.apply(this.b$['org.opensourcephysics.display.DataTable'], [Clazz.getClass(Double)]);
var c=renderer.getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I(this.b$['org.opensourcephysics.display.DataTable'], new Double(3.141592653589793), false, false, 0, 0);
if (Clazz.instanceOf(c, "javax.swing.JLabel")) {
var text=(c).getText$();
this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].sampleField.setText$S(text);
}} else {
try {
this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].sampleFormat.setDecimalFormatSymbols$java_text_DecimalFormatSymbols($I$(18).getDecimalFormatSymbols$());
this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].sampleFormat.applyPattern$S(pattern);
this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].sampleField.setText$S(this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].sampleFormat.format$D(3.141592653589793));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}});
})()
), Clazz.new_(P$.DataTable$NumberFormatDialog$6$1.$init$,[this, null]));
$I$(19).invokeLater$Runnable(runner);
}});
})()
), Clazz.new_($I$(20,1),[this, null],P$.DataTable$NumberFormatDialog$6)));
this.patternField.addFocusListener$java_awt_event_FocusListener(((P$.DataTable$NumberFormatDialog$7||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTable$NumberFormatDialog$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.FocusAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].patternField.setBackground$java_awt_Color($I$(8).white);
this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].patternField.getAction$().actionPerformed$java_awt_event_ActionEvent(null);
});
})()
), Clazz.new_($I$(21,1),[this, null],P$.DataTable$NumberFormatDialog$7)));
this.sampleField=Clazz.new_($I$(16,1).c$$I,[6]);
this.sampleField.setEditable$Z(false);
this.columnScroller=Clazz.new_($I$(22,1));
this.columnScroller.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(23,1).c$$I$I,[160, 120]));
var formatPanel=Clazz.new_([Clazz.new_($I$(25,1))],$I$(24,1).c$$java_awt_LayoutManager);
var patternPanel=Clazz.new_($I$(24,1));
patternPanel.add$java_awt_Component(this.patternLabel);
patternPanel.add$java_awt_Component(this.patternField);
formatPanel.add$java_awt_Component(patternPanel);
var samplePanel=Clazz.new_($I$(24,1));
samplePanel.add$java_awt_Component(this.sampleLabel);
samplePanel.add$java_awt_Component(this.sampleField);
formatPanel.add$java_awt_Component(samplePanel);
this.add$java_awt_Component$O(formatPanel, "North");
var columnPanel=Clazz.new_([Clazz.new_($I$(12,1))],$I$(24,1).c$$java_awt_LayoutManager);
columnPanel.setBorder$javax_swing_border_Border($I$(26,"createTitledBorder$S",[$I$(13).getString$S("DataTable.FormatDialog.ApplyTo.Title")]));
columnPanel.add$java_awt_Component$O(this.columnScroller, "Center");
this.add$java_awt_Component$O(columnPanel, "Center");
var buttonPanel=Clazz.new_($I$(24,1));
buttonPanel.add$java_awt_Component(this.helpButton);
buttonPanel.add$java_awt_Component(this.applyButton);
buttonPanel.add$java_awt_Component(this.closeButton);
buttonPanel.add$java_awt_Component(this.cancelButton);
this.add$java_awt_Component$O(buttonPanel, "South");
this.pack$();
}, 1);

Clazz.newMeth(C$, 'showNumberFormatAndSample$IA', function (selectedIndices) {
if (selectedIndices == null  || selectedIndices.length == 0 ) {
p$3.showNumberFormatAndSample$S.apply(this, [""]);
} else if (selectedIndices.length == 1) {
var name=this.realNames.get$O(this.displayedNames[selectedIndices[0]]);
var pattern=this.this$0.getFormatPattern$S.apply(this.this$0, [name]);
p$3.showNumberFormatAndSample$S.apply(this, [pattern]);
} else {
var name=this.realNames.get$O(this.displayedNames[selectedIndices[0]]);
var pattern=this.this$0.getFormatPattern$S.apply(this.this$0, [name]);
for (var i=1; i < selectedIndices.length; i++) {
name=this.realNames.get$O(this.displayedNames[selectedIndices[i]]);
if (!pattern.equals$O(this.this$0.getFormatPattern$S.apply(this.this$0, [name]))) {
pattern=null;
break;
}}
p$3.showNumberFormatAndSample$S.apply(this, [pattern]);
}}, p$3);

Clazz.newMeth(C$, 'showNumberFormatAndSample$S', function (pattern) {
if (pattern == null ) {
this.sampleField.setText$S("");
this.patternField.setText$S("");
return;
}if (pattern.equals$O("") || pattern.equals$O($I$(4).NO_PATTERN) ) {
var renderer=this.this$0.getDefaultRenderer$Class.apply(this.this$0, [Clazz.getClass(Double)]);
var c=renderer.getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I(this.this$0, new Double(3.141592653589793), false, false, 0, 0);
if (Clazz.instanceOf(c, "javax.swing.JLabel")) {
var text=(c).getText$();
this.sampleField.setText$S(text);
}this.patternField.setText$S($I$(4).NO_PATTERN);
} else {
this.sampleFormat.setDecimalFormatSymbols$java_text_DecimalFormatSymbols($I$(18).getDecimalFormatSymbols$());
this.sampleFormat.applyPattern$S(pattern);
this.sampleField.setText$S(this.sampleFormat.format$D(3.141592653589793));
this.patternField.setText$S(pattern);
}}, p$3);

Clazz.newMeth(C$, 'setColumns$SA$SA', function (names, selected) {
this.displayedNames=Clazz.array(String, [names.length]);
this.realNames.clear$();
for (var i=0; i < names.length; i++) {
var s=$I$(27).removeSubscripting$S(names[i]);
this.displayedNames[i]="   " + s + " " ;
this.realNames.put$O$O(this.displayedNames[i], names[i]);
if (selected != null ) {
for (var j=0; j < selected.length; j++) {
if (selected[j] != null  && selected[j].equals$O(names[i]) ) {
selected[j]=this.displayedNames[i];
}}
}}
this.prevPatterns.clear$();
for (var name, $name = 0, $$name = names; $name<$$name.length&&((name=($$name[$name])),1);$name++) {
this.prevPatterns.put$O$O(name, this.this$0.getFormatPattern$S.apply(this.this$0, [name]));
}
this.columnList=Clazz.new_($I$(28,1).c$$OA,[this.displayedNames]);
this.columnList.setLayoutOrientation$I(2);
this.columnList.setVisibleRowCount$I(-1);
this.columnList.addListSelectionListener$javax_swing_event_ListSelectionListener(((P$.DataTable$NumberFormatDialog$8||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTable$NumberFormatDialog$8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.ListSelectionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'valueChanged$javax_swing_event_ListSelectionEvent', function (e) {
p$3.showNumberFormatAndSample$IA.apply(this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'], [this.b$['org.opensourcephysics.display.DataTable.NumberFormatDialog'].columnList.getSelectedIndices$()]);
});
})()
), Clazz.new_(P$.DataTable$NumberFormatDialog$8.$init$,[this, null])));
this.columnScroller.setViewportView$java_awt_Component(this.columnList);
this.pack$();
var indices=null;
if (selected != null ) {
indices=Clazz.array(Integer.TYPE, [selected.length]);
for (var j=0; j < indices.length; j++) {
 inner : for (var i=0; i < this.displayedNames.length; i++) {
if (this.displayedNames[i].equals$O(selected[j])) {
indices[j]=i;
break inner;
}}
}
this.columnList.setSelectedIndices$IA(indices);
} else p$3.showNumberFormatAndSample$IA.apply(this, [indices]);
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTable, "HeaderRenderer", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'javax.swing.table.TableCellRenderer');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.panel=Clazz.new_($I$(29,1));
this.textLine=Clazz.new_($I$(30,1).c$$S$D$D,["", 0, -6]);
},1);

C$.$fields$=[['O',['panel','org.opensourcephysics.display.DrawingPanel','renderer','javax.swing.table.TableCellRenderer','textLine','org.opensourcephysics.display.DrawableTextLine']]]

Clazz.newMeth(C$, 'c$$javax_swing_table_TableCellRenderer', function (renderer) {
;C$.$init$.apply(this);
this.renderer=renderer;
this.textLine.setJustification$I(0);
this.panel.addDrawable$org_opensourcephysics_display_Drawable(this.textLine);
}, 1);

Clazz.newMeth(C$, 'getBaseRenderer$', function () {
return this.renderer;
});

Clazz.newMeth(C$, 'getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I', function (table, value, isSelected, hasFocus, row, col) {
var name=(value == null ) ? "" : value.toString();
this.textLine.setText$S(name);
if ($I$(18).isMac$()) {
name=$I$(27).removeSubscripting$S(name);
}var c=this.renderer.getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I(table, name, isSelected, hasFocus, row, col);
if (!(Clazz.instanceOf(c, "javax.swing.JComponent"))) {
return c;
}var comp=c;
var sortCol=this.this$0.decorator.getSortedColumn$();
var font=comp.getFont$();
if ($I$(18).isMac$()) {
comp.setFont$java_awt_Font((sortCol != this.b$['javax.swing.JTable'].convertColumnIndexToModel$I.apply(this.b$['javax.swing.JTable'], [col])) ? font.deriveFont$I(0) : font.deriveFont$I(1));
if (Clazz.instanceOf(comp, "javax.swing.JLabel")) {
(comp).setHorizontalAlignment$I(0);
}return comp;
}var dim=comp.getPreferredSize$();
dim.height+=1;
this.panel.setPreferredSize$java_awt_Dimension(dim);
var border=comp.getBorder$();
if (Clazz.instanceOf(border, "javax.swing.border.EmptyBorder")) {
border=$I$(26,"createLineBorder$java_awt_Color",[$I$(8).LIGHT_GRAY]);
}this.panel.setBorder$javax_swing_border_Border(border);
this.textLine.setFont$java_awt_Font((sortCol != this.b$['javax.swing.JTable'].convertColumnIndexToModel$I.apply(this.b$['javax.swing.JTable'], [col])) ? font : font.deriveFont$I(1));
this.textLine.setColor$java_awt_Color(comp.getForeground$());
this.textLine.setBackground$java_awt_Color(comp.getBackground$());
this.panel.setBackground$java_awt_Color(comp.getBackground$());
return this.panel;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-31 17:30:09 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
