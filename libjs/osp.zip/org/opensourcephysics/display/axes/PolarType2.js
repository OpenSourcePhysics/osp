(function(){var P$=Clazz.newPackage("org.opensourcephysics.display.axes"),I$=[[0,'org.opensourcephysics.display.axes.CoordinateStringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PolarType2", null, 'org.opensourcephysics.display.axes.AbstractPolarAxis', 'org.opensourcephysics.display.axes.PolarAxes');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_display_PlottingPanel$S$S$D',  function (panel, rLabel, phiLabel, phiOffset) {
;C$.superclazz.c$$org_opensourcephysics_display_DrawingPanel.apply(this,[panel]);C$.$init$.apply(this);
this.defaultLeftGutter=25;
this.defaultTopGutter=25;
this.defaultRightGutter=25;
this.defaultBottomGutter=25;
this.titleLine.setJustification$I(0);
this.titleLine.setFont$java_awt_Font(this.titleFont);
if (panel == null ) {
return;
}panel.setPreferredGutters$I$I$I$I(this.defaultLeftGutter, this.defaultTopGutter, this.defaultRightGutter, this.defaultBottomGutter);
panel.setAxes$org_opensourcephysics_display_axes_DrawableAxes(this);
panel.setCoordinateStringBuilder$org_opensourcephysics_display_axes_CoordinateStringBuilder($I$(1).createPolar$S$S$D(rLabel, phiLabel, phiOffset));
}, 1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_display_PlottingPanel',  function (panel) {
C$.c$$org_opensourcephysics_display_PlottingPanel$S$S$D.apply(this, [panel, "r=", " phi=", 0]);
}, 1);

Clazz.newMeth(C$, 'setXLabel$S$S',  function (s, font_name) {
});

Clazz.newMeth(C$, 'setYLabel$S$S',  function (s, font_name) {
});

Clazz.newMeth(C$, 'getXLabel$',  function () {
return "";
});

Clazz.newMeth(C$, 'getYLabel$',  function () {
return "";
});

Clazz.newMeth(C$, 'setXLog$Z',  function (isLog) {
});

Clazz.newMeth(C$, 'setYLog$Z',  function (isLog) {
});

Clazz.newMeth(C$, 'setShowMajorXGrid$Z',  function (showGrid) {
});

Clazz.newMeth(C$, 'setShowMinorXGrid$Z',  function (showGrid) {
});

Clazz.newMeth(C$, 'setShowMajorYGrid$Z',  function (showGrid) {
});

Clazz.newMeth(C$, 'setShowMinorYGrid$Z',  function (showGrid) {
});

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics',  function (panel, g) {
var gw=panel.getLeftGutter$() + panel.getRightGutter$();
var gh=panel.getTopGutter$() + panel.getLeftGutter$();
if (this.interiorColor != null ) {
g.setColor$java_awt_Color(this.interiorColor);
g.fillRect$I$I$I$I(panel.getLeftGutter$(), panel.getTopGutter$(), panel.getWidth$() - gw, panel.getHeight$() - gh);
g.setColor$java_awt_Color(this.gridcolor);
g.drawRect$I$I$I$I(panel.getLeftGutter$(), panel.getTopGutter$(), panel.getWidth$() - gw, panel.getHeight$() - gh);
}var g2=g.create$();
this.titleLine.setX$D((panel.getXMax$() + panel.getXMin$()) / 2);
if (panel.getTopGutter$() > 20) {
this.titleLine.setY$D(panel.getYMax$() + 5 / panel.getYPixPerUnit$());
} else {
this.titleLine.setY$D(panel.getYMax$() - 25 / panel.getYPixPerUnit$());
}this.titleLine.setColor$java_awt_Color(panel.getForeground$());
this.titleLine.draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics(panel, g2);
g2.clipRect$I$I$I$I(panel.getLeftGutter$(), panel.getTopGutter$(), panel.getWidth$() - gw, panel.getHeight$() - gh);
var rmax=Math.abs(panel.getXMax$()) + Math.abs(panel.getYMax$());
rmax=Math.max(rmax, Math.abs(panel.getXMax$()) + Math.abs(panel.getYMin$()));
rmax=Math.max(rmax, Math.abs(panel.getXMin$()) + Math.abs(panel.getYMax$()));
rmax=Math.max(rmax, Math.abs(panel.getXMin$()) + Math.abs(panel.getYMin$()));
var dr=this.drawRings$D$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics(rmax, panel, g2);
this.drawSpokes$D$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics(rmax, panel, g2);
this.drawRAxis$D$D$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics(dr, rmax, panel, g2);
g2.dispose$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:06 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
