(function(){var P$=Clazz.newPackage("org.opensourcephysics.ejs.control.value"),I$=[[0,'Boolean']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ObjectValue", null, 'org.opensourcephysics.ejs.control.value.Value');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['value','java.lang.Object']]]

Clazz.newMeth(C$, 'c$$O', function (_val) {
;C$.superclazz.c$$I.apply(this,[0]);C$.$init$.apply(this);
this.value=_val;
}, 1);

Clazz.newMeth(C$, 'getBoolean$', function () {
if (this.value == null  || this.value === $I$(1).FALSE  ) {
return false;
}if (this.value === $I$(1).TRUE ) return true;
if (Clazz.instanceOf(this.value, "java.lang.Number")) return (this.value).doubleValue$() != 0 ;
return this.value.toString().equals$O("true");
});

Clazz.newMeth(C$, 'getInteger$', function () {
if (Clazz.instanceOf(this.value, "java.lang.Number")) return (this.value).intValue$();
return (Math.round(this.getDouble$())|0);
});

Clazz.newMeth(C$, 'getDouble$', function () {
try {
if (Clazz.instanceOf(this.value, "java.lang.Number")) return (this.value).doubleValue$();
return Double.valueOf$S(this.value.toString()).doubleValue$();
} catch (exc) {
if (Clazz.exceptionOf(exc,"NumberFormatException")){
return 0.0;
} else {
throw exc;
}
}
});

Clazz.newMeth(C$, 'getString$', function () {
if (this.value == null ) {
return null;
}return this.value.toString();
});

Clazz.newMeth(C$, 'getObject$', function () {
return this.value;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-27 14:51:45 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
