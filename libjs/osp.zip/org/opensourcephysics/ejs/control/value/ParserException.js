(function(){var P$=Clazz.newPackage("org.opensourcephysics.ejs.control.value"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ParserException", null, 'Exception');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['errorcode']]]

Clazz.newMeth(C$, 'c$$I', function (code) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.errorcode=code;
}, 1);

Clazz.newMeth(C$, 'c$$S', function (msg) {
;C$.superclazz.c$$S.apply(this,[msg]);C$.$init$.apply(this);
this.errorcode=-1;
}, 1);

Clazz.newMeth(C$, 'getErrorCode$', function () {
return this.errorcode;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-27 14:51:45 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
