(function(){var P$=Clazz.newPackage("org.opensourcephysics.numerics"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ODESolver");
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:14 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
