(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.mov"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "MovieVideoI");

C$.$fields$=[[]
,['S',['PROPERTY_VIDEO_PROGRESS','PROPERTY_VIDEO_STALLED']]]

C$.$static$=function(){C$.$static$=0;
C$.PROPERTY_VIDEO_PROGRESS="progress";
C$.PROPERTY_VIDEO_STALLED="stalled";
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:13 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
