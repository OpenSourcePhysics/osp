(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.mov"),I$=[[0,'org.opensourcephysics.media.core.MediaRes','org.opensourcephysics.media.mov.JSMovieVideo','java.io.File','org.opensourcephysics.controls.OSPLog']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSMovieVideoType", null, 'org.opensourcephysics.media.mov.MovieVideoType');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_media_core_VideoFileFilter',  function (filter) {
;C$.superclazz.c$$org_opensourcephysics_media_core_VideoFileFilter.apply(this,[filter]);C$.$init$.apply(this);
this.setRecordable$Z(false);
}, 1);

Clazz.newMeth(C$, 'getDescription$',  function () {
if (this.singleTypeFilter != null ) return this.singleTypeFilter.getDescription$();
return $I$(1).getString$S("JSVideoType.Description");
});

Clazz.newMeth(C$, 'isType$org_opensourcephysics_media_core_Video',  function (video) {
if (!(video.getClass$() === Clazz.getClass($I$(2)) )) return false;
if (this.singleTypeFilter == null ) return true;
var name=video.getProperty$S("name");
return this.singleTypeFilter.accept$java_io_File(Clazz.new_($I$(3,1).c$$S,[name]));
});

Clazz.newMeth(C$, 'getVideo$S',  function (name) {
return this.getVideo$S$S$org_opensourcephysics_controls_XMLControl(name, null, null);
});

Clazz.newMeth(C$, 'getVideo$S$S$org_opensourcephysics_controls_XMLControl',  function (name, basePath, control) {
var video=null;
try {
video=Clazz.new_($I$(2,1).c$$S$S,[name, basePath]);
if (video.getFrameNumber$() == -2147483648) {
video=null;
} else {
video.setProperty$S$O("video_type", this);
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
if (name != null ) {
$I$(4,"fine$S",[this.getDescription$() + ": " + e.getMessage$() ]);
}e.printStackTrace$();
} else {
throw e;
}
}
return video;
});

Clazz.newMeth(C$, 'getRecorder$',  function () {
$I$(4).warning$S("JSMovieVideoType unable to record");
return null;
});

Clazz.newMeth(C$, 'getTypeName$',  function () {
return "JS";
});
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:13 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
