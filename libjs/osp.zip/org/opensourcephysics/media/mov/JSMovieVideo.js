(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.mov"),p$1={},p$2={},I$=[[0,'swingjs.api.js.HTML5Video','java.util.Arrays',['javajs.async.SwingJSUtils','.StateHelper'],'swingjs.api.js.DOMNode','org.opensourcephysics.controls.OSPLog','java.util.ArrayList',['org.opensourcephysics.media.mov.JSMovieVideo','.State','.RateCalc'],'org.opensourcephysics.media.core.VideoIO','org.opensourcephysics.media.mov.JSMovieVideo','org.opensourcephysics.controls.XML','org.opensourcephysics.media.core.VideoFileFilter','org.opensourcephysics.media.mov.JSMovieVideoType','org.opensourcephysics.tools.ResourceLoader','java.awt.Frame','javax.swing.SwingUtilities','org.opensourcephysics.tools.Resource','java.net.URL','java.io.File',['org.opensourcephysics.media.mov.JSMovieVideo','.State'],'org.opensourcephysics.media.core.ImageCoordSystem','org.opensourcephysics.media.core.DoubleArray','javax.swing.JOptionPane',['org.opensourcephysics.media.mov.JSMovieVideo','.Loader']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JSMovieVideo", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.media.core.VideoAdapter', ['org.opensourcephysics.media.mov.MovieVideoI', 'org.opensourcephysics.media.core.AsyncVideoI']);
C$.$classes$=[['State',2],['Loader',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['frame','progress'],'S',['err','fileName'],'O',['state','org.opensourcephysics.media.mov.JSMovieVideo.State','frameTimesMillis','double[]','jsvideo','swingjs.api.js.HTML5Video','videoDialog','javax.swing.JDialog','url','java.net.URL']]
,['Z',['registered']]]

Clazz.newMeth(C$, 'getProperty$S',  function (name) {
return C$.superclazz.prototype.getProperty$S.apply(this, [name]);
});

Clazz.newMeth(C$, 'c$$S',  function (path) {
C$.c$$S$S.apply(this, [path, null]);
}, 1);

Clazz.newMeth(C$, 'c$$S$S',  function (name, basePath) {
Clazz.super_(C$, this);
var frames=$I$(14).getFrames$();
for (var i=0, n=frames.length; i < n; i++) {
if (frames[i].getName$().equals$O("Tracker")) {
this.addPropertyChangeListener$S$java_beans_PropertyChangeListener("progress", frames[i]);
this.addPropertyChangeListener$S$java_beans_PropertyChangeListener("stalled", frames[i]);
break;
}}
p$2.load$S$S.apply(this, [name, basePath]);
}, 1);

Clazz.newMeth(C$, 'play$',  function () {
if (this.getFrameCount$() == 1) {
return;
}var n=this.getFrameNumber$() + 1;
this.playing=true;
this.firePropertyChange$S$O$O("playing", null, Boolean.valueOf$Z(true));
p$2.startPlayingAtFrame$I.apply(this, [n]);
});

Clazz.newMeth(C$, 'stop$',  function () {
this.playing=false;
this.firePropertyChange$S$O$O("playing", null, Boolean.valueOf$Z(false));
});

Clazz.newMeth(C$, 'getImage$',  function () {
return (this.rawImage == null  ? null : C$.superclazz.prototype.getImage$.apply(this, []));
});

Clazz.newMeth(C$, 'setFrameNumber$I',  function (n) {
if (n < 0) {
this.frameNumber=n;
n=0;
}C$.superclazz.prototype.setFrameNumber$I.apply(this, [n]);
this.state.getImage$I(this.getFrameNumber$());
});

Clazz.newMeth(C$, 'setFrameNumberContinued$I$D',  function (n, t) {
var bi=$I$(1).getImage(this.jsvideo, 1);
if (bi == null ) return;
this.rawImage=bi;
this.invalidateVideoAndFilter$();
this.notifyFrame$I$Z(n, false);
this.firePropertyChange$S$O$O("asyncImageReady", null, Integer.valueOf$I(n));
if (this.isPlaying$()) {
$I$(15,"invokeLater$Runnable",[((P$.JSMovieVideo$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "JSMovieVideo$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () {
this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].continuePlaying$.apply(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'], []);
});
})()
), Clazz.new_(P$.JSMovieVideo$lambda1.$init$,[this, null]))]);
}});

Clazz.newMeth(C$, 'getFrameTime$I',  function (n) {
if ((n >= this.frameTimesMillis.length) || (n < 0) ) {
return -1;
}return this.frameTimesMillis[n];
});

Clazz.newMeth(C$, 'getTime$',  function () {
return this.getFrameTime$I(this.getFrameNumber$());
});

Clazz.newMeth(C$, 'setTime$D',  function (millis) {
millis=Math.abs(millis);
for (var i=0; i < this.frameTimesMillis.length; i++) {
var t=this.frameTimesMillis[i];
if (millis < t ) {
this.setFrameNumber$I(i - 1);
break;
}}
});

Clazz.newMeth(C$, 'getStartTime$',  function () {
return this.getFrameTime$I(this.getStartFrameNumber$());
});

Clazz.newMeth(C$, 'setStartTime$D',  function (millis) {
millis=Math.abs(millis);
for (var i=0; i < this.frameTimesMillis.length; i++) {
var t=this.frameTimesMillis[i];
if (millis < t ) {
this.setStartFrameNumber$I(i - 1);
break;
}}
});

Clazz.newMeth(C$, 'getEndTime$',  function () {
var n=this.getEndFrameNumber$();
if (n < this.getFrameCount$() - 1) return this.getFrameTime$I(n + 1);
return this.getDuration$();
});

Clazz.newMeth(C$, 'setEndTime$D',  function (millis) {
millis=Math.abs(millis);
millis=Math.min(this.getDuration$(), millis);
for (var i=0; i < this.frameTimesMillis.length; i++) {
var t=this.frameTimesMillis[i];
if (millis < t ) {
this.setEndFrameNumber$I(i - 1);
break;
}}
});

Clazz.newMeth(C$, 'getDuration$',  function () {
return this.jsvideo == null  ? -1 : $I$(1).getDuration(this.jsvideo) * 1000;
});

Clazz.newMeth(C$, 'isValid$',  function () {
return C$.superclazz.prototype.isValid$.apply(this, []);
});

Clazz.newMeth(C$, 'setRate$D',  function (rate) {
C$.superclazz.prototype.setRate$D.apply(this, [rate]);
if (this.isPlaying$()) {
p$2.startPlayingAtFrame$I.apply(this, [this.getFrameNumber$()]);
}});

Clazz.newMeth(C$, 'dispose$',  function () {
C$.superclazz.prototype.dispose$.apply(this, []);
$I$(4).dispose(this.jsvideo);
this.videoDialog.dispose$();
});

Clazz.newMeth(C$, 'startPlayingAtFrame$I',  function (frameNumber) {
this.setFrameNumber$I(frameNumber);
}, p$2);

Clazz.newMeth(C$, 'continuePlaying$',  function () {
var n=this.getFrameNumber$();
if (n < this.getEndFrameNumber$()) {
this.setFrameNumber$I(++n);
} else if (this.looping) {
p$2.startPlayingAtFrame$I.apply(this, [this.getStartFrameNumber$()]);
} else {
this.stop$();
}});

Clazz.newMeth(C$, 'load$S$S',  function (fileName, basePath) {
this.baseDir=basePath;
this.fileName=fileName;
var path=this.getAbsolutePath$S(fileName);
var res=($I$(13).isHTTP$S(path) ? Clazz.new_([Clazz.new_($I$(17,1).c$$S,[path])],$I$(16,1).c$$java_net_URL) : Clazz.new_([Clazz.new_($I$(18,1).c$$S,[path])],$I$(16,1).c$$java_io_File));
this.url=res.getURL$();
var isLocal=(this.url.getProtocol$().toLowerCase$().indexOf$S("file") >= 0);
path=isLocal ? res.getAbsolutePath$() : this.url.toExternalForm$();
$I$(5).finest$S("JSMovieVideo loading " + path + " local?: " + isLocal );
if (!$I$(8).checkMP4$S$org_opensourcephysics_tools_LibraryBrowser$org_opensourcephysics_media_core_VideoPanel(path, null, null)) {
this.frameNumber=-2147483648;
return;
}this.setProperty$S$O("name", $I$(10).getName$S(fileName));
this.setProperty$S$O("absolutePath", res.getAbsolutePath$());
if (fileName.indexOf$S(":") < 0) {
this.setProperty$S$O("path", $I$(10).forwardSlash$S(fileName));
} else {
this.setProperty$S$O("path", $I$(10).getRelativePath$S(fileName));
}this.firePropertyChange$S$O$O("progress", fileName, Integer.valueOf$I(0));
this.frame=0;
if (this.state == null ) this.state=Clazz.new_($I$(19,1),[this, null]);
this.state.load$S(path);
}, p$2);

Clazz.newMeth(C$, 'getTypeName$',  function () {
return "JS";
});

Clazz.newMeth(C$, 'setFrameCount$I',  function (n) {
C$.superclazz.prototype.setFrameCount$I.apply(this, [n]);
this.coords=Clazz.new_($I$(20,1).c$$I$org_opensourcephysics_media_core_Video,[this.frameCount, this]);
this.aspects=Clazz.new_($I$(21,1).c$$I$D,[this.frameCount, 1]);
});

Clazz.newMeth(C$, 'initializeMovie$java_util_ArrayList$D',  function (frameTimes, duration) {
this.videoDialog.setVisible$Z(false);
if (frameTimes.size$() == 0) {
this.firePropertyChange$S$O$O("progress", this.fileName, Integer.valueOf$I(this.frame));
this.dispose$();
this.err="no frames";
}this.setFrameCount$I(frameTimes.size$());
$I$(5,"debug$S",["JSMovieVideo " + this.size + "\n duration:" + new Double(duration).toString() + " act. frameCount:" + this.frameCount ]);
this.startFrameNumber=0;
this.endFrameNumber=this.frameCount - 1;
this.frameTimesMillis=Clazz.array(Double.TYPE, [this.frameCount]);
for (var i=0; i < this.frameTimesMillis.length; i++) {
this.frameTimesMillis[i]=frameTimes.get$I(i).doubleValue$() * 1000;
}
this.firePropertyChange$S$O$O("progress", this.fileName, Integer.valueOf$I(this.frame));
this.frameNumber=-1;
this.firePropertyChange$S$O$O("asyncVideoHaveFrames", null, this);
this.firePropertyChange$S$O$O("asyncVideoReady", this.fileName, this);
this.setFrameNumber$I(-99);
});

Clazz.newMeth(C$, 'cantRead$',  function () {
$I$(22).showMessageDialog$java_awt_Component$O(null, "Video file format or compression method could not be read.");
$I$(8).setCanceled$Z(true);
});

Clazz.newMeth(C$, 'getLoader$',  function () {
return Clazz.new_($I$(23,1));
}, 1);

Clazz.newMeth(C$, 'createThumbnailFile$java_awt_Dimension$S$S',  function (defaultThumbnailDimension, sourcePath, thumbPath) {
return null;
}, 1);

Clazz.newMeth(C$, 'getProgress$',  function () {
return this.progress;
});

Clazz.newMeth(C$, 'getLoadedFrameCount$',  function () {
return this.frame;
});

C$.$static$=function(){C$.$static$=0;
{
for (var ext, $ext = 0, $$ext = $I$(8).JS_VIDEO_EXTENSIONS; $ext<$$ext.length&&((ext=($$ext[$ext])),1);$ext++) {
var filter=Clazz.new_([ext, Clazz.array(String, -1, [ext])],$I$(11,1).c$$S$SA);
$I$(8,"addVideoType$org_opensourcephysics_media_core_VideoType",[Clazz.new_($I$(12,1).c$$org_opensourcephysics_media_core_VideoFileFilter,[filter])]);
$I$(13).addExtractExtension$S(ext);
}
C$.registered=true;
};
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.JSMovieVideo, "State", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, [['javajs.async.SwingJSUtils','javajs.async.SwingJSUtils.StateMachine']]);
C$.$classes$=[['RateCalc',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.dt=0;
this.offset=0;
this.lastT=-1;
this.onevent=((P$.JSMovieVideo$State$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "JSMovieVideo$State$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]]

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
switch (this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'].helper.getState$()) {
case 2:
this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'].helper.setState$I(3);
break;
case 40:
this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'].helper.setState$I(41);
break;
}
this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'].next$I.apply(this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'], [-2147483648]);
});
})()
), Clazz.new_(P$.JSMovieVideo$State$1.$init$,[this, null]));
this.thisFrame=-1;
this.debugging=false;
this.canSeek=true;
this.playThroughOrSeeked="canplaythrough";
},1);

C$.$fields$=[['Z',['debugging','canSeek'],'D',['t','dt','offset','lastT','duration'],'I',['thisFrame'],'S',['playThroughOrSeeked'],'O',['frameTimes','java.util.ArrayList','helper','javajs.async.SwingJSUtils.StateHelper','onevent','java.awt.event.ActionListener','readyListener','Object[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.helper=Clazz.new_($I$(3,1).c$$javajs_async_SwingJSUtils_StateMachine,[this]);
}, 1);

Clazz.newMeth(C$, 'next$I',  function (stateNext) {
this.helper.delayedState$I$I(10, stateNext);
});

Clazz.newMeth(C$, 'load$S',  function (path) {
this.helper.next$I(10);
});

Clazz.newMeth(C$, 'getImage$I',  function (n) {
if (this.thisFrame == n) return;
this.thisFrame=n;
this.t=this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].getFrameTime$I.apply(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'], [n]) / 1000.0;
this.next$I(20);
});

Clazz.newMeth(C$, 'dispose',  function () {
p$1.removeReadyListener.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'seekToNextFrame',  function () {
if (this.canSeek) {
try {
var next=((P$.JSMovieVideo$State$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "JSMovieVideo$State$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$',  function () {
this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'].next$I.apply(this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'], [3]);
});
})()
), Clazz.new_(P$.JSMovieVideo$State$2.$init$,[this, null]));
var f=function() {next.run$()} ||null;
this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].jsvideo.seekToNextFrame().then(f, null);
} catch (e) {
this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].err="JSMovieVideo cannot seek to next Frame";
e.printStackTrace$();
}
} else {
$I$(1,"setCurrentTime",[this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].jsvideo, this.offset + (this.t=this.t + this.dt)]);
}}, p$1);

Clazz.newMeth(C$, 'setReadyListener$S',  function (event) {
if (this.readyListener != null ) return;
this.readyListener=$I$(1).addActionListener(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].jsvideo, this.onevent, [event]);
if (this.debugging) {
System.out.println$S("Setting listener to " + event);
$I$(1,"addActionListener",[this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].jsvideo, ((P$.JSMovieVideo$State$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "JSMovieVideo$State$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
System.out.println$S("JSMovieVideo.actionPerformed " + e.getActionCommand$());
});
})()
), Clazz.new_(P$.JSMovieVideo$State$3.$init$,[this, null])), []]);
}}, p$1);

Clazz.newMeth(C$, 'removeReadyListener',  function () {
$I$(1).removeActionListener(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].jsvideo, this.readyListener);
this.readyListener=null;
}, p$1);

Clazz.newMeth(C$, 'stateLoop$',  function () {
var v=this.b$['org.opensourcephysics.media.mov.JSMovieVideo'];
while (this.helper.isAlive$()){
switch (v.err == null  ? this.helper.getState$() : -99) {
case -1:
return false;
case 10:
v.videoDialog=$I$(1,"createDialog",[null, v.url, 500, false, ((P$.JSMovieVideo$State$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "JSMovieVideo$State$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['apply$swingjs_api_js_HTML5Video','apply$O'],  function (video) {
this.$finals$.v.jsvideo=video;
this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'].canSeek=($I$(4).getAttr(this.$finals$.v.jsvideo, "seekToNextFrame") != null );
if (!this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'].canSeek) this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'].playThroughOrSeeked="seeked";
this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'].next$I.apply(this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'], [12]);
return null;
});
})()
), Clazz.new_(P$.JSMovieVideo$State$4.$init$,[this, {v:v}]))]);
return true;
case 12:
v.videoDialog.setVisible$Z(true);
var d=$I$(1).getSize(v.jsvideo);
v.size.width=d.width;
v.size.height=d.height;
this.duration=$I$(1).getDuration(v.jsvideo);
var n=$I$(1).getFrameCount(v.jsvideo);
v.setFrameCount$I(n);
$I$(5,"finer$S",["JSMovieVideo " + v.size + "\n duration:" + new Double(this.duration).toString() + " est. v.frameCount:" + n ]);
if (v.size.width == 0) {
this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].cantRead$.apply(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'], []);
this.helper.next$I(3);
} else {
this.helper.next$I(this.canSeek ? 0 : 40);
}continue;
case 40:
p$1.setReadyListener$S.apply(this, ["ended"]);
try {
v.jsvideo.play();
} catch (e) {
e.printStackTrace$();
}
return false;
case 41:
p$1.removeReadyListener.apply(this, []);
this.helper.setState$I(0);
$I$(1).setCurrentTime(v.jsvideo, 0);
continue;
case 0:
v.err=null;
this.duration=$I$(1).getDuration(v.jsvideo);
this.t=0.0;
this.dt=0;
this.frameTimes=Clazz.new_($I$(6,1));
this.frameTimes.add$O(Double.valueOf$D(this.t));
if (!this.canSeek) {
this.helper.setState$I(2);
Clazz.new_($I$(7,1),[this, null]).getRate$I$java_util_function_Function(2, ((P$.JSMovieVideo$State$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "JSMovieVideo$State$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['apply$DA','apply$O'],  function (times) {
this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'].setTimes$DA.apply(this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'], [times]);
return null;
});
})()
), Clazz.new_(P$.JSMovieVideo$State$5.$init$,[this, null])));
return false;
}p$1.setReadyListener$S.apply(this, [this.playThroughOrSeeked]);
this.helper.setState$I(1);
continue;
case 1:
if (this.t >= this.duration ) {
this.helper.setState$I(99);
continue;
}this.helper.setState$I(2);
p$1.seekToNextFrame.apply(this, []);
return false;
case 2:
return false;
case 3:
if ($I$(8).isCanceled$()) {
v.firePropertyChange$S$O$O("progress", v.fileName, null);
p$1.dispose.apply(this, []);
v.err="Canceled by user";
this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].progress=-999;
return false;
}this.t=$I$(1).getCurrentTime(v.jsvideo);
if (this.t > this.lastT ) {
this.lastT=this.t;
this.frameTimes.add$O(Double.valueOf$D(this.t));
v.firePropertyChange$S$O$O("progress", v.fileName, Integer.valueOf$I(v.frame++));
this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].progress=$I$(8).progressForFraction$D$D(v.frame, v.frameCount);
}this.helper.setState$I(1);
continue;
case 99:
this.helper.setState$I(-1);
v.initializeMovie$java_util_ArrayList$D(this.frameTimes, this.duration);
this.frameTimes=null;
this.thisFrame=-1;
this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].progress=80;
continue;
case 20:
this.helper.setState$I(22);
p$1.setReadyListener$S.apply(this, [this.playThroughOrSeeked]);
$I$(1).setCurrentTime(v.jsvideo, this.offset + this.t);
return true;
case 22:
v.setFrameNumberContinued$I$D(this.thisFrame, this.t);
return false;
}
return false;
}
return false;
});

Clazz.newMeth(C$, 'setTimes$DA',  function (times) {
if (times == null ) {
this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].cantRead$.apply(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'], []);
this.next$I(99);
} else {
this.dt=times[1];
this.offset=times[0] - this.dt / 2;
var t=0;
var nFrames=(((this.duration - times[0]) / this.dt + 1.0E-4)|0) + 1;
for (var i=nFrames; --i >= 0; ) {
t+=this.dt;
this.frameTimes.add$O(Double.valueOf$D(t));
}
this.next$I(99);
this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].frame=nFrames;
}});
;
(function(){/*c*/var C$=Clazz.newClass(P$.JSMovieVideo.State, "RateCalc", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.ActionListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.curTime0=0;
this.curTime=0;
this.ds=0.01;
this.tolerance=1.0E-5;
this.frameDur=0;
this.expanding=true;
},1);

C$.$fields$=[['Z',['expanding'],'D',['curTime0','curTime','ds','tolerance','frameDur'],'I',['pt'],'O',['results','double[]','whenDone','java.util.function.Function','buffer','byte[]','+buffer0','listener','Object[]']]]

Clazz.newMeth(C$, 'getRate$I$java_util_function_Function',  function (n, whenDone) {
this.results=Clazz.array(Double.TYPE, [n]);
this.whenDone=whenDone;
this.pt=0;
this.buffer=null;
this.expanding=true;
this.curTime0=this.curTime=$I$(1).getCurrentTime(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].jsvideo);
this.ds=this.frameDur / 2 + 0.001;
this.frameDur=0;
this.listener=$I$(1).addActionListener(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].jsvideo, this, [this.b$['org.opensourcephysics.media.mov.JSMovieVideo.State'].playThroughOrSeeked]);
$I$(1).setCurrentTime(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].jsvideo, this.curTime);
});

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
var img=$I$(1).getImage(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].jsvideo, -2147483648);
if (img == null ) {
this.whenDone.apply$O(null);
return;
}var b=(img.getRaster$().getDataBuffer$()).getData$();
if (this.buffer == null ) {
this.buffer=Clazz.array(Byte.TYPE, [img.getWidth$() * img.getHeight$() * 4 ]);
}System.arraycopy$O$I$O$I$I(b, 0, this.buffer, 0, b.length);
if (this.buffer0 == null ) {
this.buffer0=Clazz.array(Byte.TYPE, [img.getWidth$() * img.getHeight$() * 4 ]);
System.arraycopy$O$I$O$I$I(this.buffer, 0, this.buffer0, 0, this.buffer.length);
} else {
if ($I$(2).equals$BA$BA(this.buffer, this.buffer0)) {
if (this.expanding) {
this.ds*=1.4;
}} else if (this.ds < 0  || Math.abs(this.ds) >= this.tolerance  ) {
this.expanding=false;
this.ds/=-2;
this.buffer0=this.buffer;
this.buffer=null;
} else {
this.buffer=this.buffer0=null;
this.frameDur=this.curTime - this.curTime0;
this.curTime0=this.curTime;
this.results[this.pt++]=this.frameDur;
if (this.pt < this.results.length) {
this.ds=this.frameDur / 2;
} else {
$I$(1).removeActionListener(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].jsvideo, this.listener);
this.whenDone.apply$O(this.results);
return;
}}}this.curTime+=this.ds;
$I$(1).setCurrentTime(this.b$['org.opensourcephysics.media.mov.JSMovieVideo'].jsvideo, this.curTime);
});

Clazz.newMeth(C$);
})()
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.JSMovieVideo, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, ['org.opensourcephysics.media.core.VideoAdapter','.Loader']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'createVideo$S',  function (path) {
var video=Clazz.new_($I$(9,1).c$$S,[path]);
if (video.getFrameNumber$() == -2147483648) return null;
var ext=$I$(10).getExtension$S(path);
var VideoType=$I$(8).getMovieType$S(ext);
if (VideoType != null ) video.setProperty$S$O("video_type", VideoType);
return video;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:13 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
