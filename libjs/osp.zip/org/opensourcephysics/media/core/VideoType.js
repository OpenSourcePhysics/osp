(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "VideoType");
C$.$defaults$ = function(C$){

Clazz.newMeth(C$, 'accepts$java_io_File',  function (file) {
var filters=this.getFileFilters$();
for (var i=filters.length; --i >= 0; ) if (filters[i].accept$java_io_File(file)) return true;

return false;
});

Clazz.newMeth(C$, '_toString$',  function () {
var s="";
for (var f, $f = 0, $$f = this.getFileFilters$(); $f<$$f.length&&((f=($$f[$f])),1);$f++) {
s+=" " + f;
}
return "[" + this.getTypeName$() + " " + s + "]" ;
});
};})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:13 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
