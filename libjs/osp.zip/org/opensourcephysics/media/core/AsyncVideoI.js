(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "AsyncVideoI");

C$.$fields$=[[]
,['S',['PROPERTY_ASYNCVIDEOI_HAVEFRAMES','PROPERTY_ASYNCVIDEOI_READY','PROPERTY_ASYNCVIDEOI_IMAGEREADY']]]

C$.$static$=function(){C$.$static$=0;
C$.PROPERTY_ASYNCVIDEOI_HAVEFRAMES="asyncVideoHaveFrames";
C$.PROPERTY_ASYNCVIDEOI_READY="asyncVideoReady";
C$.PROPERTY_ASYNCVIDEOI_IMAGEREADY="asyncImageReady";
};
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:10 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
