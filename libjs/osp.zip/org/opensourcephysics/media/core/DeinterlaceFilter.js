(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'org.opensourcephysics.media.core.MediaRes','java.awt.Toolkit','javax.swing.JRadioButton','javax.swing.ButtonGroup','javax.swing.JPanel','java.awt.FlowLayout','java.awt.BorderLayout','org.opensourcephysics.media.core.DeinterlaceFilter',['org.opensourcephysics.media.core.DeinterlaceFilter','.Inspector'],'javax.swing.JOptionPane','java.awt.image.BufferedImage',['org.opensourcephysics.media.core.DeinterlaceFilter','.Loader']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DeinterlaceFilter", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.media.core.Filter');
C$.$classes$=[['Inspector',2],['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isOdd'],'O',['pixels','int[]','inspector','org.opensourcephysics.media.core.DeinterlaceFilter.Inspector','odd','javax.swing.JRadioButton','+even']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.hasInspector=true;
}, 1);

Clazz.newMeth(C$, 'setOdd$Z', function (odd) {
var prev=this.isOdd;
this.isOdd=odd;
this.support.firePropertyChange$S$Z$Z("odd", prev, odd);
});

Clazz.newMeth(C$, 'isOdd$', function () {
return this.isOdd;
});

Clazz.newMeth(C$, 'getFilteredImage$java_awt_image_BufferedImage', function (sourceImage) {
if (!this.isEnabled$()) {
return sourceImage;
}if (sourceImage !== this.source ) {
p$1.initialize$java_awt_image_BufferedImage.apply(this, [sourceImage]);
}if (sourceImage !== this.input ) {
this.gIn.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.source, 0, 0, null);
}p$1.setOutputToField.apply(this, []);
return this.output;
});

Clazz.newMeth(C$, 'getInspector$', function () {
var myInspector=this.inspector;
if (myInspector == null ) {
myInspector=Clazz.new_($I$(9,1),[this, null]);
}if (myInspector.isModal$() && this.vidPanel != null  ) {
this.frame=$I$(10).getFrameForComponent$java_awt_Component(this.vidPanel);
myInspector.setVisible$Z(false);
myInspector.dispose$();
myInspector=Clazz.new_($I$(9,1),[this, null]);
}this.inspector=myInspector;
this.inspector.initialize$();
return this.inspector;
});

Clazz.newMeth(C$, 'refresh$', function () {
C$.superclazz.prototype.refresh$.apply(this, []);
this.odd.setText$S($I$(1).getString$S("Filter.Deinterlace.Button.Odd"));
this.even.setText$S($I$(1).getString$S("Filter.Deinterlace.Button.Even"));
if (this.inspector != null ) {
this.inspector.setTitle$S($I$(1).getString$S("Filter.Deinterlace.Title"));
this.inspector.pack$();
}var enabled=this.isEnabled$();
this.odd.setEnabled$Z(enabled);
this.even.setEnabled$Z(enabled);
});

Clazz.newMeth(C$, 'initialize$java_awt_image_BufferedImage', function (image) {
this.source=image;
this.w=this.source.getWidth$();
this.h=this.source.getHeight$();
this.pixels=Clazz.array(Integer.TYPE, [this.w * this.h]);
this.output=Clazz.new_($I$(11,1).c$$I$I$I,[this.w, this.h, 1]);
if (this.source.getType$() == 1) {
this.input=this.source;
} else {
this.input=Clazz.new_($I$(11,1).c$$I$I$I,[this.w, this.h, 1]);
this.gIn=this.input.createGraphics$();
}}, p$1);

Clazz.newMeth(C$, 'setOutputToField', function () {
this.input.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
if (this.h % 2 != 0) {
this.h=this.h - 1;
}for (var i=0; i < (this.h/2|0) - 1; i++) {
for (var j=0; j < this.w; j++) {
if (this.isOdd) {
this.pixels[this.w * 2 * i  + j]=this.pixels[this.w * (2 * i + 1) + j];
} else {
this.pixels[this.w * (2 * i + 1) + j]=this.pixels[this.w * 2 * i  + j];
}}
}
this.output.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(12,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.DeinterlaceFilter, "Inspector", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['group','javax.swing.ButtonGroup']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$java_awt_Frame$Z.apply(this,[this.this$0.frame, !(Clazz.instanceOf(this.this$0.frame, "org.opensourcephysics.display.OSPFrame"))]);C$.$init$.apply(this);
this.setTitle$S($I$(1).getString$S("Filter.Deinterlace.Title"));
this.setResizable$Z(false);
this.createGUI$();
this.initialize$();
this.this$0.refresh$.apply(this.this$0, []);
this.pack$();
var rect=this.getBounds$();
var dim=$I$(2).getDefaultToolkit$().getScreenSize$();
var x=((dim.width - rect.width)/2|0);
var y=((dim.height - rect.height)/2|0);
this.setLocation$I$I(x, y);
}, 1);

Clazz.newMeth(C$, 'createGUI$', function () {
this.this$0.odd=Clazz.new_($I$(3,1));
this.this$0.even=Clazz.new_($I$(3,1));
this.group=Clazz.new_($I$(4,1));
this.group.add$javax_swing_AbstractButton(this.this$0.odd);
this.group.add$javax_swing_AbstractButton(this.this$0.even);
var select=((P$.DeinterlaceFilter$Inspector$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "DeinterlaceFilter$Inspector$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.DeinterlaceFilter'].setOdd$Z.apply(this.b$['org.opensourcephysics.media.core.DeinterlaceFilter'], [this.b$['org.opensourcephysics.media.core.DeinterlaceFilter.Inspector'].group.isSelected$javax_swing_ButtonModel(this.b$['org.opensourcephysics.media.core.DeinterlaceFilter'].odd.getModel$())]);
});
})()
), Clazz.new_(P$.DeinterlaceFilter$Inspector$1.$init$,[this, null]));
this.this$0.even.addActionListener$java_awt_event_ActionListener(select);
this.this$0.odd.addActionListener$java_awt_event_ActionListener(select);
var panel=Clazz.new_([Clazz.new_($I$(6,1))],$I$(5,1).c$$java_awt_LayoutManager);
panel.add$java_awt_Component(this.this$0.odd);
panel.add$java_awt_Component(this.this$0.even);
var buttonbar=Clazz.new_([Clazz.new_($I$(6,1))],$I$(5,1).c$$java_awt_LayoutManager);
buttonbar.add$java_awt_Component(this.this$0.ableButton);
buttonbar.add$java_awt_Component(this.this$0.closeButton);
var contentPane=Clazz.new_([Clazz.new_($I$(7,1))],$I$(5,1).c$$java_awt_LayoutManager);
this.setContentPane$java_awt_Container(contentPane);
contentPane.add$java_awt_Component$O(panel, "Center");
contentPane.add$java_awt_Component$O(buttonbar, "South");
});

Clazz.newMeth(C$, 'initialize$', function () {
this.updateDisplay$();
});

Clazz.newMeth(C$, 'updateDisplay$', function () {
if (this.this$0.isOdd) {
this.group.setSelected$javax_swing_ButtonModel$Z(this.this$0.odd.getModel$(), true);
} else {
this.group.setSelected$javax_swing_ButtonModel$Z(this.this$0.even.getModel$(), true);
}});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DeinterlaceFilter, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
if (filter.isOdd$()) {
control.setValue$S$O("field", "odd");
} else {
control.setValue$S$O("field", "even");
}if ((filter.frame != null ) && (filter.inspector != null ) && filter.inspector.isVisible$()  ) {
var x=filter.inspector.getLocation$().x - filter.frame.getLocation$().x;
var y=filter.inspector.getLocation$().y - filter.frame.getLocation$().y;
control.setValue$S$I("inspector_x", x);
control.setValue$S$I("inspector_y", y);
}});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(8,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
if (control.getPropertyNames$().contains$O("field")) {
if (control.getString$S("field").equals$O("odd")) {
filter.setOdd$Z(true);
} else {
filter.setOdd$Z(false);
}}filter.inspectorX=control.getInt$S("inspector_x");
filter.inspectorY=control.getInt$S("inspector_y");
return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-31 17:30:11 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
