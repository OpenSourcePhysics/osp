(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Video", null, null, ['org.opensourcephysics.media.core.InteractiveImage', 'org.opensourcephysics.media.core.Trackable', 'java.beans.PropertyChangeListener']);

C$.$clinit$=2;
C$.$defaults$ = function(C$){

Clazz.newMeth(C$, 'removeListener$java_beans_PropertyChangeListener',  function (c) {
this.removePropertyChangeListener$S$java_beans_PropertyChangeListener("coords", c);
this.removePropertyChangeListener$S$java_beans_PropertyChangeListener("filterChanged", c);
this.removePropertyChangeListener$S$java_beans_PropertyChangeListener("image", c);
this.removePropertyChangeListener$S$java_beans_PropertyChangeListener("size", c);
this.removePropertyChangeListener$S$java_beans_PropertyChangeListener("videoVisible", c);
});

Clazz.newMeth(C$, 'addListener$java_beans_PropertyChangeListener',  function (c) {
this.addPropertyChangeListener$S$java_beans_PropertyChangeListener("coords", c);
this.addPropertyChangeListener$S$java_beans_PropertyChangeListener("filterChanged", c);
this.addPropertyChangeListener$S$java_beans_PropertyChangeListener("image", c);
this.addPropertyChangeListener$S$java_beans_PropertyChangeListener("size", c);
this.addPropertyChangeListener$S$java_beans_PropertyChangeListener("videoVisible", c);
});

Clazz.newMeth(C$, 'isValid$',  function () {
return this.getDuration$() > 0 ;
});
};})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:12 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
