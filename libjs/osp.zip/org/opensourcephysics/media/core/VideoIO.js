(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'javax.swing.ButtonGroup','java.util.HashMap','javax.swing.BoxLayout','javax.swing.BorderFactory','org.opensourcephysics.media.core.MediaRes','org.opensourcephysics.media.core.VideoIO','javax.swing.JPanel','javax.swing.JRadioButton','org.opensourcephysics.controls.OSPLog','org.opensourcephysics.controls.XML','org.opensourcephysics.media.core.VideoFileFilter','java.util.TreeSet','java.util.ArrayList','org.opensourcephysics.media.core.ImageVideoType','javax.swing.filechooser.FileFilter',['org.opensourcephysics.media.core.VideoIO','.VideoEnginePanel'],'org.opensourcephysics.display.OSPRuntime','java.io.File','javax.swing.JFileChooser','org.opensourcephysics.tools.FontSizer','org.opensourcephysics.tools.DiagnosticsForXuggle','java.io.FileInputStream','java.io.FileOutputStream','org.opensourcephysics.media.core.VideoType','java.awt.BorderLayout','javax.swing.JTextArea','javax.swing.JOptionPane','org.opensourcephysics.media.core.ImageVideo','org.opensourcephysics.controls.XMLControlElement','org.opensourcephysics.tools.ResourceLoader','org.opensourcephysics.media.core.VideoPanel','javax.imageio.ImageIO']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VideoIO", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['StreamPiper',9],['VideoEnginePanel',12]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['Z',['canceled'],'S',['defaultXMLExt','videoEngine','preferredExportExtension'],'O',['VIDEO_EXTENSIONS','String[]','chooser','javax.swing.JFileChooser','videoFileFilter','org.opensourcephysics.media.core.VideoFileFilter','singleVideoTypeFilters','java.util.Collection','imageFileFilter','javax.swing.filechooser.FileFilter','videoTypes','java.util.ArrayList','+videoEngines','videoEnginePanel','org.opensourcephysics.media.core.VideoIO.VideoEnginePanel']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getExtension$java_io_File', function (file) {
return $I$(10,"getExtension$S",[file.getName$()]);
}, 1);

Clazz.newMeth(C$, 'getChooser$', function () {
if (C$.chooser == null ) {
var dir=($I$(17).chooserDir == null ) ? Clazz.new_([$I$(17).getUserHome$()],$I$(18,1).c$$S) : Clazz.new_([$I$(17).chooserDir],$I$(18,1).c$$S);
C$.chooser=Clazz.new_($I$(19,1).c$$java_io_File,[dir]);
C$.chooser.addPropertyChangeListener$java_beans_PropertyChangeListener(C$.videoEnginePanel);
}$I$(20,"setFonts$O$I",[C$.chooser, $I$(20).getLevel$()]);
return C$.chooser;
}, 1);

Clazz.newMeth(C$, 'setDefaultXMLExtension$S', function (ext) {
C$.defaultXMLExt=ext;
}, 1);

Clazz.newMeth(C$, 'getRelativePath$S', function (absolutePath) {
if ((absolutePath.indexOf$S("/") == -1) && (absolutePath.indexOf$S("\\") == -1) ) {
return absolutePath;
}if (absolutePath.startsWith$S("http:")) {
return absolutePath;
}var path=absolutePath;
var relativePath="";
var validPath=false;
var base=System.getProperty$S("user.dir");
if (base == null ) {
return path;
}for (var j=0; j < 3; j++) {
if (j > 0) {
var k=base.lastIndexOf$S("\\");
if (k == -1) {
k=base.lastIndexOf$S("/");
}if (k != -1) {
base=base.substring$I$I(0, k);
relativePath += "../";
} else {
break;
}}if (path.startsWith$S(base)) {
path=path.substring$I(base.length$() + 1);
var i=path.indexOf$S("\\");
while (i != -1){
path=path.substring$I$I(0, i) + "/" + path.substring$I(i + 1) ;
i=path.indexOf$S("\\");
}
relativePath += path;
validPath=true;
break;
}}
if (validPath) {
return relativePath;
}return path;
}, 1);

Clazz.newMeth(C$, 'isEngineInstalled$S', function (engine) {
if (engine.equals$O("Xuggle")) {
return $I$(21).getXuggleJar$() != null ;
}return false;
}, 1);

Clazz.newMeth(C$, 'getEngine$', function () {
if (C$.videoEngine == null ) {
C$.videoEngine=C$.getDefaultEngine$();
}return C$.videoEngine;
}, 1);

Clazz.newMeth(C$, 'setEngine$S', function (engine) {
if (engine == null  || (!engine.equals$O("Xuggle") && !engine.equals$O("none") ) ) return;
C$.videoEngine=engine;
}, 1);

Clazz.newMeth(C$, 'getDefaultEngine$', function () {
var engine="none";
var xuggleVersion=0;
for (var next, $next = C$.videoEngines.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
if (next.getClass$().getSimpleName$().contains$CharSequence("Xuggle")) {
xuggleVersion=$I$(21).guessXuggleVersion$();
}}
if (xuggleVersion == 3.4 ) engine="Xuggle";
return engine;
}, 1);

Clazz.newMeth(C$, 'testExec$', function () {
}, 1);

Clazz.newMeth(C$, 'copyFile$java_io_File$java_io_File', function (inFile, outFile) {
var buffer=Clazz.array(Byte.TYPE, [100000]);
try {
var $in=Clazz.new_($I$(22,1).c$$java_io_File,[inFile]);
var out=Clazz.new_($I$(23,1).c$$java_io_File,[outFile]);
while (true){
{
var amountRead=$in.read$BA(buffer);
if (amountRead == -1) {
break;
}out.write$BA$I$I(buffer, 0, amountRead);
}}
$in.close$();
out.close$();
outFile.setLastModified$J(inFile.lastModified$());
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
return false;
} else {
throw ex;
}
}
return true;
}, 1);

Clazz.newMeth(C$, 'getVideoExtensions$', function () {
return C$.videoFileFilter.getExtensions$();
}, 1);

Clazz.newMeth(C$, 'getPreferredExportExtension$', function () {
return C$.preferredExportExtension;
}, 1);

Clazz.newMeth(C$, 'setPreferredExportExtension$S', function (extension) {
if (extension != null  && extension.length$() > 1 ) C$.preferredExportExtension=extension;
}, 1);

Clazz.newMeth(C$, 'addVideoType$org_opensourcephysics_media_core_VideoType', function (type) {
if (type != null ) {
var hasType=false;
for (var next, $next = C$.videoTypes.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
if (next.getDescription$().equals$O(type.getDescription$()) && next.getClass$() === type.getClass$()  ) {
hasType=true;
}}
if (!hasType) {
C$.videoTypes.add$O(type);
var filter=type.getDefaultFileFilter$();
if (filter != null  && filter.extensions != null  ) {
C$.singleVideoTypeFilters.add$O(filter);
}}}}, 1);

Clazz.newMeth(C$, 'addVideoEngine$org_opensourcephysics_media_core_VideoType', function (engine) {
if (engine != null ) {
$I$(9,"finest$S",[engine.getClass$().getSimpleName$() + " " + engine.getDefaultExtension$() ]);
var hasType=false;
for (var next, $next = C$.videoEngines.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
if (next.getClass$() === engine.getClass$() ) {
hasType=true;
}}
if (!hasType) {
C$.videoEngines.add$O(engine);
C$.videoEnginePanel.addVideoEngine$org_opensourcephysics_media_core_VideoType(engine);
}}}, 1);

Clazz.newMeth(C$, 'getVideoType$S$S', function (className, extension) {
if (className == null  && extension == null  ) return null;
var candidates=Clazz.new_($I$(13,1));
{
if (className == null ) {
candidates.addAll$java_util_Collection(C$.videoTypes);
} else {
className=className.toLowerCase$();
for (var next, $next = C$.videoTypes.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
var name=next.getClass$().getSimpleName$().toLowerCase$();
if (name.indexOf$S(className) > -1) candidates.add$O(next);
}
}if (extension == null ) {
if (candidates.isEmpty$()) return null;
return candidates.get$I(0);
}extension=extension.toLowerCase$();
for (var next, $next = candidates.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
var id=next.getDefaultExtension$();
if (id != null  && id.indexOf$S(extension) > -1 ) return next;
}
for (var next, $next = candidates.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
var filters=next.getFileFilters$();
for (var filter, $filter = 0, $$filter = filters; $filter<$$filter.length&&((filter=($$filter[$filter])),1);$filter++) {
if (filter.extensions != null ) {
for (var s, $s = 0, $$s = filter.extensions; $s<$$s.length&&((s=($$s[$s])),1);$s++) if (s.indexOf$S(extension) > -1) return next;

}}
}
}return null;
}, 1);

Clazz.newMeth(C$, 'getVideoTypesForExtension$S', function (ext) {
ext=ext.toLowerCase$();
var found=Clazz.new_($I$(13,1));
var vidTypes=C$.getVideoTypes$();
for (var next, $next = 0, $$next = vidTypes; $next<$$next.length&&((next=($$next[$next])),1);$next++) {
var id=next.getDefaultExtension$();
if (id != null  && id.indexOf$S(ext) > -1 ) found.add$O(next);
}
for (var next, $next = 0, $$next = vidTypes; $next<$$next.length&&((next=($$next[$next])),1);$next++) {
var filters=next.getFileFilters$();
for (var filter, $filter = 0, $$filter = filters; $filter<$$filter.length&&((filter=($$filter[$filter])),1);$filter++) {
if (filter.extensions != null ) {
for (var s, $s = 0, $$s = filter.extensions; $s<$$s.length&&((s=($$s[$s])),1);$s++) if (s.indexOf$S(ext) > -1 && !found.contains$O(next) ) found.add$O(next);

}}
}
return found.toArray$OA(Clazz.array($I$(24), [0]));
}, 1);

Clazz.newMeth(C$, 'getVideoTypes$', function () {
return C$.getVideoTypesForEngine$S(C$.getEngine$());
}, 1);

Clazz.newMeth(C$, 'getVideoTypesForEngine$S', function (engine) {
var available=Clazz.new_($I$(13,1));
var skipXuggle=C$.getEngine$().equals$O("none");
for (var next, $next = C$.videoTypes.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
var typeName=next.getClass$().getSimpleName$();
if (skipXuggle && typeName.contains$CharSequence("Xuggle") ) continue;
available.add$O(next);
}
return available.toArray$OA(Clazz.array($I$(24), [0]));
}, 1);

Clazz.newMeth(C$, 'setCanceled$Z', function (cancel) {
C$.canceled=cancel;
}, 1);

Clazz.newMeth(C$, 'isCanceled$', function () {
return C$.canceled;
}, 1);

Clazz.newMeth(C$, 'getVideo$S$org_opensourcephysics_media_core_VideoType', function (path, vidType) {
$I$(9).fine$S("path: " + path + " type: " + vidType );
var video=null;
C$.setCanceled$Z(false);
if (vidType != null ) {
$I$(9,"finest$S",["requested type " + vidType.getClass$().getSimpleName$() + " " + vidType.getDescription$() ]);
video=vidType.getVideo$S(path);
if (video != null ) return video;
}if (C$.isCanceled$()) return null;
var extension=$I$(10).getExtension$S(path);
var allTypes=C$.getVideoTypesForExtension$S(extension);
var allowedTypes=Clazz.new_($I$(13,1));
var skipXuggle=C$.getEngine$().equals$O("none");
for (var i=0; i < allTypes.length; i++) {
var typeName=allTypes[i].getClass$().getSimpleName$();
if (skipXuggle && typeName.contains$CharSequence("Xuggle") ) continue;
allowedTypes.add$O(allTypes[i]);
}
for (var next, $next = allowedTypes.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
$I$(9,"finest$S",["preferred type " + next.getClass$().getSimpleName$() + " " + next.getDescription$() ]);
video=next.getVideo$S(path);
if (C$.isCanceled$()) return null;
if (video != null ) return video;
}
return null;
}, 1);

Clazz.newMeth(C$, 'getVideo$S$java_util_ArrayList$javax_swing_JComponent$javax_swing_JFrame', function (path, engines, component, frame) {
var engine=C$.getEngine$();
engine="none".equals$O(engine) ? $I$(5).getString$S("VideoIO.Engine.None") : $I$(5).getString$S("XuggleVideoType.Description");
var message=$I$(5).getString$S("VideoIO.Dialog.TryDifferentEngine.Message1") + " (" + engine + ")." ;
message += "\n" + $I$(5).getString$S("VideoIO.Dialog.TryDifferentEngine.Message2");
message += "\n\n" + $I$(5).getString$S("VideoIO.Dialog.Label.Path") + ": " + path ;
var optionList=Clazz.new_($I$(13,1));
for (var next, $next = engines.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
if (next.getClass$().getSimpleName$().equals$O("XuggleVideoType")) {
optionList.add$O($I$(5).getString$S("XuggleVideoType.Description"));
}}
optionList.add$O($I$(5).getString$S("Dialog.Button.Cancel"));
var options=optionList.toArray$OA(Clazz.array(String, [optionList.size$()]));
var messagePanel=Clazz.new_([Clazz.new_($I$(25,1))],$I$(7,1).c$$java_awt_LayoutManager);
var textArea=Clazz.new_($I$(26,1));
textArea.setText$S(message);
textArea.setOpaque$Z(false);
textArea.setBorder$javax_swing_border_Border($I$(4).createEmptyBorder$I$I$I$I(4, 0, 4, 4));
messagePanel.add$java_awt_Component$O(textArea, "North");
if (component != null ) {
component.setBorder$javax_swing_border_Border($I$(4).createEmptyBorder$I$I$I$I(12, 0, 12, 0));
messagePanel.add$java_awt_Component$O(component, "South");
}var response=$I$(27,"showOptionDialog$java_awt_Component$O$S$I$I$javax_swing_Icon$OA$O",[frame, messagePanel, $I$(5).getString$S("VideoClip.Dialog.BadVideo.Title"), 1, 2, null, options, options[0]]);
if (response >= 0 && response < options.length - 1 ) {
var desiredType=engines.get$I(response);
var video=C$.getVideo$S$org_opensourcephysics_media_core_VideoType(path, desiredType);
if (video == null  && !C$.isCanceled$() ) {
$I$(27,"showMessageDialog$java_awt_Component$O$S$I",[frame, $I$(5).getString$S("VideoIO.Dialog.BadVideo.Message") + "\n\n" + path , $I$(5).getString$S("VideoClip.Dialog.BadVideo.Title"), 2]);
}return video;
}return null;
}, 1);

Clazz.newMeth(C$, 'clone$org_opensourcephysics_media_core_Video', function (video) {
if (video == null ) {
return null;
}if (Clazz.instanceOf(video, "org.opensourcephysics.media.core.ImageVideo")) {
var oldVid=video;
var newVid=Clazz.new_([oldVid.getImages$()],$I$(28,1).c$$java_awt_ImageA);
newVid.rawImage=newVid.images[0];
var filters=video.getFilterStack$().getFilters$();
if (filters != null ) {
var it=filters.iterator$();
while (it.hasNext$()){
var filter=it.next$();
newVid.getFilterStack$().addFilter$org_opensourcephysics_media_core_Filter(filter);
}
}return newVid;
}var control=Clazz.new_($I$(29,1).c$$O,[video]);
return Clazz.new_($I$(29,1).c$$org_opensourcephysics_controls_XMLControl,[control]).loadObject$O(null);
}, 1);

Clazz.newMeth(C$, 'open$org_opensourcephysics_media_core_VideoPanel', function (vidPanel) {
return C$.open$java_io_File$org_opensourcephysics_media_core_VideoPanel(null, vidPanel);
}, 1);

Clazz.newMeth(C$, 'getChooserFiles$S', function (type) {
var chooser=C$.getChooser$();
chooser.setMultiSelectionEnabled$Z(false);
chooser.setAcceptAllFileFilterUsed$Z(true);
var result=1;
if (type.toLowerCase$().equals$O("open")) {
chooser.addChoosableFileFilter$javax_swing_filechooser_FileFilter(C$.videoFileFilter);
chooser.setFileFilter$javax_swing_filechooser_FileFilter(chooser.getAcceptAllFileFilter$());
result=chooser.showOpenDialog$java_awt_Component(null);
} else if (type.toLowerCase$().equals$O("open video")) {
chooser.addChoosableFileFilter$javax_swing_filechooser_FileFilter(C$.videoFileFilter);
result=chooser.showOpenDialog$java_awt_Component(null);
} else if (type.toLowerCase$().equals$O("save")) {
var filename=$I$(5).getString$S("VideoIO.FileName.Untitled");
chooser.setSelectedFile$java_io_File(Clazz.new_($I$(18,1).c$$S,[filename + "." + C$.defaultXMLExt ]));
result=chooser.showSaveDialog$java_awt_Component(null);
} else if (type.toLowerCase$().equals$O("insert image")) {
chooser.setMultiSelectionEnabled$Z(true);
chooser.setAcceptAllFileFilterUsed$Z(false);
chooser.addChoosableFileFilter$javax_swing_filechooser_FileFilter(C$.imageFileFilter);
chooser.setSelectedFile$java_io_File(Clazz.new_($I$(18,1).c$$S,[""]));
result=chooser.showOpenDialog$java_awt_Component(null);
var files=chooser.getSelectedFiles$();
chooser.removeChoosableFileFilter$javax_swing_filechooser_FileFilter(C$.imageFileFilter);
chooser.setSelectedFile$java_io_File(Clazz.new_($I$(18,1).c$$S,[""]));
if (result == 0) {
return files;
}}if (result == 0) {
var file=chooser.getSelectedFile$();
chooser.removeChoosableFileFilter$javax_swing_filechooser_FileFilter(C$.videoFileFilter);
chooser.setSelectedFile$java_io_File(Clazz.new_($I$(18,1).c$$S,[""]));
return Clazz.array($I$(18), -1, [file]);
}return null;
}, 1);

Clazz.newMeth(C$, 'open$java_io_File$org_opensourcephysics_media_core_VideoPanel', function (file, vidPanel) {
if (file == null ) {
var files=C$.getChooserFiles$S("open");
if (files != null ) {
file=files[0];
}}if (file == null ) {
return null;
}if (C$.videoFileFilter.accept$java_io_File(file)) {
var types=C$.getVideoTypes$();
var video=null;
for (var i=0; i < types.length; i++) {
video=types[i].getVideo$S(file.getAbsolutePath$());
if (video != null ) {
$I$(9,"info$S",[file.getName$() + " opened as type " + types[i].getDescription$() ]);
break;
}$I$(9,"info$S",[file.getName$() + " failed as type " + types[i].getDescription$() ]);
}
if (video != null ) {
vidPanel.setVideo$org_opensourcephysics_media_core_Video(video);
vidPanel.repaint$();
} else {
$I$(27,"showMessageDialog$java_awt_Component$O",[vidPanel, $I$(5).getString$S("VideoIO.Dialog.BadVideo.Message") + $I$(30,"getNonURIPath$S",[$I$(10).getAbsolutePath$java_io_File(file)])]);
}} else {
var control=Clazz.new_($I$(29,1));
control.read$S(file.getAbsolutePath$());
var type=control.getObjectClass$();
if (Clazz.getClass($I$(31)).isAssignableFrom$Class(type)) {
vidPanel.setDataFile$java_io_File(file);
control.loadObject$O(vidPanel);
} else if (!control.failedToRead$()) {
$I$(27,"showMessageDialog$java_awt_Component$O$S$I",[vidPanel, "\"" + file.getName$() + "\" " + $I$(5).getString$S("VideoIO.Dialog.XMLMismatch.Message") , $I$(5).getString$S("VideoIO.Dialog.XMLMismatch.Title"), 2]);
return null;
} else {
$I$(27,"showMessageDialog$java_awt_Component$O",[vidPanel, $I$(5).getString$S("VideoIO.Dialog.BadFile.Message") + $I$(30,"getNonURIPath$S",[$I$(10).getAbsolutePath$java_io_File(file)])]);
}vidPanel.changed=false;
}return file;
}, 1);

Clazz.newMeth(C$, 'save$java_io_File$org_opensourcephysics_media_core_VideoPanel', function (file, vidPanel) {
return C$.save$java_io_File$org_opensourcephysics_media_core_VideoPanel$S(file, vidPanel, $I$(5).getString$S("VideoIO.Dialog.SaveAs.Title"));
}, 1);

Clazz.newMeth(C$, 'save$java_io_File$org_opensourcephysics_media_core_VideoPanel$S', function (file, vidPanel, chooserTitle) {
if (file == null ) {
var video=vidPanel.getVideo$();
var chooser=C$.getChooser$();
chooser.removeChoosableFileFilter$javax_swing_filechooser_FileFilter(C$.videoFileFilter);
chooser.removeChoosableFileFilter$javax_swing_filechooser_FileFilter(C$.imageFileFilter);
chooser.setDialogTitle$S(chooserTitle);
var filename=$I$(5).getString$S("VideoIO.FileName.Untitled");
if (vidPanel.getFilePath$() != null ) {
filename=$I$(10,"stripExtension$S",[vidPanel.getFilePath$()]);
} else if ((video != null ) && (video.getProperty$S("name") != null ) ) {
filename=video.getProperty$S("name");
var i=filename.lastIndexOf$S(".");
if (i > 0) {
filename=filename.substring$I$I(0, i);
}}file=Clazz.new_($I$(18,1).c$$S,[filename + "." + C$.defaultXMLExt ]);
var parent=$I$(10).getDirectoryPath$S(filename);
if (!parent.equals$O("")) {
$I$(10).createFolders$S(parent);
chooser.setCurrentDirectory$java_io_File(Clazz.new_($I$(18,1).c$$S,[parent]));
}chooser.setSelectedFile$java_io_File(file);
var result=chooser.showSaveDialog$java_awt_Component(vidPanel);
if (result == 0) {
file=chooser.getSelectedFile$();
if (!C$.defaultXMLExt.equals$O(C$.getExtension$java_io_File(file))) {
filename=$I$(10,"stripExtension$S",[file.getPath$()]);
file=Clazz.new_($I$(18,1).c$$S,[filename + "." + C$.defaultXMLExt ]);
}if (file.exists$()) {
var selected=$I$(27,"showConfirmDialog$java_awt_Component$O$S$I",[vidPanel, " \"" + file.getName$() + "\" " + $I$(5).getString$S("VideoIO.Dialog.FileExists.Message") , $I$(5).getString$S("VideoIO.Dialog.FileExists.Title"), 2]);
if (selected != 0) {
return null;
}}vidPanel.setDataFile$java_io_File(file);
} else {
return null;
}}var video=vidPanel.getVideo$();
if (video != null ) {
video.setProperty$S$O("base", $I$(10,"getDirectoryPath$S",[$I$(10).getAbsolutePath$java_io_File(file)]));
if (Clazz.instanceOf(video, "org.opensourcephysics.media.core.ImageVideo")) {
(video).saveInvalidImages$();
}}var xmlControl=Clazz.new_($I$(29,1).c$$O,[vidPanel]);
xmlControl.write$S(file.getAbsolutePath$());
vidPanel.changed=false;
return file;
}, 1);

Clazz.newMeth(C$, 'writeImageFile$java_awt_image_BufferedImage$S', function (image, filePath) {
if (image == null ) return null;
var file=Clazz.new_($I$(18,1).c$$S,[filePath]);
var parent=file.getParentFile$();
if (!parent.exists$()) {
parent.mkdirs$();
}var ext=$I$(10).getExtension$S(filePath);
try {
if ($I$(32).write$java_awt_image_RenderedImage$S$java_io_File(image, ext, file)) return file;
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
$I$(9,"finer$S",[ex.toString()]);
} else {
throw ex;
}
}
return null;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.VIDEO_EXTENSIONS=Clazz.array(String, -1, ["mov", "avi", "mp4"]);
C$.videoFileFilter=Clazz.new_($I$(11,1));
C$.singleVideoTypeFilters=Clazz.new_($I$(12,1));
C$.videoTypes=Clazz.new_($I$(13,1));
C$.videoEngines=Clazz.new_($I$(13,1));
C$.defaultXMLExt="xml";
C$.preferredExportExtension="mp4";
{
try {
var name="org.opensourcephysics.media.gif.GifVideoType";
var gifClass=Clazz.forName(name);
C$.addVideoType$org_opensourcephysics_media_core_VideoType(gifClass.newInstance$());
} catch (e) {
e.printStackTrace$();
}
var filter=Clazz.new_(["jpg", Clazz.array(String, -1, ["jpg", "jpeg"])],$I$(11,1).c$$S$SA);
C$.addVideoType$org_opensourcephysics_media_core_VideoType(Clazz.new_($I$(14,1).c$$org_opensourcephysics_media_core_VideoFileFilter,[filter]));
filter=Clazz.new_(["png", Clazz.array(String, -1, ["png"])],$I$(11,1).c$$S$SA);
C$.addVideoType$org_opensourcephysics_media_core_VideoType(Clazz.new_($I$(14,1).c$$org_opensourcephysics_media_core_VideoFileFilter,[filter]));
C$.imageFileFilter=((P$.VideoIO$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoIO$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.filechooser.FileFilter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]]

Clazz.newMeth(C$, 'accept$java_io_File', function (f) {
if (f == null ) {
return false;
}if (f.isDirectory$()) {
return true;
}var extension=$I$(6).getExtension$java_io_File(f);
if ((extension != null ) && (extension.equals$O("gif") || extension.equals$O("jpg") ) ) {
return true;
}return false;
});

Clazz.newMeth(C$, 'getDescription$', function () {
return $I$(5).getString$S("VideoIO.ImageFileFilter.Description");
});
})()
), Clazz.new_($I$(15,1),[this, null],P$.VideoIO$1));
C$.videoEnginePanel=Clazz.new_($I$(16,1));
};
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.VideoIO, "StreamPiper", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'Runnable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['input','java.io.InputStream','output','java.io.OutputStream']]]

Clazz.newMeth(C$, 'c$$java_io_InputStream$java_io_OutputStream', function ($in, out) {
;C$.$init$.apply(this);
this.input=$in;
this.output=out;
}, 1);

Clazz.newMeth(C$, 'run$', function () {
try {
var buffer=Clazz.array(Byte.TYPE, [1024]);
for (var count=0; (count=this.input.read$BA(buffer)) >= 0; ) {
this.output.write$BA$I$I(buffer, 0, count);
}
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
e.printStackTrace$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.VideoIO, "VideoEnginePanel", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'javax.swing.JPanel', 'java.beans.PropertyChangeListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.videoEngineButtonGroup=Clazz.new_($I$(1,1));
this.buttonMap=Clazz.new_($I$(2,1));
this.isClosing=false;
},1);

C$.$fields$=[['Z',['isClosing'],'O',['emptyPanel','javax.swing.JPanel','selectedFile','java.io.File','videoEngineButtonGroup','javax.swing.ButtonGroup','buttonMap','java.util.HashMap','title','javax.swing.border.TitledBorder']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(3,1).c$$java_awt_Container$I,[this, 1]));
this.title=$I$(4,"createTitledBorder$S",[$I$(5).getString$S("VideoEnginePanel.TitledBorder.Title")]);
this.setBorder$javax_swing_border_Border(this.title);
this.emptyPanel=((P$.VideoIO$VideoEnginePanel$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoIO$VideoEnginePanel$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.JPanel'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getPreferredSize$', function () {
return $I$(6).videoEnginePanel.getPreferredSize$();
});
})()
), Clazz.new_($I$(7,1),[this, null],P$.VideoIO$VideoEnginePanel$1));
}, 1);

Clazz.newMeth(C$, 'addVideoEngine$org_opensourcephysics_media_core_VideoType', function (type) {
var button=Clazz.new_([type.getDescription$()],$I$(8,1).c$$S);
button.setActionCommand$S(type.getClass$().getSimpleName$());
this.videoEngineButtonGroup.add$javax_swing_AbstractButton(button);
this.buttonMap.put$O$O(button, type);
this.add$java_awt_Component(button);
});

Clazz.newMeth(C$, 'getSelectedVideoType$', function () {
if ($I$(6).chooser.getAccessory$() == null  || $I$(6).chooser.getAccessory$() === this.emptyPanel  ) return null;
for (var button, $button = this.buttonMap.keySet$().iterator$(); $button.hasNext$()&&((button=($button.next$())),1);) {
if (button.isSelected$()) {
var engineType=this.buttonMap.get$O(button);
$I$(9).finest$S("selected video type: " + engineType);
var engineName=engineType.getClass$().getSimpleName$();
var ext=$I$(10,"getExtension$S",[this.selectedFile.getName$()]);
var specificType=$I$(6).getVideoType$S$S(engineName, ext);
return specificType == null  ? engineType : specificType;
}}
return null;
});

Clazz.newMeth(C$, 'reset$', function () {
this.isClosing=false;
this.refresh$();
});

Clazz.newMeth(C$, 'refresh$', function () {
if (this.isClosing) return;
this.selectedFile=$I$(6).chooser.getSelectedFile$();
if (this.buttonMap.size$() < 2) {
$I$(6).chooser.setAccessory$javax_swing_JComponent(null);
$I$(6).chooser.validate$();
return;
}var count=0;
var isButtonSelected=false;
for (var button, $button = this.buttonMap.keySet$().iterator$(); $button.hasNext$()&&((button=($button.next$())),1);) {
if (button.isSelected$()) isButtonSelected=true;
var type=this.buttonMap.get$O(button);
for (var filter, $filter = 0, $$filter = type.getFileFilters$(); $filter<$$filter.length&&((filter=($$filter[$filter])),1);$filter++) {
if (this.selectedFile != null  && filter.accept$java_io_File(this.selectedFile) ) {
count++;
continue;
}}
}
if (count < 2) {
$I$(6).chooser.setAccessory$javax_swing_JComponent(this.emptyPanel);
} else {
$I$(6).chooser.setAccessory$javax_swing_JComponent($I$(6).videoEnginePanel);
if (!isButtonSelected) {
for (var button, $button = this.buttonMap.keySet$().iterator$(); $button.hasNext$()&&((button=($button.next$())),1);) {
button.setSelected$Z(button.getActionCommand$().contains$CharSequence($I$(6).getEngine$()));
}
}}$I$(6).chooser.validate$();
$I$(6).chooser.repaint$();
});

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
var name=e.getPropertyName$();
if (name.toLowerCase$().indexOf$S("closing") > -1) {
this.isClosing=true;
} else if ($I$(6).chooser.getAccessory$() == null ) {
return;
} else if (name.equals$O("SelectedFileChangedProperty")) {
this.refresh$();
}});
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-31 17:30:12 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
