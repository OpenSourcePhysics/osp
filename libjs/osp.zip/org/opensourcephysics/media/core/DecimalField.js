(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "DecimalField", null, 'org.opensourcephysics.media.core.NumberField');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['defaultPattern']]]

Clazz.newMeth(C$, 'c$$I$I', function (columns, places) {
;C$.superclazz.c$$I.apply(this,[columns]);C$.$init$.apply(this);
this.fixedPattern=this.fixedPatternByDefault=true;
this.setDecimalPlaces$I(places);
}, 1);

Clazz.newMeth(C$, 'setDecimalPlaces$I', function (places) {
places=Math.min(places, 5);
places=Math.max(places, 1);
var d=".";
var pattern="0" + d;
for (var i=0; i < places; i++) {
pattern += "0";
}
this.defaultPattern=pattern;
if (this.userPattern.equals$O("")) {
this.format.applyPattern$S(pattern);
}});

Clazz.newMeth(C$, 'setSigFigs$I', function (sigfigs) {
});

Clazz.newMeth(C$, 'setExpectedRange$D$D', function (lower, upper) {
});

Clazz.newMeth(C$, 'setFixedPattern$S', function (pattern) {
if (pattern == null ) pattern="";
pattern=pattern.trim$();
if (pattern.equals$O(this.userPattern)) return;
this.userPattern=pattern;
if (this.userPattern.equals$O("")) {
this.format.applyPattern$S(this.defaultPattern);
} else {
this.format.applyPattern$S(this.userPattern);
}this.setValue$D(this.prevValue);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-27 14:51:45 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
