(function(){var P$=Clazz.newPackage("org.opensourcephysics.display3d.simple3d.utils"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ShapeUtils");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['vectorx','double[]','+vectory','+vectorz']]]

C$.$static$=function(){C$.$static$=0;
C$.vectorx=Clazz.array(Double.TYPE, -1, [1.0, 0.0, 0.0]);
C$.vectory=Clazz.array(Double.TYPE, -1, [0.0, 1.0, 0.0]);
C$.vectorz=Clazz.array(Double.TYPE, -1, [0.0, 0.0, 1.0]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-31 17:30:10 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
