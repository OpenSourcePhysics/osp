(function(){var P$=Clazz.newPackage("org.opensourcephysics.display3d.simple3d.utils"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ShapeUtils");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['vectorx','double[]','+vectory','+vectorz']]]

C$.$static$=function(){C$.$static$=0;
C$.vectorx=Clazz.array(Double.TYPE, -1, [1.0, 0.0, 0.0]);
C$.vectory=Clazz.array(Double.TYPE, -1, [0.0, 1.0, 0.0]);
C$.vectorz=Clazz.array(Double.TYPE, -1, [0.0, 0.0, 1.0]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-12-02 06:30:08 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
