(function(){var P$=Clazz.newPackage("org.opensourcephysics.display2d"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "LineRecord");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['x1','y1','x2','y2']]]

Clazz.newMeth(C$, 'c$$I$I$I$I', function (x1, y1, x2, y2) {
;C$.$init$.apply(this);
this.x1=x1;
this.y1=y1;
this.x2=x2;
this.y2=y2;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-20 00:04:07 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
