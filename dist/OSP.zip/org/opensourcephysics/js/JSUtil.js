(function(){var P$=Clazz.newPackage("org.opensourcephysics.js"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JSUtil");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['Z',['isJS']]]

C$.$static$=function(){C$.$static$=0;
{
var corsEnabled=Clazz.array(String, -1, ["www.physlets.org", "www.compadre.org/osp/online_help"]);
for (var i=corsEnabled.length; --i >= 0; ) {
var uri=corsEnabled[i];

J2S.addDirectDatabaseCall(uri);
}
};
C$.isJS=true ||false;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 12:09:26 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
