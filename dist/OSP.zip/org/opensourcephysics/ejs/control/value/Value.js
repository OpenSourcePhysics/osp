(function(){var P$=Clazz.newPackage("org.opensourcephysics.ejs.control.value"),I$=[[0,'org.opensourcephysics.ejs.control.value.ObjectValue','org.opensourcephysics.ejs.control.value.BooleanValue','org.opensourcephysics.ejs.control.value.DoubleValue','org.opensourcephysics.ejs.control.value.IntegerValue','org.opensourcephysics.ejs.control.value.StringValue','java.util.StringTokenizer']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Value");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['type']]]

Clazz.newMeth(C$, 'c$$I', function (type) {
;C$.$init$.apply(this);
this.type=type;
}, 1);

Clazz.newMeth(C$, 'getType$', function () {
return this.type;
});

Clazz.newMeth(C$, 'copyValue$org_opensourcephysics_ejs_control_value_Value', function (_source) {
switch (this.type) {
case 0:
(this).value=_source.getObject$();
break;
case 1:
(this).value=_source.getBoolean$();
break;
case 2:
(this).value=_source.getDouble$();
break;
case 3:
break;
case 4:
(this).value=_source.getInteger$();
break;
case 5:
(this).value=_source.getString$();
break;
}
});

Clazz.newMeth(C$, 'cloneValue$', function () {
switch (this.type) {
case 0:
return Clazz.new_([this.getObject$()],$I$(1,1).c$$O);
case 1:
return Clazz.new_([this.getBoolean$()],$I$(2,1).c$$Z);
case 2:
return Clazz.new_([this.getDouble$()],$I$(3,1).c$$D);
case 3:
break;
case 4:
return Clazz.new_([this.getInteger$()],$I$(4,1).c$$I);
case 5:
return Clazz.new_([this.getString$()],$I$(5,1).c$$S);
}
return null;
});

Clazz.newMeth(C$, 'toString', function () {
return this.getString$();
});

Clazz.newMeth(C$, 'parseConstantOrArray$S$Z', function (_input, _silentMode) {
var tkn=Clazz.new_($I$(6,1).c$$S$S,[_input, ","]);
var dim=tkn.countTokens$();
if (dim <= 1) {
return C$.parseConstant$S$Z(_input, _silentMode);
}var data=Clazz.array(C$, [dim]);
var hasDoubles=false;
var hasInts=false;
var hasBooleans=false;
for (var i=0; i < dim; i++) {
data[i]=C$.parseConstant$S$Z(tkn.nextToken$(), _silentMode);
if (data[i] == null ) {
return C$.parseConstant$S$Z(_input, _silentMode);
}if (Clazz.instanceOf(data[i], "org.opensourcephysics.ejs.control.value.DoubleValue")) {
hasDoubles=true;
} else if (Clazz.instanceOf(data[i], "org.opensourcephysics.ejs.control.value.IntegerValue")) {
hasInts=true;
} else if (Clazz.instanceOf(data[i], "org.opensourcephysics.ejs.control.value.BooleanValue")) {
hasBooleans=true;
}}
if (hasDoubles) {
var doubleArray=Clazz.array(Double.TYPE, [dim]);
for (var i=0; i < dim; i++) {
doubleArray[i]=data[i].getDouble$();
}
return Clazz.new_($I$(1,1).c$$O,[doubleArray]);
} else if (hasInts) {
var intArray=Clazz.array(Integer.TYPE, [dim]);
for (var i=0; i < dim; i++) {
intArray[i]=data[i].getInteger$();
}
return Clazz.new_($I$(1,1).c$$O,[intArray]);
} else if (hasBooleans) {
var booleanArray=Clazz.array(Boolean.TYPE, [dim]);
for (var i=0; i < dim; i++) {
booleanArray[i]=data[i].getBoolean$();
}
return Clazz.new_($I$(1,1).c$$O,[booleanArray]);
}return C$.parseConstant$S$Z(_input, _silentMode);
}, 1);

Clazz.newMeth(C$, 'removeScapes$S', function (str) {
var txt="";
var l=str.length$();
for (var i=0; i < l; i++) {
var c=str.charAt$I(i);
if (c == "\\") {
if (i == (l - 1)) {
return txt + c;
}c=str.charAt$I(++i);
}txt += c;
}
return txt;
}, 1);

Clazz.newMeth(C$, 'parseConstant$S$Z', function (_input, _silentMode) {
_input=_input.trim$();
if (_input.length$() <= 0) {
return null;
}if (_input.startsWith$S("\"")) {
if (_input.length$() <= 1) {
return null;
}if (!_input.endsWith$S("\"")) {
return null;
}return Clazz.new_([C$.removeScapes$S(_input.substring$I$I(1, _input.length$() - 1))],$I$(5,1).c$$S);
}if (_input.startsWith$S("\'")) {
if (!_input.endsWith$S("\'")) {
return null;
}return Clazz.new_([C$.removeScapes$S(_input.substring$I$I(1, _input.length$() - 1))],$I$(5,1).c$$S);
}if (_input.equals$O("true")) {
return Clazz.new_($I$(2,1).c$$Z,[true]);
}if (_input.equals$O("false")) {
return Clazz.new_($I$(2,1).c$$Z,[false]);
}if (_input.indexOf$I(".") >= 0) {
try {
var v=Double.parseDouble$S(_input);
return Clazz.new_($I$(3,1).c$$D,[v]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
if (!_silentMode) {
System.err.println$S("Value : Error 2! Incorrect input to parse " + _input);
}return null;
} else {
throw e;
}
}
}try {
var i=Integer.parseInt$S(_input);
return Clazz.new_($I$(4,1).c$$I,[i]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-27 13:16:08 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
