(function(){var P$=Clazz.newPackage("org.opensourcephysics.frames"),I$=[[0,'org.opensourcephysics.display.DataPanel']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TableFrame", null, 'org.opensourcephysics.display.OSPFrame');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.tableData=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['tableData','org.opensourcephysics.display.DataPanel']]]

Clazz.newMeth(C$, 'c$$S', function (frameTitle) {
;C$.superclazz.c$$S.apply(this,[frameTitle]);C$.$init$.apply(this);
this.setAnimated$Z(true);
this.setAutoclear$Z(true);
this.setContentPane$java_awt_Container(this.tableData);
this.setRowNumberVisible$Z(true);
this.setSize$I$I(400, 500);
}, 1);

Clazz.newMeth(C$, 'setRefreshDelay$I', function (delay) {
this.tableData.setRefreshDelay$I(delay);
});

Clazz.newMeth(C$, 'setStride$I', function (stride) {
this.tableData.setStride$I(stride);
});

Clazz.newMeth(C$, 'setRowNumberVisible$Z', function (vis) {
this.tableData.setRowNumberVisible$Z(vis);
});

Clazz.newMeth(C$, 'setColumnNames$SA', function (names) {
this.tableData.setColumnNames$SA(names);
});

Clazz.newMeth(C$, 'appendArray$O', function (obj) {
this.tableData.appendArray$O(obj);
});

Clazz.newMeth(C$, 'appendRow$DA', function (x) {
this.tableData.appendRow$DA(x);
});

Clazz.newMeth(C$, 'appendRow$IA', function (x) {
this.tableData.appendRow$IA(x);
});

Clazz.newMeth(C$, 'appendRow$OA', function (x) {
this.tableData.appendRow$OA(x);
});

Clazz.newMeth(C$, 'appendRow$BA', function (x) {
this.tableData.appendRow$BA(x);
});

Clazz.newMeth(C$, 'setColumnNames$I$S', function (column, name) {
this.tableData.setColumnNames$I$S(column, name);
});

Clazz.newMeth(C$, 'setColumnFormat$I$S', function (column, format) {
this.tableData.setColumnFormat$I$S(column, format);
});

Clazz.newMeth(C$, 'setMaxPoints$I', function (max) {
this.tableData.setMaxPoints$I(max);
});

Clazz.newMeth(C$, 'setFirstRowIndex$I', function (index) {
this.tableData.setFirstRowIndex$I(index);
});

Clazz.newMeth(C$, 'setVisible$Z', function (vis) {
var wasVisible=C$.superclazz.prototype.isVisible$.apply(this, []);
C$.superclazz.prototype.setVisible$Z.apply(this, [vis]);
if (vis && !wasVisible ) {
this.tableData.refreshTable$();
}});

Clazz.newMeth(C$, 'refreshTable$', function () {
this.tableData.refreshTable$();
});

Clazz.newMeth(C$, 'clearData$', function () {
this.tableData.clearData$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-26 22:52:36 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
