(function(){var P$=Clazz.newPackage("org.opensourcephysics.numerics"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "InvertibleFunction", null, null, 'org.opensourcephysics.numerics.Function');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 12:09:27 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
