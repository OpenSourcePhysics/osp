(function(){var P$=Clazz.newPackage("org.opensourcephysics.numerics");
/*c*/var C$=Clazz.newClass(P$, "Euler", null, 'org.opensourcephysics.numerics.AbstractODESolver');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['rate','double[]']]]

Clazz.newMeth(C$, 'c$$org_opensourcephysics_numerics_ODE', function (ode) {
;C$.superclazz.c$$org_opensourcephysics_numerics_ODE.apply(this,[ode]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'initialize$D', function (stepSize) {
C$.superclazz.prototype.initialize$D.apply(this, [stepSize]);
this.rate=Clazz.array(Double.TYPE, [this.numEqn]);
});

Clazz.newMeth(C$, 'step$', function () {
var state=this.ode.getState$();
this.ode.getRate$DA$DA(state, this.rate);
for (var i=0; i < this.numEqn; i++) {
state[i]=state[i] + this.stepSize * this.rate[i];
}
return this.stepSize;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-20 00:04:11 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
