(function(){var P$=Clazz.newPackage("org.opensourcephysics.numerics"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "NumericMethodException", null, 'RuntimeException');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['error_value'],'I',['error_code']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (msg) {
;C$.superclazz.c$$S.apply(this,[msg]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$I$D', function (msg, code, val) {
;C$.superclazz.c$$S.apply(this,[msg]);C$.$init$.apply(this);
this.error_code=code;
this.error_value=val;
}, 1);

Clazz.newMeth(C$, 'getMessage$', function () {
return C$.superclazz.prototype.getMessage$.apply(this, []) + "\n error code=" + this.error_code + "  error value=" + new Double(this.error_value).toString() ;
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-20 00:04:11 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
