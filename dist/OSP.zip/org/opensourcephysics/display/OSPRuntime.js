(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[[0,'java.util.ArrayList','java.text.DecimalFormatSymbols','java.util.Locale','javax.swing.UIManager','javax.swing.JFrame','java.util.HashMap','org.opensourcephysics.controls.XML','java.text.NumberFormat','java.text.DecimalFormat','org.opensourcephysics.js.JSUtil','java.io.File','org.opensourcephysics.tools.ResourceLoader','javax.swing.JOptionPane','javax.swing.plaf.metal.MetalLookAndFeel','javax.swing.JDialog','org.opensourcephysics.controls.OSPLog','java.util.jar.JarFile','java.net.URL','java.util.TreeMap','org.opensourcephysics.controls.XMLControlElement','org.opensourcephysics.tools.FontSizer','javajs.async.AsyncFileChooser','org.opensourcephysics.display.DisplayRes','javax.swing.filechooser.FileFilter','javax.swing.JFileChooser',['org.opensourcephysics.display.OSPRuntime','.ExtensionFileFilter'],'javax.swing.filechooser.FileSystemView']],$I$=function(i,n){return(i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i};
/*c*/var C$=Clazz.newClass(P$, "OSPRuntime", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['ExtensionFileFilter',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['Z',['isJS','disableAllDrawing','loadVideoTool','loadExportTool','loadDataTool','loadFourierTool','loadTranslatorTool','loadOSPLog','launcherMode','appletMode','webStart','authorMode','launchingInSingleVM','DEFAULT_LOOK_AND_FEEL_DECORATIONS','isMac','setRenderingHints'],'C',['defaultDecimalSeparator'],'S',['launchJarPath','launchJarName','buildDate','preferredDecimalSeparator','chooserDir','userhomeDir','prefsPath','prefsFileName'],'O',['translator','org.opensourcephysics.tools.Translator','dfs','java.text.DecimalFormatSymbols','defaultLocales','java.util.Locale[]','antiAliasText','Boolean','applet','javax.swing.JApplet','launchJar','java.util.jar.JarFile','DEFAULT_LOOK_AND_FEEL','javax.swing.LookAndFeel','LOOK_AND_FEEL_TYPES','java.util.HashMap','prefsControl','org.opensourcephysics.controls.XMLControl','chooser','javajs.async.AsyncFileChooser']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getUserHome$', function () {
var home=System.getProperty$S("user.home");
if (C$.isLinux$()) {
var homeEnv=System.getenv$S("HOME");
if (homeEnv != null ) {
home=homeEnv;
}}return home == null  ? "." : home;
}, 1);

Clazz.newMeth(C$, 'getDownloadDir$', function () {
var home=C$.getUserHome$();
var downloadDir=Clazz.new_($I$(11,1).c$$S,[home + "/Downloads"]);
if (C$.isLinux$()) {
var xdgDir=home + "/.config/user-dirs.dirs";
var xdgText=$I$(12).getString$S(xdgDir);
if (xdgText != null ) {
var split=xdgText.split$S("XDG_");
for (var next, $next = 0, $$next = split; $next<$$next.length&&((next=($$next[$next])),1);$next++) {
if (next.contains$CharSequence("DOWNLOAD_DIR")) {
var n=next.indexOf$S("\"");
if (n > -1) {
next=next.substring$I(n + 1);
n=next.indexOf$S("\"");
if (n > -1) {
next=next.substring$I$I(0, n);
if (next.startsWith$S("$HOME")) {
next=home + next.substring$I(5);
}var f=Clazz.new_($I$(11,1).c$$S,[next]);
if (f.exists$()) {
downloadDir=f;
}}}}}
}}return downloadDir;
}, 1);

Clazz.newMeth(C$, 'showAboutDialog$java_awt_Component', function (parent) {
var date=C$.getLaunchJarBuildDate$();
date="February 1, 2020";
var vers="JavaScript OSP Library 5.0.0";
vers += "\n\nJavaScript transcription created using the\njava2script/SwingJS framework developed at\nSt. Olaf College.\n";
if (date != null ) {
vers += " released " + date;
}var aboutString=vers + "\n" + "Open Source Physics Project \n" + "www.opensourcephysics.org" ;
$I$(13).showMessageDialog$java_awt_Component$O$S$I(parent, aboutString, "About Open Source Physics", 1);
}, 1);

Clazz.newMeth(C$, 'setLookAndFeel$Z$S', function (useDefaultLnFDecorations, lookAndFeel) {
var found=true;
var currentLookAndFeel=$I$(4).getLookAndFeel$();
try {
if ((lookAndFeel == null ) || lookAndFeel.equals$O("DEFAULT") ) {
$I$(4).setLookAndFeel$javax_swing_LookAndFeel(C$.DEFAULT_LOOK_AND_FEEL);
useDefaultLnFDecorations=C$.DEFAULT_LOOK_AND_FEEL_DECORATIONS;
} else if (lookAndFeel.equals$O("CROSS_PLATFORM")) {
lookAndFeel=$I$(4).getCrossPlatformLookAndFeelClassName$();
$I$(4).setLookAndFeel$S(lookAndFeel);
} else if (lookAndFeel.equals$O("SYSTEM")) {
lookAndFeel=$I$(4).getSystemLookAndFeelClassName$();
$I$(4).setLookAndFeel$S(lookAndFeel);
} else if (lookAndFeel.equals$O("NIMBUS")) {
$I$(4).setLookAndFeel$S("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
} else if (lookAndFeel.equals$O("METAL")) {
(function(a,f){return f.apply(null,a)})([Clazz.new_($I$(14,1))],$I$(4).setLookAndFeel$javax_swing_LookAndFeel);
} else if (lookAndFeel.equals$O("GTK")) {
$I$(4).setLookAndFeel$S("com.sun.java.swing.plaf.gtk.GTKLookAndFeel");
} else if (lookAndFeel.equals$O("MOTIF")) {
$I$(4).setLookAndFeel$S("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
} else if (lookAndFeel.equals$O("WINDOWS")) {
$I$(4).setLookAndFeel$S("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
} else {
$I$(4).setLookAndFeel$S(lookAndFeel);
}$I$(5).setDefaultLookAndFeelDecorated$Z(useDefaultLnFDecorations);
$I$(15).setDefaultLookAndFeelDecorated$Z(useDefaultLnFDecorations);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
found=false;
} else {
throw ex;
}
}
if (!found) {
try {
$I$(4).setLookAndFeel$javax_swing_LookAndFeel(currentLookAndFeel);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}return found;
}, 1);

Clazz.newMeth(C$, 'isDefaultLookAndFeelDecorated$', function () {
return $I$(5).isDefaultLookAndFeelDecorated$();
}, 1);

Clazz.newMeth(C$, 'isWindows$', function () {
try {
return (System.getProperty$S$S("os.name", "").toLowerCase$().startsWith$S("windows"));
} catch (ex) {
if (Clazz.exceptionOf(ex,"SecurityException")){
return false;
} else {
throw ex;
}
}
}, 1);

Clazz.newMeth(C$, 'isMac$', function () {
return C$.isMac;
}, 1);

Clazz.newMeth(C$, 'isLinux$', function () {
try {
return (System.getProperty$S$S("os.name", "").toLowerCase$().startsWith$S("linux"));
} catch (ex) {
if (Clazz.exceptionOf(ex,"SecurityException")){
return false;
} else {
throw ex;
}
}
}, 1);

Clazz.newMeth(C$, 'isVista$', function () {
if (System.getProperty$S$S("os.name", "").toLowerCase$().indexOf$S("vista") > -1) {
return true;
}return false;
}, 1);

Clazz.newMeth(C$, 'hasJava3D$', function () {
try {
if (C$.isMac) {
var tryIt=true;
var home=System.getProperty$S("java.home");
var version=System.getProperty$S("java.version");
if (version.indexOf$S("1.7") < 0 && version.indexOf$S("1.8") < 0 ) tryIt=true;
 else tryIt=(Clazz.new_($I$(11,1).c$$S,[home + "/lib/ext/j3dcore.jar"])).exists$();
if (!tryIt) return false;
}} catch (exc) {
if (Clazz.exceptionOf(exc,"Exception")){
return false;
} else {
throw exc;
}
}
try {
Clazz.forName("com.sun.j3d.utils.universe.SimpleUniverse");
return true;
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"Error")){
var e = e$$;
{
return false;
}
} else if (Clazz.exceptionOf(e$$,"Exception")){
var e = e$$;
{
return false;
}
} else {
throw e$$;
}
}
}, 1);

Clazz.newMeth(C$, 'isPopupTrigger$java_awt_event_InputEvent', function (e) {
if (Clazz.instanceOf(e, "java.awt.event.MouseEvent")) {
var me=e;
if (me.isShiftDown$()) return false;
return (me.isPopupTrigger$()) || (me.getButton$() == 3) || (me.isControlDown$() && C$.isMac )  ;
}return false;
}, 1);

Clazz.newMeth(C$, 'isWebStart$', function () {
if (!C$.webStart) {
try {
C$.webStart=System.getProperty$S("javawebstart.version") != null ;
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
}return C$.webStart;
}, 1);

Clazz.newMeth(C$, 'isAppletMode$', function () {
return C$.appletMode;
}, 1);

Clazz.newMeth(C$, 'isAuthorMode$', function () {
return C$.authorMode;
}, 1);

Clazz.newMeth(C$, 'setAuthorMode$Z', function (b) {
C$.authorMode=b;
}, 1);

Clazz.newMeth(C$, 'setLauncherMode$Z', function (b) {
C$.launcherMode=b;
}, 1);

Clazz.newMeth(C$, 'isLauncherMode$', function () {
return C$.launcherMode || "true".equals$O(System.getProperty$S("org.osp.launcher")) ;
}, 1);

Clazz.newMeth(C$, 'setLaunchJarPath$S', function (path) {
if ((path == null ) || (C$.launchJarPath != null ) ) {
return;
}if (!path.endsWith$S(".jar") && !path.endsWith$S(".exe") ) {
var n=path.indexOf$S(".jar!");
if (n == -1) {
n=path.indexOf$S(".exe!");
}if (n > -1) {
path=path.substring$I$I(0, n + 4);
} else {
return;
}}if (path.startsWith$S("jar:")) {
path=path.substring$I$I(4, path.length$());
}try {
var file=Clazz.new_($I$(11,1).c$$S,[path]);
if (!file.exists$()) return;
path=(function(a,f){return f.apply(null,a)})([file.getCanonicalPath$()],$I$(7).forwardSlash$S);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
$I$(16).finer$S("Setting launch jar path to " + path);
C$.launchJarPath=path;
C$.launchJarName=path.substring$I(path.lastIndexOf$S("/") + 1);
}, 1);

Clazz.newMeth(C$, 'getLaunchJarName$', function () {
return C$.launchJarName;
}, 1);

Clazz.newMeth(C$, 'getLaunchJarPath$', function () {
return C$.launchJarPath;
}, 1);

Clazz.newMeth(C$, 'getLaunchJarDirectory$', function () {
if (C$.applet != null ) {
return null;
}return (C$.launchJarPath == null ) ? null : $I$(7).getDirectoryPath$S(C$.launchJarPath);
}, 1);

Clazz.newMeth(C$, 'getLaunchJar$', function () {
if (C$.launchJar != null ) {
return C$.launchJar;
}if (C$.launchJarPath == null ) {
return null;
}var isWebFile=C$.launchJarPath.startsWith$S("http:");
if (!isWebFile) {
C$.launchJarPath=$I$(12).getNonURIPath$S(C$.launchJarPath);
}try {
if ((C$.applet == null ) && !isWebFile ) {
C$.launchJar=Clazz.new_($I$(17,1).c$$S,[C$.launchJarPath]);
} else {
var url;
if (isWebFile) {
url=Clazz.new_($I$(18,1).c$$S,["jar:" + C$.launchJarPath + "!/" ]);
} else {
url=Clazz.new_($I$(18,1).c$$S,["jar:file:/" + C$.launchJarPath + "!/" ]);
}var conn=url.openConnection$();
C$.launchJar=conn.getJarFile$();
}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
(function(a,f){return f.apply(null,a)})([ex.getMessage$()],$I$(16).fine$S);
} else {
throw ex;
}
}
return C$.launchJar;
}, 1);

Clazz.newMeth(C$, 'getLaunchJarBuildDate$', function () {
if (C$.buildDate == null ) {
try {
var jarfile=C$.getLaunchJar$();
var att=jarfile.getManifest$().getMainAttributes$();
C$.buildDate=att.getValue$S("Build-Date");
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
}return C$.buildDate;
}, 1);

Clazz.newMeth(C$, 'getJavaFile$S', function (jrePath) {
if (jrePath == null ) return null;
var file=Clazz.new_($I$(11,1).c$$S,[jrePath]);
jrePath=$I$(7).forwardSlash$S(jrePath);
if (jrePath.endsWith$S("/lib/ext")) {
jrePath=jrePath.substring$I$I(0, jrePath.length$() - 8);
file=Clazz.new_($I$(11,1).c$$S,[jrePath]);
}if (!jrePath.endsWith$S("/bin/java") && !jrePath.endsWith$S("/bin/java.exe") ) {
if (jrePath.endsWith$S("/bin")) {
file=file.getParentFile$();
}if (C$.isWindows$()) {
if (file.getParentFile$() != null  && file.getParentFile$().getName$().indexOf$S("jre") > -1 ) {
file=file.getParentFile$();
}if (file.getParentFile$() != null  && file.getParentFile$().getName$().indexOf$S("jdk") > -1 ) {
file=file.getParentFile$();
}if (file.getName$().indexOf$S("jdk") > -1) file=Clazz.new_($I$(11,1).c$$java_io_File$S,[file, "jre/bin/java.exe"]);
 else if (file.getName$().indexOf$S("jre") > -1) {
file=Clazz.new_($I$(11,1).c$$java_io_File$S,[file, "bin/java.exe"]);
} else file=null;
} else if (C$.isMac) {
if (file.getName$().endsWith$S("jdk")) {
var parent=file;
file=Clazz.new_($I$(11,1).c$$java_io_File$S,[parent, "Contents/Home/jre/bin/java"]);
if (!file.exists$()) {
file=Clazz.new_($I$(11,1).c$$java_io_File$S,[parent, "Contents/Home/bin/java"]);
}} else file=Clazz.new_($I$(11,1).c$$java_io_File$S,[file, "bin/java"]);
} else if (C$.isLinux$()) {
if ("jre".equals$O(file.getName$())) {
file=Clazz.new_($I$(11,1).c$$java_io_File$S,[file, "bin/java"]);
} else {
if (file.getParentFile$() != null  && file.getParentFile$().getName$().indexOf$S("jre") > -1 ) {
file=file.getParentFile$();
}if (file.getParentFile$() != null  && file.getParentFile$().getName$().indexOf$S("jdk") > -1 ) {
file=file.getParentFile$();
}if (file.getParentFile$() != null  && file.getParentFile$().getName$().indexOf$S("sun") > -1 ) {
file=file.getParentFile$();
}if (file.getName$().indexOf$S("jdk") > -1 || file.getName$().indexOf$S("sun") > -1 ) file=Clazz.new_($I$(11,1).c$$java_io_File$S,[file, "jre/bin/java"]);
 else file=null;
}}}if (file != null ) {
try {
file=file.getCanonicalFile$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
file=null;
} else {
throw e;
}
}
}if (file != null  && file.exists$() ) return file;
return null;
}, 1);

Clazz.newMeth(C$, 'getVMBitness$', function () {
var s=System.getProperty$S("java.vm.name");
s += "-" + System.getProperty$S("os.arch");
s += "-" + System.getProperty$S("sun.arch.data.model");
return s.indexOf$S("64") > -1 ? 64 : 32;
}, 1);

Clazz.newMeth(C$, 'getJREPath$java_io_File', function (javaFile) {
if (javaFile == null ) return null;
var javaPath=(function(a,f){return f.apply(null,a)})([javaFile.getAbsolutePath$()],$I$(7).forwardSlash$S);
if ($I$(7).stripExtension$S(javaPath).endsWith$S("/bin/java")) return javaFile.getParentFile$().getParent$();
return "";
}, 1);

Clazz.newMeth(C$, 'getDefaultLocales$', function () {
return C$.defaultLocales;
}, 1);

Clazz.newMeth(C$, 'getInstalledLocales$', function () {
var list=Clazz.new_($I$(1,1));
if ($I$(10).isJS) return list.toArray$OA(Clazz.array($I$(3), [0]));
var languages=Clazz.new_($I$(19,1));
list.add$O($I$(3).ENGLISH);
if (C$.getLaunchJarPath$() != null ) {
var jar=C$.getLaunchJar$();
if (jar != null ) {
for (var e=jar.entries$(); e.hasMoreElements$(); ) {
var entry=e.nextElement$();
var path=entry.toString();
var n=path.indexOf$S(".properties");
if (path.indexOf$S(".properties") > -1) {
var m=path.indexOf$S("display_res_");
if (m > -1) {
var loc=path.substring$I$I(m + 12, n);
if (loc.equals$O("zh_TW")) {
var next=$I$(3).TAIWAN;
languages.put$O$O(C$.getDisplayLanguage$java_util_Locale(next).toLowerCase$(), next);
} else if (loc.equals$O("zh_CN")) {
var next=$I$(3).CHINA;
languages.put$O$O(C$.getDisplayLanguage$java_util_Locale(next).toLowerCase$(), next);
} else if (loc.equals$O("en_US")) {
continue;
} else {
var next;
if (!loc.contains$CharSequence("_")) next=Clazz.new_($I$(3,1).c$$S,[loc]);
 else {
var lang=loc.substring$I$I(0, 2);
var country=loc.substring$I(3);
next=Clazz.new_($I$(3,1).c$$S$S$S,[lang, country, ""]);
}if (!next.equals$O($I$(3).ENGLISH)) {
languages.put$O$O(C$.getDisplayLanguage$java_util_Locale(next).toLowerCase$(), next);
}}}}}
for (var s, $s = languages.keySet$().iterator$(); $s.hasNext$()&&((s=($s.next$())),1);) {
list.add$O(languages.get$O(s));
}
} else {
C$.defaultLocales=Clazz.array($I$(3), -1, [$I$(3).ENGLISH]);
return C$.defaultLocales;
}}return list.toArray$OA(Clazz.array($I$(3), [0]));
}, 1);

Clazz.newMeth(C$, 'getDisplayLanguage$java_util_Locale', function (locale) {
if (locale.equals$O($I$(3).CHINA)) return "\u7b80\u4f53\u4e2d\u6587";
if (locale.equals$O($I$(3).TAIWAN)) return "\u7e41\u4f53\u4e2d\u6587";
return locale.getDisplayLanguage$java_util_Locale(locale);
}, 1);

Clazz.newMeth(C$, 'getDecimalFormatSymbols$', function () {
return C$.dfs;
}, 1);

Clazz.newMeth(C$, 'setDefaultDecimalSeparator$C', function (c) {
C$.defaultDecimalSeparator=c;
if (C$.preferredDecimalSeparator == null ) C$.dfs.setDecimalSeparator$C(c);
}, 1);

Clazz.newMeth(C$, 'setPreferredDecimalSeparator$S', function (separator) {
if (separator != null  && separator.length$() == 0 ) separator=null;
C$.preferredDecimalSeparator=separator;
C$.dfs.setDecimalSeparator$C(separator == null  ? C$.defaultDecimalSeparator : separator.charAt$I(0));
}, 1);

Clazz.newMeth(C$, 'getPreferredDecimalSeparator$', function () {
return C$.preferredDecimalSeparator;
}, 1);

Clazz.newMeth(C$, 'getDefaultSearchPaths$', function () {
var paths=Clazz.new_($I$(1,1));
if (C$.isWindows$()) {
var appdata=System.getenv$S("LOCALAPPDATA");
if (appdata != null ) {
var dir=Clazz.new_($I$(11,1).c$$S$S,[appdata, "OSP"]);
if (!dir.exists$()) dir.mkdir$();
if (dir.exists$()) {
paths.add$O((function(a,f){return f.apply(null,a)})([dir.getAbsolutePath$()],$I$(7).forwardSlash$S));
}}} else if (C$.userhomeDir != null  && C$.isMac ) {
var dir=Clazz.new_($I$(11,1).c$$S$S,[C$.userhomeDir, "Library/Application Support"]);
if (dir.exists$()) {
dir=Clazz.new_($I$(11,1).c$$java_io_File$S,[dir, "OSP"]);
if (!dir.exists$()) dir.mkdir$();
if (dir.exists$()) {
paths.add$O((function(a,f){return f.apply(null,a)})([dir.getAbsolutePath$()],$I$(7).forwardSlash$S));
}}} else if (C$.userhomeDir != null  && C$.isLinux$() ) {
var dir=Clazz.new_($I$(11,1).c$$S$S,[C$.userhomeDir, ".config"]);
if (dir.exists$()) {
dir=Clazz.new_($I$(11,1).c$$java_io_File$S,[dir, "OSP"]);
if (!dir.exists$()) dir.mkdir$();
if (dir.exists$()) {
paths.add$O((function(a,f){return f.apply(null,a)})([dir.getAbsolutePath$()],$I$(7).forwardSlash$S));
}}}if (C$.userhomeDir != null ) {
paths.add$O(C$.userhomeDir);
}var codebase=C$.getLaunchJarDirectory$();
if (codebase != null ) {
paths.add$O($I$(7).forwardSlash$S(codebase));
}return paths;
}, 1);

Clazz.newMeth(C$, 'getPreference$S', function (name) {
var control=C$.getPrefsControl$();
return control.getObject$S(name);
}, 1);

Clazz.newMeth(C$, 'setPreference$S$O', function (name, pref) {
var control=C$.getPrefsControl$();
control.setValue$S$O(name, pref);
}, 1);

Clazz.newMeth(C$, 'savePreferences$', function () {
var control=C$.getPrefsControl$();
var file=Clazz.new_($I$(11,1).c$$S$S,[C$.prefsPath, C$.prefsFileName]);
control.write$S(file.getAbsolutePath$());
}, 1);

Clazz.newMeth(C$, 'getPreferencesFile$', function () {
C$.getPrefsControl$();
var file=Clazz.new_($I$(11,1).c$$S$S,[C$.prefsPath, C$.prefsFileName]);
if (file.exists$()) return file;
return null;
}, 1);

Clazz.newMeth(C$, 'getPrefsControl$', function () {
if (C$.prefsControl == null ) {
var dirs=C$.getDefaultSearchPaths$();
for (var dir, $dir = dirs.iterator$(); $dir.hasNext$()&&((dir=($dir.next$())),1);) {
var file=Clazz.new_($I$(11,1).c$$S$S,[dir, C$.prefsFileName]);
if (!file.exists$()) {
file=Clazz.new_($I$(11,1).c$$S$S,[dir, "." + C$.prefsFileName]);
if (file.exists$()) {
C$.prefsFileName="." + C$.prefsFileName;
}}if (file.exists$()) {
var test=Clazz.new_([file.getAbsolutePath$()],$I$(20,1).c$$S);
if (!test.failedToRead$()) {
C$.prefsControl=test;
C$.prefsPath=$I$(7).forwardSlash$S(dir);
break;
}}}
if (C$.prefsControl == null ) {
C$.prefsControl=Clazz.new_($I$(20,1));
C$.prefsPath=(function(a,f){return f.apply(null,a)})([dirs.get$I(0)],$I$(7).forwardSlash$S);
if (C$.prefsPath.equals$O(C$.userhomeDir)) {
C$.prefsFileName="." + C$.prefsFileName;
}var file=Clazz.new_($I$(11,1).c$$S$S,[C$.prefsPath, C$.prefsFileName]);
if (!$I$(10).isJS) C$.prefsControl.write$S(file.getAbsolutePath$());
}}return C$.prefsControl;
}, 1);

Clazz.newMeth(C$, 'getTranslator$', function () {
if ($I$(10).isJS) {
return null;
}if ((C$.translator == null ) && C$.loadTranslatorTool ) {
try {
var translatorClass=Clazz.forName("org.opensourcephysics.tools.TranslatorTool");
var m=translatorClass.getMethod$S$ClassA("getTool", null);
C$.translator=m.invoke$O$OA(null, null);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
C$.loadTranslatorTool=false;
(function(a,f){return f.apply(null,a)})(["Cannot instantiate translator tool class:\n" + ex.toString()],$I$(16).finest$S);
} else {
throw ex;
}
}
}return C$.translator;
}, 1);

Clazz.newMeth(C$, 'getChooser$', function () {
if (C$.chooser != null ) {
(function(a,f){return f.apply(null,a)})([C$.chooser, $I$(21).getLevel$()],$I$(21).setFonts$O$I);
return C$.chooser;
}try {
C$.chooser=(C$.chooserDir == null ) ? Clazz.new_($I$(22,1)) : Clazz.new_([Clazz.new_($I$(11,1).c$$S,[C$.chooserDir])],$I$(22,1).c$$java_io_File);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Exception in OSPFrame getChooser=" + e);
return null;
} else {
throw e;
}
}
var defaultFilter=C$.chooser.getFileFilter$();
var xmlFilter=((P$.OSPRuntime$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPRuntime$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.filechooser.FileFilter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'accept$java_io_File', function (f) {
if (f == null ) {
return false;
}if (f.isDirectory$()) {
return true;
}var extension=null;
var name=f.getName$();
var i=name.lastIndexOf$I(".");
if ((i > 0) && (i < name.length$() - 1) ) {
extension=name.substring$I(i + 1).toLowerCase$();
}if ((extension != null ) && (extension.equals$O("xml")) ) {
return true;
}return false;
});

Clazz.newMeth(C$, 'getDescription$', function () {
return $I$(23).getString$S("OSPRuntime.FileFilter.Description.XML");
});
})()
), Clazz.new_($I$(24,1),[this, null],P$.OSPRuntime$1));
var txtFilter=((P$.OSPRuntime$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPRuntime$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.filechooser.FileFilter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'accept$java_io_File', function (f) {
if (f == null ) {
return false;
}if (f.isDirectory$()) {
return true;
}var extension=null;
var name=f.getName$();
var i=name.lastIndexOf$I(".");
if ((i > 0) && (i < name.length$() - 1) ) {
extension=name.substring$I(i + 1).toLowerCase$();
}if ((extension != null ) && extension.equals$O("txt") ) {
return true;
}return false;
});

Clazz.newMeth(C$, 'getDescription$', function () {
return $I$(23).getString$S("OSPRuntime.FileFilter.Description.TXT");
});
})()
), Clazz.new_($I$(24,1),[this, null],P$.OSPRuntime$2));
C$.chooser.addChoosableFileFilter$javax_swing_filechooser_FileFilter(xmlFilter);
C$.chooser.addChoosableFileFilter$javax_swing_filechooser_FileFilter(txtFilter);
C$.chooser.setFileFilter$javax_swing_filechooser_FileFilter(defaultFilter);
(function(a,f){return f.apply(null,a)})([C$.chooser, $I$(21).getLevel$()],$I$(21).setFonts$O$I);
return C$.chooser;
}, 1);

Clazz.newMeth(C$, 'chooseFilename$javax_swing_JFileChooser', function (chooser) {
return C$.chooseFilename$javax_swing_JFileChooser$java_awt_Component$Z(chooser, null, true);
}, 1);

Clazz.newMeth(C$, 'chooseFilename$javax_swing_JFileChooser$java_awt_Component$Z', function (chooser, parent, toSave) {
var fileName=null;
var result;
if (toSave) {
result=chooser.showSaveDialog$java_awt_Component(parent);
} else {
result=chooser.showOpenDialog$java_awt_Component(parent);
}if (result == 0) {
C$.chooserDir=chooser.getCurrentDirectory$().toString();
var file=chooser.getSelectedFile$();
if (toSave) {
if (file.exists$()) {
var selected=(function(a,f){return f.apply(null,a)})([parent, $I$(23).getString$S("DrawingFrame.ReplaceExisting_message") + " " + file.getName$() + $I$(23).getString$S("DrawingFrame.QuestionMark") , $I$(23).getString$S("DrawingFrame.ReplaceFile_option_title"), 1],$I$(13).showConfirmDialog$java_awt_Component$O$S$I);
if (selected != 0) {
return null;
}}} else {
if (!file.exists$()) {
(function(a,f){return f.apply(null,a)})([parent, $I$(23).getString$S("GUIUtils.FileDoesntExist") + " " + file.getName$() , $I$(23).getString$S("GUIUtils.FileChooserError"), 0],$I$(13).showMessageDialog$java_awt_Component$O$S$I);
return null;
}}fileName=file.getAbsolutePath$();
if ((fileName == null ) || fileName.trim$().equals$O("") ) {
return null;
}}return fileName;
}, 1);

Clazz.newMeth(C$, 'createChooser$S$S$SA', function (title, description, extensions) {
var chooser=C$.createChooser$S$SA$java_io_File(description, extensions, null);
chooser.setDialogTitle$S(title);
return chooser;
}, 1);

Clazz.newMeth(C$, 'createChooser$S$SA', function (description, extensions) {
return C$.createChooser$S$SA$java_io_File(description, extensions, null);
}, 1);

Clazz.newMeth(C$, 'createChooser$S$SA$java_io_File', function (description, extensions, homeDir) {
var chooser=Clazz.new_([Clazz.new_($I$(11,1).c$$S,[C$.chooserDir])],$I$(25,1).c$$java_io_File);
var filter=Clazz.new_($I$(26,1));
for (var i=0; i < extensions.length; i++) {
filter.addExtension$S(extensions[i]);
}
filter.setDescription$S(description);
if (homeDir != null ) {
chooser.setFileSystemView$javax_swing_filechooser_FileSystemView(((P$.OSPRuntime$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPRuntime$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.filechooser.FileSystemView'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'createNewFolder$java_io_File', function (arg0) {
return $I$(27).getFileSystemView$().createNewFolder$java_io_File(arg0);
});

Clazz.newMeth(C$, 'getHomeDirectory$', function () {
return this.$finals$.homeDir;
});
})()
), Clazz.new_($I$(27,1),[this, {homeDir:homeDir}],P$.OSPRuntime$3)));
}chooser.setFileFilter$javax_swing_filechooser_FileFilter(filter);
(function(a,f){return f.apply(null,a)})([chooser, $I$(21).getLevel$()],$I$(21).setFonts$O$I);
return chooser;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.isJS=true ||false;
C$.disableAllDrawing=false;
C$.loadVideoTool=true;
C$.loadExportTool=true;
C$.loadDataTool=true;
C$.loadFourierTool=true;
C$.loadTranslatorTool=true;
C$.loadOSPLog=true;
C$.dfs=Clazz.new_($I$(2,1));
C$.defaultLocales=Clazz.array($I$(3), -1, [$I$(3).ENGLISH, Clazz.new_($I$(3,1).c$$S,["es"]), Clazz.new_($I$(3,1).c$$S,["de"]), Clazz.new_($I$(3,1).c$$S,["da"]), Clazz.new_($I$(3,1).c$$S,["sk"]), $I$(3).TAIWAN]);
C$.launcherMode=false;
C$.antiAliasText=new Boolean(false);
C$.authorMode=true;
C$.launchJar=null;
C$.preferredDecimalSeparator=null;
C$.DEFAULT_LOOK_AND_FEEL=$I$(4).getLookAndFeel$();
C$.DEFAULT_LOOK_AND_FEEL_DECORATIONS=$I$(5).isDefaultLookAndFeelDecorated$();
C$.LOOK_AND_FEEL_TYPES=Clazz.new_($I$(6,1));
C$.prefsFileName="osp.prefs";
{
try {
C$.chooserDir=System.getProperty$S$S("user.dir", null);
var userhome=C$.getUserHome$();
if (userhome != null ) {
C$.userhomeDir=$I$(7).forwardSlash$S(userhome);
}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
C$.chooserDir=null;
} else {
throw ex;
}
}
C$.LOOK_AND_FEEL_TYPES.put$O$O("METAL", "javax.swing.plaf.metal.MetalLookAndFeel");
C$.LOOK_AND_FEEL_TYPES.put$O$O("NIMBUS", "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
C$.LOOK_AND_FEEL_TYPES.put$O$O("GTK", "com.sun.java.swing.plaf.gtk.GTKLookAndFeel");
C$.LOOK_AND_FEEL_TYPES.put$O$O("MOTIF", "com.sun.java.swing.plaf.motif.MotifLookAndFeel");
C$.LOOK_AND_FEEL_TYPES.put$O$O("WINDOWS", "com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
C$.LOOK_AND_FEEL_TYPES.put$O$O("CROSS_PLATFORM", $I$(4).getCrossPlatformLookAndFeelClassName$());
C$.LOOK_AND_FEEL_TYPES.put$O$O("SYSTEM", $I$(4).getSystemLookAndFeelClassName$());
C$.LOOK_AND_FEEL_TYPES.put$O$O("DEFAULT", C$.DEFAULT_LOOK_AND_FEEL.getClass$().getName$());
var format=(function(a,f){return f.apply(null,a)})([$I$(3).FRANCE],$I$(8).getInstance$java_util_Locale);
if (Clazz.instanceOf(format, "java.text.DecimalFormat")) {
C$.defaultDecimalSeparator=(format).getDecimalFormatSymbols$().getDecimalSeparator$();
} else {
C$.defaultDecimalSeparator=Clazz.new_($I$(9,1)).getDecimalFormatSymbols$().getDecimalSeparator$();
}C$.dfs.setDecimalSeparator$C(C$.defaultDecimalSeparator);
};
{
try {
C$.isMac=(1 ? false :(System.getProperty$S$S("os.name", "").toLowerCase$().startsWith$S("mac")));
} catch (ex) {
if (Clazz.exceptionOf(ex,"SecurityException")){
} else {
throw ex;
}
}
};
C$.setRenderingHints=(!$I$(10).isJS && !C$.isMac );
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.OSPRuntime, "ExtensionFileFilter", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'javax.swing.filechooser.FileFilter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.description="";
this.extensions=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['S',['description'],'O',['extensions','java.util.ArrayList']]]

Clazz.newMeth(C$, 'addExtension$S', function (extension) {
if (!extension.startsWith$S(".")) {
extension="." + extension;
}this.extensions.add$O(extension.toLowerCase$());
});

Clazz.newMeth(C$, 'toString', function () {
return this.description;
});

Clazz.newMeth(C$, 'setDescription$S', function (aDescription) {
this.description=aDescription;
});

Clazz.newMeth(C$, 'getDescription$', function () {
return this.description;
});

Clazz.newMeth(C$, 'accept$java_io_File', function (f) {
if (f == null ) return false;
if (f.isDirectory$()) {
return true;
}var name=f.getName$().toLowerCase$();
for (var i=0; i < this.extensions.size$(); i++) {
if (name.endsWith$S(this.extensions.get$I(i))) {
return true;
}}
return false;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-20 00:04:05 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
