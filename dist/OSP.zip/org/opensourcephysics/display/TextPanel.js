(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[[0,'java.awt.Dimension','java.awt.Color','java.awt.Font','org.opensourcephysics.display.TeXParser','javax.swing.SwingUtilities']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TextPanel", null, 'javax.swing.JPanel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.text="";
this.fontname="TimesRoman";
this.fontsize=14;
this.fontstyle=0;
this.textColor=$I$(2).black;
this.backgroundColor=$I$(2).yellow;
this.dim=C$.ZEROSIZE;
},1);

C$.$fields$=[['I',['fontsize','fontstyle'],'S',['text','fontname'],'O',['$font','java.awt.Font','textColor','java.awt.Color','+backgroundColor','dim','java.awt.Dimension']]
,['O',['ZEROSIZE','java.awt.Dimension']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.setBackground$java_awt_Color(this.backgroundColor);
this.$font=Clazz.new_($I$(3,1).c$$S$I$I,[this.fontname, this.fontstyle, this.fontsize]);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (text) {
C$.c$.apply(this, []);
this.setText$S(text);
}, 1);

Clazz.newMeth(C$, 'setText$S', function (_text) {
_text=$I$(4).parseTeX$S(_text);
if (this.text == _text) {
return;
}this.text=_text;
if (this.text == null ) {
this.text="";
}var c=this.getParent$();
if (c == null ) {
return;
}var runner=((P$.TextPanel$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "TextPanel$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
if (Clazz.instanceOf(this.$finals$.c.getLayout$(), "org.opensourcephysics.display.OSPLayout")) {
(this.$finals$.c.getLayout$()).quickLayout$java_awt_Container$java_awt_Component(this.$finals$.c, this.b$['org.opensourcephysics.display.TextPanel']);
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
} else {
this.$finals$.c.validate$();
}});
})()
), Clazz.new_(P$.TextPanel$1.$init$,[this, {c:c}]));
if ($I$(5).isEventDispatchThread$()) {
runner.run$();
} else {
$I$(5).invokeLater$Runnable(runner);
}});

Clazz.newMeth(C$, 'setMessageFont$java_awt_Font', function (font) {
this.$font=font;
});

Clazz.newMeth(C$, 'getPreferredSize$', function () {
var c=this.getParent$();
var text=this.text;
if ((c == null ) || text.equals$O("") ) {
return C$.ZEROSIZE;
}var g2=c.getGraphics$();
if (g2 == null ) {
return C$.ZEROSIZE;
}var oldFont=g2.getFont$();
g2.setFont$java_awt_Font(this.$font);
var fm=g2.getFontMetrics$();
var boxHeight=fm.getAscent$() + 4;
var boxWidth=fm.stringWidth$S(text) + 6;
g2.setFont$java_awt_Font(oldFont);
g2.dispose$();
return Clazz.new_($I$(1,1).c$$I$I,[boxWidth, boxHeight]);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
var text=this.text;
if (!this.dim.equals$O(this.getPreferredSize$())) {
this.dim=this.getPreferredSize$();
this.setSize$java_awt_Dimension(this.dim);
}if (text.equals$O("") || !this.isVisible$() ) {
return;
}var g2=g;
var w=this.getWidth$();
var h=this.getHeight$();
var oldColor=g2.getColor$();
var oldFont=g2.getFont$();
g2.setColor$java_awt_Color(this.backgroundColor);
g2.fillRect$I$I$I$I(0, 0, w, h);
g2.setColor$java_awt_Color(this.textColor);
g2.setFont$java_awt_Font(this.$font);
g2.drawString$S$I$I(text, 3, h - 4);
g2.setColor$java_awt_Color($I$(2).black);
g2.drawRect$I$I$I$I(0, 0, w - 1, h - 1);
g2.setFont$java_awt_Font(oldFont);
g2.setColor$java_awt_Color(oldColor);
});

C$.$static$=function(){C$.$static$=0;
C$.ZEROSIZE=Clazz.new_($I$(1,1).c$$I$I,[0, 0]);
};
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:23 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
