(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),p$1={},I$=[[0,'java.util.Arrays']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SortDecorator", null, null, ['javax.swing.table.TableModel', 'javax.swing.event.TableModelListener']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['sortedColumn'],'O',['realModel','javax.swing.table.TableModel','indexes','int[]']]]

Clazz.newMeth(C$, 'c$$javax_swing_table_TableModel', function (model) {
;C$.$init$.apply(this);
if (model == null ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["null models are not allowed"]);
}this.realModel=model;
this.realModel.addTableModelListener$javax_swing_event_TableModelListener(this);
p$1.allocate.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'getSortedRow$I', function (realModelRow) {
for (var i=0; i < this.indexes.length; i++) {
if (this.indexes[i] == realModelRow) return i;
}
return -1;
});

Clazz.newMeth(C$, 'getValueAt$I$I', function (row, column) {
if (column >= this.getColumnCount$()) {
return null;
}if (this.indexes.length <= row) {
p$1.allocate.apply(this, []);
}return this.realModel.getValueAt$I$I(this.indexes[row], column);
});

Clazz.newMeth(C$, 'setValueAt$O$I$I', function (aValue, row, column) {
if (this.indexes.length <= row) {
p$1.allocate.apply(this, []);
}this.realModel.setValueAt$O$I$I(aValue, this.indexes[row], column);
});

Clazz.newMeth(C$, 'tableChanged$javax_swing_event_TableModelEvent', function (e) {
p$1.allocate.apply(this, []);
});

Clazz.newMeth(C$, 'sort$I', function (column) {
this.sortedColumn=column;
var rowCount=this.getRowCount$();
if (this.indexes.length <= rowCount) {
p$1.allocate.apply(this, []);
}try {
if (this.realModel.getColumnClass$I(column) === Clazz.getClass(Double)  || this.realModel.getColumnClass$I(column) === Clazz.getClass(Integer)  ) {
var sortArray=Clazz.array(Double, [rowCount, 2]);
if (this.realModel.getColumnClass$I(column) === Clazz.getClass(Double) ) {
for (var i=0; i < rowCount; i++) {
sortArray[i][0]=this.realModel.getValueAt$I$I(i, column);
sortArray[i][1]=new Double(1.0 * this.indexes[i]);
}
} else {
for (var i=0; i < rowCount; i++) {
sortArray[i][0]=new Double((this.realModel.getValueAt$I$I(i, column)).doubleValue$());
sortArray[i][1]=new Double(1.0 * this.indexes[i]);
}
}$I$(1,"sort$OA$java_util_Comparator",[sortArray, ((P$.SortDecorator$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "SortDecorator$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$DoubleA$DoubleA','compare$O$O'], function (a, b) {
if (a[0] == null  || b[0] == null  ) {
return b[0] === a[0]  ? 0 : b[0] == null  ? -1 : 1;
}return ((b[0]).valueOf() < (a[0]).valueOf() ) ? 1 : (((b[0]).valueOf() > (a[0]).valueOf() ) ? -1 : 0);
});
})()
), Clazz.new_(P$.SortDecorator$1.$init$,[this, null]))]);
for (var i=0; i < rowCount; i++) {
this.indexes[i]=sortArray[i][1].intValue$();
}
} else {
for (var i=0; i < rowCount; i++) {
for (var j=i + 1; j < rowCount; j++) {
if (this.compare$I$I$I(this.indexes[i], this.indexes[j], column) < 0) {
this.swap$I$I(i, j);
}}
}
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getSortedColumn$', function () {
return this.sortedColumn;
});

Clazz.newMeth(C$, 'swap$I$I', function (i, j) {
var tmp=this.indexes[i];
this.indexes[i]=this.indexes[j];
this.indexes[j]=tmp;
});

Clazz.newMeth(C$, 'compare$I$I$I', function (i, j, column) {
var io=this.realModel.getValueAt$I$I(i, column);
var jo=this.realModel.getValueAt$I$I(j, column);
if ((io != null ) && (jo == null ) ) {
return 1;
}if ((io == null ) && (jo != null ) ) {
return -1;
}if ((io == null ) && (jo == null ) ) {
return 0;
}if ((Clazz.instanceOf(io, "java.lang.Integer")) && (Clazz.instanceOf(jo, "java.lang.Integer")) ) {
var a=(io).intValue$();
var b=(jo).intValue$();
return (b < a) ? -1 : ((b > a) ? 1 : 0);
} else if ((Clazz.instanceOf(io, "java.lang.Double")) && (Clazz.instanceOf(jo, "java.lang.Double")) ) {
var a=(io).doubleValue$();
var b=(jo).doubleValue$();
return (b < a ) ? -1 : ((b > a ) ? 1 : 0);
} else if ((Clazz.instanceOf(io, "java.lang.Integer")) && (Clazz.instanceOf(jo, "java.lang.Double")) ) {
var a=(io).intValue$();
var b=(jo).doubleValue$();
return (b < a ) ? -1 : ((b > a ) ? 1 : 0);
} else if ((Clazz.instanceOf(io, "java.lang.Double")) && (Clazz.instanceOf(jo, "java.lang.Integer")) ) {
var a=(io).doubleValue$();
var b=(jo).intValue$();
return (b < a ) ? -1 : ((b > a ) ? 1 : 0);
}var c=jo.toString().compareTo$S(io.toString());
return (c < 0) ? -1 : ((c > 0) ? 1 : 0);
});

Clazz.newMeth(C$, 'allocate', function () {
this.indexes=Clazz.array(Integer.TYPE, [this.getRowCount$()]);
for (var i=0; i < this.indexes.length; ++i) {
this.indexes[i]=i;
}
}, p$1);

Clazz.newMeth(C$, 'reset$', function () {
p$1.allocate.apply(this, []);
this.sortedColumn=-1;
});

Clazz.newMeth(C$, 'getRowCount$', function () {
return this.realModel.getRowCount$();
});

Clazz.newMeth(C$, 'getColumnCount$', function () {
return this.realModel.getColumnCount$();
});

Clazz.newMeth(C$, 'getColumnName$I', function (columnIndex) {
if (columnIndex >= this.getColumnCount$()) {
return "unknown";
}return this.realModel.getColumnName$I(columnIndex);
});

Clazz.newMeth(C$, 'getColumnClass$I', function (columnIndex) {
if (columnIndex >= this.getColumnCount$()) {
return Clazz.getClass(java.lang.Object);
}return this.realModel.getColumnClass$I(columnIndex);
});

Clazz.newMeth(C$, 'isCellEditable$I$I', function (rowIndex, columnIndex) {
if (columnIndex >= this.getColumnCount$()) {
return false;
}return this.realModel.isCellEditable$I$I(rowIndex, columnIndex);
});

Clazz.newMeth(C$, 'addTableModelListener$javax_swing_event_TableModelListener', function (l) {
this.realModel.addTableModelListener$javax_swing_event_TableModelListener(l);
});

Clazz.newMeth(C$, 'removeTableModelListener$javax_swing_event_TableModelListener', function (l) {
this.realModel.removeTableModelListener$javax_swing_event_TableModelListener(l);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-29 00:28:21 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
