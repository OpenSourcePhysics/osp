(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),p$1={},I$=[[0,'org.opensourcephysics.display.Histogram','java.awt.Color',['java.util.Map','.Entry'],'org.opensourcephysics.display.DisplayRes','java.io.BufferedReader','java.io.FileReader','java.util.StringTokenizer','java.util.Arrays','StringBuffer','java.util.HashMap','org.opensourcephysics.display.TeXParser',['java.awt.geom.Rectangle2D','.Double'],'org.opensourcephysics.display.HistogramDataset','java.util.ArrayList',['org.opensourcephysics.display.Histogram','.HistogramLoader']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Histogram", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.table.AbstractTableModel', ['org.opensourcephysics.display.Measurable', 'org.opensourcephysics.display.LogMeasurable', 'org.opensourcephysics.display.Data']);
C$.$classes$=[['HistogramLoader',12]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.logScale=false;
this.adjustForWidth=false;
this.visible=true;
this.measured=true;
this.binFillColor=$I$(2).red;
this.binEdgeColor=$I$(2).red;
this.binStyle=1;
this.binWidth=1;
this.binOffset=0;
this.discrete=true;
this.YMIN=0;
this.entries=Clazz.array($I$(3), [0]);
this.normalizedToOne=false;
this.datasetID=this.hashCode$();
},1);

C$.$fields$=[['Z',['logScale','adjustForWidth','visible','measured','discrete','dataChanged','normalizedToOne'],'D',['binWidth','binOffset','xmin','xmax','ymax','sum','barOffset'],'I',['binStyle','YMIN','datasetID'],'S',['name','binColumnName','xColumnName','yColumnName'],'O',['histogramDataset','org.opensourcephysics.display.HistogramDataset','binFillColor','java.awt.Color','+binEdgeColor','bins','java.util.HashMap','entries','java.util.Map.Entry[]']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.binColumnName=$I$(4).getString$S("Histogram.Column.BinNumber");
this.xColumnName="x";
this.yColumnName=$I$(4).getString$S("Histogram.Column.Occurrences");
this.name=$I$(4).getString$S("Histogram.Title");
this.clear$();
}, 1);

Clazz.newMeth(C$, 'read$S', function (inputPathName) {
var reader=Clazz.new_([Clazz.new_($I$(6,1).c$$S,[inputPathName])],$I$(5,1).c$$java_io_Reader);
var s=null;
while ((s=reader.readLine$()) != null ){
s=s.trim$();
if (s.equals$O("") || (s.length$() == 0) || (s.charAt$I(0) == "#")  ) {
continue;
}try {
var st=Clazz.new_($I$(7,1).c$$S$S,[s, "\t"]);
var binNumber=Integer.parseInt$S(st.nextToken$());
var numberOfoccurrences=Double.parseDouble$S(st.nextToken$());
var prioroccurrences=this.bins.get$O( new Integer(binNumber));
if (prioroccurrences == null ) {
this.bins.put$O$O( new Integer(binNumber),  new Double(numberOfoccurrences));
} else {
numberOfoccurrences += prioroccurrences.doubleValue$();
this.bins.put$O$O( new Integer(binNumber),  new Double(numberOfoccurrences));
}this.ymax=Math.max(numberOfoccurrences, this.ymax);
this.xmin=Math.min(binNumber * this.binWidth + this.binOffset, this.xmin);
this.xmax=Math.max(binNumber * this.binWidth + this.binWidth + this.binOffset, this.xmax);
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"java.util.NoSuchElementException")){
var nsee = e$$;
{
nsee.printStackTrace$();
}
} else if (Clazz.exceptionOf(e$$,"NumberFormatException")){
var nfe = e$$;
{
nfe.printStackTrace$();
}
} else {
throw e$$;
}
}
}
reader.close$();
this.dataChanged=true;
});

Clazz.newMeth(C$, 'toSortedString$', function () {
var keySet=this.bins.keySet$();
var keys=keySet.toArray$();
$I$(8).sort$OA(keys);
var s="x\tx";
var buf=Clazz.new_([s.length$() * keys.length],$I$(9,1).c$$I);
for (var i=0; i < keys.length; i++) {
var key=keys[i];
buf.append$O(key);
buf.append$S("\t");
buf.append$O(this.bins.get$O(keys[i]));
buf.append$S("\n");
}
return buf.toString();
});

Clazz.newMeth(C$, 'toString', function () {
var set=this.bins.keySet$();
var keys=set.iterator$();
var s="x\tx";
var buf=Clazz.new_([s.length$() * set.size$()],$I$(9,1).c$$I);
while (keys.hasNext$()){
var binNumber=keys.next$();
var occurrences=this.bins.get$O(binNumber);
buf.append$O(binNumber);
buf.append$S("\t");
buf.append$O(occurrences);
buf.append$S("\n");
}
return buf.toString();
});

Clazz.newMeth(C$, 'hashCode$D', function (value) {
return ((Math.floor((value - this.binOffset) / this.binWidth))|0);
});

Clazz.newMeth(C$, 'append$D$D', function (value, numberOfoccurrences) {
this.sum += numberOfoccurrences;
var binNumber=this.hashCode$D(value);
var occurrences=this.bins.get$O( new Integer(binNumber));
if (occurrences == null ) {
this.bins.put$O$O( new Integer(binNumber),  new Double(numberOfoccurrences));
} else {
numberOfoccurrences += occurrences.doubleValue$();
this.bins.put$O$O( new Integer(binNumber),  new Double(numberOfoccurrences));
}this.ymax=Math.max(numberOfoccurrences, this.ymax);
this.xmin=Math.min(binNumber * this.binWidth + this.binOffset, this.xmin);
this.xmax=Math.max(binNumber * this.binWidth + this.binWidth + this.binOffset, this.xmax);
this.dataChanged=true;
});

Clazz.newMeth(C$, 'append$D', function (value) {
this.append$D$D(value, 1);
});

Clazz.newMeth(C$, 'append$S', function (inputPathName) {
var br=Clazz.new_([Clazz.new_($I$(6,1).c$$S,[inputPathName])],$I$(5,1).c$$java_io_Reader);
var s=null;
while ((s=br.readLine$()) != null ){
s=s.trim$();
if (s.equals$O("") || (s.length$() == 0) || (s.charAt$I(0) == "#")  ) {
continue;
}try {
var d=Double.parseDouble$S(s);
this.append$D$D(d, 1);
} catch (nfe) {
if (Clazz.exceptionOf(nfe,"NumberFormatException")){
nfe.printStackTrace$();
} else {
throw nfe;
}
}
}
br.close$();
});

Clazz.newMeth(C$, 'append$DA', function (values) {
for (var i=0; i < values.length; i++) {
this.append$D$D(values[i], 1);
}
});

Clazz.newMeth(C$, 'setVisible$Z', function (visibility) {
this.visible=visibility;
});

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (drawingPanel, g) {
if (this.bins.size$() == 0 || !this.visible ) {
return;
}g=g.create$();
g.setColor$java_awt_Color(this.binFillColor);
g.clipRect$I$I$I$I(0, 0, drawingPanel.getWidth$(), drawingPanel.getHeight$());
for (var keys=this.bins.keySet$().iterator$(); keys.hasNext$(); ) {
var binNumber=keys.next$();
var d=(this.bins.get$O(binNumber));
if (d == null ) {
break;
}var occurrences=d.doubleValue$();
if (this.normalizedToOne) {
occurrences /= this.sum;
}if (this.binStyle == 1) {
this.drawBin$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics$I$D(drawingPanel, g, binNumber.intValue$(), occurrences);
} else {
this.drawPoint$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics$I$D(drawingPanel, g, binNumber.intValue$(), occurrences);
}}
g.dispose$();
});

Clazz.newMeth(C$, 'clear$', function () {
this.bins=Clazz.new_($I$(10,1));
this.xmin=2147483647;
this.xmax=-2147483648;
this.ymax=-2147483648;
this.sum=0;
this.dataChanged=true;
});

Clazz.newMeth(C$, 'entries$', function () {
p$1.updateEntries.apply(this, []);
return this.entries;
});

Clazz.newMeth(C$, 'setBinStyle$I', function (style) {
this.binStyle=style;
});

Clazz.newMeth(C$, 'setDiscrete$Z', function (_discrete) {
this.discrete=_discrete;
});

Clazz.newMeth(C$, 'setBinOffset$D', function (_binOffset) {
this.binOffset=_binOffset;
});

Clazz.newMeth(C$, 'setBarOffset$D', function (_barOffset) {
this.barOffset=_barOffset;
});

Clazz.newMeth(C$, 'getLineColor$', function () {
return this.binEdgeColor;
});

Clazz.newMeth(C$, 'getLineColors$', function () {
return Clazz.array($I$(2), -1, [this.binEdgeColor, this.binEdgeColor]);
});

Clazz.newMeth(C$, 'getFillColor$', function () {
return this.binFillColor;
});

Clazz.newMeth(C$, 'getFillColors$', function () {
return Clazz.array($I$(2), -1, [this.binFillColor, this.binFillColor]);
});

Clazz.newMeth(C$, 'setBinColor$java_awt_Color', function (binColor) {
this.binFillColor=binColor;
this.binEdgeColor=binColor;
});

Clazz.newMeth(C$, 'setBinColor$java_awt_Color$java_awt_Color', function (fillColor, edgeColor) {
this.binFillColor=fillColor;
this.binEdgeColor=edgeColor;
});

Clazz.newMeth(C$, 'setBinWidth$D', function (_binWidth) {
this.binWidth=_binWidth;
});

Clazz.newMeth(C$, 'setName$S', function (name) {
this.name=$I$(11).parseTeX$S(name);
});

Clazz.newMeth(C$, 'getName$', function () {
return this.name;
});

Clazz.newMeth(C$, 'getColumnNames$', function () {
return Clazz.array(String, -1, [this.xColumnName, this.yColumnName]);
});

Clazz.newMeth(C$, 'getDataList$', function () {
return null;
});

Clazz.newMeth(C$, 'setXYColumnNames$S$S', function (_xColumnName, _yColumnName) {
this.xColumnName=$I$(11).parseTeX$S(_xColumnName);
this.yColumnName=$I$(11).parseTeX$S(_yColumnName);
});

Clazz.newMeth(C$, 'setXYColumnNames$S$S$S', function (_xColumnName, _yColumnName, _name) {
this.xColumnName=$I$(11).parseTeX$S(_xColumnName);
this.yColumnName=$I$(11).parseTeX$S(_yColumnName);
this.name=$I$(11).parseTeX$S(_name);
});

Clazz.newMeth(C$, 'setNormalizedToOne$Z', function (b) {
this.normalizedToOne=b;
});

Clazz.newMeth(C$, 'getBinWidth$', function () {
return this.binWidth;
});

Clazz.newMeth(C$, 'getBinOffset$', function () {
return this.binOffset;
});

Clazz.newMeth(C$, 'getXMin$', function () {
return (this.discrete && (this.bins.size$() > 1) ) ? this.xmin - this.binWidth : this.xmin;
});

Clazz.newMeth(C$, 'getXMax$', function () {
return this.xmax;
});

Clazz.newMeth(C$, 'getYMin$', function () {
return 0;
});

Clazz.newMeth(C$, 'getYMax$', function () {
var max=(this.normalizedToOne ? this.ymax / this.sum : this.ymax);
if (this.adjustForWidth) {
max=max / this.getBinWidth$();
}if (this.logScale) {
max=Math.log(max);
}return max;
});

Clazz.newMeth(C$, 'getXMinLogscale$', function () {
var xmin=this.getXMin$();
if (xmin > 0 ) {
return xmin;
}return this.binOffset;
});

Clazz.newMeth(C$, 'getXMaxLogscale$', function () {
var xmax=this.getXMax$();
if (xmax > 0 ) {
return xmax;
}return this.binOffset + 10;
});

Clazz.newMeth(C$, 'getYMinLogscale$', function () {
return 1;
});

Clazz.newMeth(C$, 'getYMaxLogscale$', function () {
return Math.max(10, this.getYMax$());
});

Clazz.newMeth(C$, 'isMeasured$', function () {
return this.bins.size$() > 0 && this.measured ;
});

Clazz.newMeth(C$, 'setMeasured$Z', function (measure) {
this.measured=measure;
});

Clazz.newMeth(C$, 'getColumnName$I', function (column) {
if (column == 0) {
return this.binColumnName;
} else if (column == 1) {
return this.xColumnName;
} else {
return this.yColumnName;
}});

Clazz.newMeth(C$, 'getRowCount$', function () {
return this.bins.size$();
});

Clazz.newMeth(C$, 'getColumnCount$', function () {
return 3;
});

Clazz.newMeth(C$, 'getValueAt$I$I', function (row, column) {
p$1.updateEntries.apply(this, []);
var entry=this.entries[row];
if (column == 0) {
return entry.getKey$();
}if (column == 1) {
return  new Double((entry.getKey$()).doubleValue$() * this.binWidth + this.binWidth / 2.0 + this.binOffset);
}if (this.normalizedToOne) {
var d=entry.getValue$();
return  new Double(d.doubleValue$() / this.sum);
}return entry.getValue$();
});

Clazz.newMeth(C$, 'getColumnClass$I', function (columnIndex) {
return ((columnIndex == 0) ? Clazz.getClass(Integer) : Clazz.getClass(Double));
});

Clazz.newMeth(C$, 'setID$I', function (id) {
this.datasetID=id;
});

Clazz.newMeth(C$, 'getID$', function () {
return this.datasetID;
});

Clazz.newMeth(C$, 'drawPoint$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics$I$D', function (drawingPanel, g, binNumber, occurrences) {
var px=drawingPanel.xToPix$D(this.getLeftMostBinPosition$I(binNumber));
var py=drawingPanel.yToPix$D(occurrences);
var pointRadius=2;
if (this.discrete) {
g.fillRect$I$I$I$I(px - pointRadius, py - pointRadius, pointRadius * 2, pointRadius * 2);
} else {
var px2=drawingPanel.xToPix$D(this.getRightMostBinPosition$I(binNumber));
var pWidth=px2 - px;
g.fillRect$I$I$I$I(px, py, pWidth, pointRadius * 2);
}});

Clazz.newMeth(C$, 'drawBin$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics$I$D', function (drawingPanel, g, binNumber, occurrences) {
if (this.adjustForWidth) {
occurrences=occurrences / this.getBinWidth$();
}if (this.logScale) {
occurrences=Math.max(0, Math.log(occurrences));
}var binlx=drawingPanel.xToPix$D(this.getLeftMostBinPosition$I(binNumber));
if (this.discrete) {
if (this.binEdgeColor != null ) {
g.setColor$java_awt_Color(this.binEdgeColor);
g.drawLine$I$I$I$I(binlx, drawingPanel.yToPix$D(0), binlx, drawingPanel.yToPix$D(occurrences));
}} else {
var binrx=drawingPanel.xToPix$D(this.getRightMostBinPosition$I(binNumber));
var pWidth=binrx - binlx;
var pHeight=drawingPanel.getYPixPerUnit$() * occurrences;
var rect=Clazz.new_([binlx, drawingPanel.yToPix$D(occurrences), pWidth, pHeight],$I$(12,1).c$$D$D$D$D);
var g2=g;
if (this.binFillColor != null ) {
g.setColor$java_awt_Color(this.binFillColor);
g2.fill$java_awt_Shape(rect);
}if (this.binEdgeColor != null ) {
g.setColor$java_awt_Color(this.binEdgeColor);
g2.draw$java_awt_Shape(rect);
}}});

Clazz.newMeth(C$, 'getXPoints$', function () {
var nbins=1 + (((this.xmax - this.xmin) / this.binWidth)|0);
if (nbins < 1) {
return Clazz.array(Double.TYPE, [0]);
}var xdata=Clazz.array(Double.TYPE, [nbins]);
for (var i=0; i < nbins; i++) {
xdata[i]=this.xmin + i * this.binWidth + this.binOffset + this.binWidth / 2;
}
return xdata;
});

Clazz.newMeth(C$, 'getYPoints$', function () {
var nbins=1 + (((this.xmax - this.xmin) / this.binWidth)|0);
if (nbins < 1) {
return Clazz.array(Double.TYPE, [0]);
}var ydata=Clazz.array(Double.TYPE, [nbins]);
for (var i=0; i < nbins; i++) {
var binNumber= new Integer(i);
var bin=this.bins.get$O(binNumber);
ydata[i]=(bin == null ) ? 0 : bin.doubleValue$();
}
return ydata;
});

Clazz.newMeth(C$, 'getPoints$', function () {
var nbins=1 + (((this.xmax - this.xmin) / this.binWidth)|0);
if (nbins < 1) {
return Clazz.array(Double.TYPE, [2, 0]);
}var data=Clazz.array(Double.TYPE, [2, nbins]);
var iStart=((this.xmin / this.binWidth)|0);
for (var i=0; i < nbins; i++) {
var binNumber= new Integer(i + iStart);
var bin=this.bins.get$O(binNumber);
data[0][i]=this.xmin + i * this.binWidth + this.binOffset + this.binWidth / 2;
data[1][i]=(bin == null ) ? 0 : bin.doubleValue$();
}
return data;
});

Clazz.newMeth(C$, 'getLogPoints$', function () {
var nbins=(Math.round((this.xmax - this.xmin) / this.binWidth)|0);
if (nbins < 1) {
return Clazz.array(Double.TYPE, [2, 0]);
}var data=Clazz.array(Double.TYPE, [2, nbins]);
var iStart=((this.xmin / this.binWidth)|0);
for (var i=0; i < nbins; i++) {
var binNumber= new Integer(i + iStart);
var bin=this.bins.get$O(binNumber);
data[0][i]=this.xmin + i * this.binWidth + this.binOffset + this.binWidth / 2;
data[1][i]=(bin == null ) ? 0 : bin.doubleValue$();
data[1][i]=(data[1][i] > 0 ) ? Math.log(data[1][i]) : 0;
}
return data;
});

Clazz.newMeth(C$, 'getLeftMostBinPosition$I', function (binNumber) {
return binNumber * this.binWidth + this.binOffset + this.binWidth * this.barOffset;
});

Clazz.newMeth(C$, 'getRightMostBinPosition$I', function (binNumber) {
return binNumber * this.binWidth + this.binWidth + this.binOffset + this.binWidth * this.barOffset;
});

Clazz.newMeth(C$, 'updateEntries', function () {
if (this.dataChanged) {
this.entries=this.bins.entrySet$().toArray$OA(this.entries);
this.dataChanged=false;
}}, p$1);

Clazz.newMeth(C$, 'getData2D$', function () {
var data=(this.logScale) ? this.getLogPoints$() : this.getPoints$();
return data;
});

Clazz.newMeth(C$, 'getData3D$', function () {
return null;
});

Clazz.newMeth(C$, 'getDatasets$', function () {
var data=(this.logScale) ? this.getLogPoints$() : this.getPoints$();
var bins=data[0];
var vals=data[1];
var start=0;
var stop=this.getBinWidth$();
if ((bins != null ) && (bins.length > 0) ) {
start=bins[0] - this.getBinWidth$() / 2;
stop=bins[bins.length - 1] + this.getBinWidth$() / 2;
}if (this.histogramDataset == null ) {
this.histogramDataset=Clazz.new_([start, stop, this.getBinWidth$()],$I$(13,1).c$$D$D$D);
} else {
this.histogramDataset.clear$();
this.histogramDataset.setBinWidth$D$D$D(start, stop, this.getBinWidth$());
}this.histogramDataset.setXYColumnNames$S$S$S(this.xColumnName, this.yColumnName, this.name);
this.histogramDataset.append$DA$DA(bins, vals);
this.histogramDataset.setMarkerColor$java_awt_Color$java_awt_Color(this.binFillColor, this.binEdgeColor);
var list=Clazz.new_($I$(14,1));
list.add$O(this.histogramDataset);
return list;
});

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(15,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.Histogram, "HistogramLoader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'org.opensourcephysics.controls.XMLLoader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var his=obj;
var points=(his.logScale) ? his.getLogPoints$() : his.getPoints$();
var bins=points[0];
var vals=points[1];
control.setValue$S$Z("log_scale", his.logScale);
control.setValue$S$Z("discrete", his.discrete);
control.setValue$S$Z("adjust_for_width", his.adjustForWidth);
control.setValue$S$O("bin_fill_color", his.binFillColor);
control.setValue$S$O("bin_edge_color", his.binEdgeColor);
control.setValue$S$I("bin_style", his.binStyle);
control.setValue$S$D("bin_width", his.binWidth);
control.setValue$S$D("bin_offset", his.binOffset);
control.setValue$S$O("name", his.name);
control.setValue$S$O("x_column_name", his.xColumnName);
control.setValue$S$O("y_column_name", his.yColumnName);
control.setValue$S$O("bin_column_name", his.binColumnName);
control.setValue$S$O("bins", bins);
control.setValue$S$O("vals", vals);
});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(1,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var his=obj;
var bins=control.getObject$S("bins");
var vals=control.getObject$S("vals");
his.name=control.getString$S("name");
his.xColumnName=control.getString$S("x_column_name");
his.yColumnName=control.getString$S("y_column_name");
his.binColumnName=control.getString$S("bin_column_name");
his.logScale=control.getBoolean$S("log_scale");
his.discrete=control.getBoolean$S("discrete");
his.adjustForWidth=control.getBoolean$S("adjust_for_width");
his.binFillColor=control.getObject$S("bin_fill_color");
his.binEdgeColor=control.getObject$S("bin_edge_color");
his.binStyle=control.getInt$S("bin_style");
his.binWidth=control.getDouble$S("bin_width");
his.binOffset=control.getDouble$S("bin_offset");
his.adjustForWidth=control.getBoolean$S("adjust_for_width");
if ((bins != null ) && (vals != null ) ) {
for (var i=0, n=bins.length; i < n; i++) {
his.append$D$D(bins[i], vals[i]);
}
}return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 21:42:01 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
