(function(){var P$=Clazz.newPackage("org.opensourcephysics.display.axes"),I$=[[0,'org.opensourcephysics.display.axes.CartesianInteractive','org.opensourcephysics.display.axes.CartesianType2','org.opensourcephysics.display.axes.CartesianType3']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CartesianType1Factory", null, 'org.opensourcephysics.display.axes.AxisFactory');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'createAxes$org_opensourcephysics_display_PlottingPanel', function (panel) {
return Clazz.new_($I$(1,1).c$$org_opensourcephysics_display_PlottingPanel,[panel]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:23 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
