(function(){var P$=Clazz.newPackage("org.opensourcephysics.display.axes"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DrawableAxes", null, null, 'org.opensourcephysics.display.Drawable');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-26 22:52:33 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
