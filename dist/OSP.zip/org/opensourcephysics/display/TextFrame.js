(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[[0,'org.opensourcephysics.display.OSPRuntime','java.awt.RenderingHints','javax.swing.JTextPane','javax.swing.JScrollPane',['javax.swing.event.HyperlinkEvent','.EventType'],'org.opensourcephysics.desktop.OSPDesktop','org.opensourcephysics.desktop.ostermiller.Browser','org.opensourcephysics.tools.ResourceLoader','org.opensourcephysics.controls.OSPLog']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TextFrame", null, 'javax.swing.JFrame');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.textPane=((P$.TextFrame$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "TextFrame$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.JTextPane'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]]

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
if (($I$(1).antiAliasText).valueOf()) {
var g2=g;
var rh=g2.getRenderingHints$();
rh.put$O$O($I$(2).KEY_TEXT_ANTIALIASING, $I$(2).VALUE_TEXT_ANTIALIAS_ON);
rh.put$O$O($I$(2).KEY_ANTIALIASING, $I$(2).VALUE_ANTIALIAS_ON);
}C$.superclazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
});
})()
), Clazz.new_($I$(3,1),[this, null],P$.TextFrame$1));
},1);

C$.$fields$=[['O',['hyperlinkListener','javax.swing.event.HyperlinkListener','textPane','javax.swing.JTextPane','textScroller','javax.swing.JScrollPane']]]

Clazz.newMeth(C$, 'c$', function () {
C$.c$$S$Class.apply(this, [null, null]);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (resourceName) {
C$.c$$S$Class.apply(this, [resourceName, null]);
}, 1);

Clazz.newMeth(C$, 'c$$S$Class', function (resourceName, location) {
Clazz.super_(C$, this);
this.setSize$I$I(300, 300);
this.textPane.setEditable$Z(false);
this.textScroller=Clazz.new_($I$(4,1).c$$java_awt_Component,[this.textPane]);
this.setContentPane$java_awt_Container(this.textScroller);
if (resourceName != null ) {
this.loadResource$S$Class(resourceName, location);
}}, 1);

Clazz.newMeth(C$, 'getTextPane$', function () {
return this.textPane;
});

Clazz.newMeth(C$, 'enableHyperlinks$', function () {
if (this.hyperlinkListener != null ) {
this.textPane.removeHyperlinkListener$javax_swing_event_HyperlinkListener(this.hyperlinkListener);
}this.hyperlinkListener=((P$.TextFrame$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "TextFrame$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.HyperlinkListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'hyperlinkUpdate$javax_swing_event_HyperlinkEvent', function (e) {
if (e.getEventType$() === $I$(5).ACTIVATED ) {
try {
this.b$['org.opensourcephysics.display.TextFrame'].textPane.setPage$java_net_URL(e.getURL$());
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
} else {
throw ex;
}
}
}});
})()
), Clazz.new_(P$.TextFrame$2.$init$,[this, null]));
this.textPane.addHyperlinkListener$javax_swing_event_HyperlinkListener(this.hyperlinkListener);
});

Clazz.newMeth(C$, 'enableDesktopHyperlinks$', function () {
if (this.hyperlinkListener != null ) {
this.textPane.removeHyperlinkListener$javax_swing_event_HyperlinkListener(this.hyperlinkListener);
}this.hyperlinkListener=((P$.TextFrame$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "TextFrame$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.HyperlinkListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'hyperlinkUpdate$javax_swing_event_HyperlinkEvent', function (e) {
if (e.getEventType$() === $I$(5).ACTIVATED ) {
try {
if (!$I$(6,"browse$java_net_URI",[e.getURL$().toURI$()])) {
$I$(7).init$();
$I$(7,"displayURL$S",[e.getURL$().toString()]);
}} catch (e1) {
if (Clazz.exceptionOf(e1,"Exception")){
} else {
throw e1;
}
}
}});
})()
), Clazz.new_(P$.TextFrame$3.$init$,[this, null]));
this.textPane.addHyperlinkListener$javax_swing_event_HyperlinkListener(this.hyperlinkListener);
});

Clazz.newMeth(C$, 'disableHyperlinks$', function () {
if (this.hyperlinkListener != null ) {
this.textPane.removeHyperlinkListener$javax_swing_event_HyperlinkListener(this.hyperlinkListener);
}this.hyperlinkListener=null;
});

Clazz.newMeth(C$, 'loadResource$S$Class', function (resourceName, location) {
var res=null;
try {
res=$I$(8).getResource$S$Class(resourceName, location);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
$I$(9).fine$S("Error getting resource: " + resourceName);
return false;
} else {
throw ex;
}
}
if (res == null ) {
$I$(9).fine$S("Resource not found: " + resourceName);
return false;
}try {
this.textPane.setPage$java_net_URL(res.getURL$());
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
$I$(9).fine$S("Resource not loadeded: " + resourceName);
return false;
} else {
throw ex;
}
}
this.setTitle$S(resourceName);
return true;
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-26 22:52:33 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
