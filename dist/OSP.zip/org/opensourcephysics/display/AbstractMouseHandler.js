(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "AbstractMouseHandler", null, null, 'org.opensourcephysics.display.InteractiveMouseHandler');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mouseClicked$org_opensourcephysics_display_InteractivePanel', function (panel) {
});

Clazz.newMeth(C$, 'mouseEntered$org_opensourcephysics_display_InteractivePanel', function (panel) {
});

Clazz.newMeth(C$, 'mouseExited$org_opensourcephysics_display_InteractivePanel', function (panel) {
});

Clazz.newMeth(C$, 'mousePressed$org_opensourcephysics_display_InteractivePanel', function (panel) {
});

Clazz.newMeth(C$, 'mouseReleased$org_opensourcephysics_display_InteractivePanel', function (panel) {
});

Clazz.newMeth(C$, 'mouseDragged$org_opensourcephysics_display_InteractivePanel', function (panel) {
});

Clazz.newMeth(C$, 'mouseMoved$org_opensourcephysics_display_InteractivePanel', function (panel) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:21 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
