(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[[0,'org.opensourcephysics.display.DataRowTable','javax.swing.JScrollPane','java.awt.BorderLayout']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DataPanel", null, 'javax.swing.JPanel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.table=Clazz.new_($I$(1,1));
this.scrollPane=Clazz.new_($I$(2,1).c$$java_awt_Component,[this.table]);
},1);

C$.$fields$=[['O',['table','org.opensourcephysics.display.DataRowTable','scrollPane','javax.swing.JScrollPane']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(3,1)));
this.add$java_awt_Component$O(this.scrollPane, "Center");
}, 1);

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'setFont$java_awt_Font', function (font) {
C$.superclazz.prototype.setFont$java_awt_Font.apply(this, [font]);
if (this.table != null ) this.table.setFont$java_awt_Font(font);
});

Clazz.newMeth(C$, 'setForeground$java_awt_Color', function (color) {
C$.superclazz.prototype.setForeground$java_awt_Color.apply(this, [color]);
if (this.table != null ) this.table.setForeground$java_awt_Color(color);
});

Clazz.newMeth(C$, 'refreshTable$S', function (from) {
this.table.refreshTable$S(from);
});

Clazz.newMeth(C$, 'getVisual$', function () {
return this.table;
});

Clazz.newMeth(C$, 'setColumnNames$I$S', function (column, name) {
if (this.table.$rowModel.setColumnNames$I$S(column, name)) {
this.refreshTable$S("setColumnName");
}});

Clazz.newMeth(C$, 'setColumnNames$SA', function (names) {
var changed=false;
for (var i=0, n=names.length; i < n; i++) {
if (this.table.$rowModel.setColumnNames$I$S(i, names[i])) {
changed=true;
}}
if (changed) {
this.refreshTable$S("setColumnNames");
}});

Clazz.newMeth(C$, 'setRowNumberVisible$Z', function (vis) {
if (this.table.$rowModel.setRowNumberVisible$Z(vis)) {
this.refreshTable$S("setRowNumberVis " + vis);
}});

Clazz.newMeth(C$, 'setFirstRowIndex$I', function (index) {
if (this.table.$rowModel.firstRowIndex != index) {
this.table.$rowModel.firstRowIndex=index;
this.refreshTable$S("setFirstRowIndex " + index);
}});

Clazz.newMeth(C$, 'setRefreshDelay$I', function (delay) {
this.table.setRefreshDelay$I(delay);
});

Clazz.newMeth(C$, 'appendArray$O', function (obj) {
if (!obj.getClass$().isArray$()) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,[""]);
}var componentType=obj.getClass$().getComponentType$();
while (componentType.isArray$()){
componentType=componentType.getComponentType$();
}
var type=componentType.getName$();
if (type.equals$O("double")) {
var array=obj;
var row=Clazz.array(Double.TYPE, [array.length]);
for (var i=0, n=array[0].length; i < n; i++) {
for (var j=0, m=row.length; j < m; j++) {
row[j]=array[j][i];
}
this.appendRow$DA(row);
}
} else if (type.equals$O("int")) {
var array=obj;
var row=Clazz.array(Integer.TYPE, [array.length]);
for (var i=0, n=array[0].length; i < n; i++) {
for (var j=0, m=row.length; j < m; j++) {
row[j]=array[j][i];
}
this.appendRow$IA(row);
}
} else if (type.equals$O("byte")) {
var array=obj;
var row=Clazz.array(Byte.TYPE, [array.length]);
for (var i=0, n=array[0].length; i < n; i++) {
for (var j=0, m=row.length; j < m; j++) {
row[j]=array[j][i];
}
this.appendRow$BA(row);
}
} else {
var array=obj;
var row=Clazz.array(java.lang.Object, [array.length]);
for (var i=0, n=array[0].length; i < n; i++) {
for (var j=0, m=row.length; j < m; j++) {
row[j]=array[j][i];
}
this.appendRow$OA(row);
}
}});

Clazz.newMeth(C$, 'appendRow$DA', function (x) {
this.table.$rowModel.appendDoubles$DA(x);
if (this.isShowing$()) {
this.table.refreshTable$S("appendRow");
}});

Clazz.newMeth(C$, 'appendRow$IA', function (x) {
this.table.$rowModel.appendInts$IA(x);
if (this.isShowing$()) {
this.table.refreshTable$S("appendRow");
}});

Clazz.newMeth(C$, 'appendRow$OA', function (x) {
this.table.$rowModel.appendRow$O(x);
if (this.isShowing$()) {
this.table.refreshTable$S("appendRow");
}});

Clazz.newMeth(C$, 'appendRow$BA', function (x) {
this.table.$rowModel.appendBytes$BA(x);
if (this.isShowing$()) {
this.table.refreshTable$S("appendRow");
}});

Clazz.newMeth(C$, 'isRowNumberVisible$', function () {
return this.table.$rowModel.rowNumberVisible;
});

Clazz.newMeth(C$, 'getColumnCount$', function () {
return this.table.$rowModel.getColumnCount$();
});

Clazz.newMeth(C$, 'getRowCount$', function () {
return this.table.$rowModel.getRowCount$();
});

Clazz.newMeth(C$, 'getTotalRowCount$', function () {
return this.table.$rowModel.rowList.size$();
});

Clazz.newMeth(C$, 'getStride$', function () {
return this.table.$rowModel.stride;
});

Clazz.newMeth(C$, 'setColumnFormat$I$S', function (column, format) {
this.table.setColumnFormat$I$S(column, format);
});

Clazz.newMeth(C$, 'clearFormats$', function () {
this.table.clearFormats$();
});

Clazz.newMeth(C$, 'setNumericFormat$S', function (pattern) {
this.table.setNumericFormat$S(pattern);
});

Clazz.newMeth(C$, 'setMaxPoints$I', function (max) {
this.table.$rowModel.setMaxPoints$I(max);
});

Clazz.newMeth(C$, 'setVisible$Z', function (vis) {
if (vis) {
this.table.refreshTable$S(" vis " + vis);
}C$.superclazz.prototype.setVisible$Z.apply(this, [vis]);
});

Clazz.newMeth(C$, 'setStride$I', function (stride) {
this.table.setStride$I(stride);
});

Clazz.newMeth(C$, 'clearData$', function () {
this.table.clearData$();
});

Clazz.newMeth(C$, 'clear$', function () {
this.table.clear$();
});

Clazz.newMeth(C$, 'setAutoResizeMode$I', function (mode) {
this.table.setAutoResizeMode$I(mode);
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-29 00:28:20 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
