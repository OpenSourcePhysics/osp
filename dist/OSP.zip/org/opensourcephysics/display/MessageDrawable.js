(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[[0,'java.awt.Font','org.opensourcephysics.tools.FontSizer','java.awt.Color']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MessageDrawable", null, null, 'org.opensourcephysics.display.Drawable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.tlStr=null;
this.trStr=null;
this.blStr=null;
this.brStr=null;
this.fontname="TimesRoman";
this.fontsize=14;
this.fontstyle=0;
},1);

C$.$fields$=[['I',['fontsize','fontstyle'],'S',['tlStr','trStr','blStr','brStr','fontname'],'O',['font','java.awt.Font','guiChangeListener','java.beans.PropertyChangeListener']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
this.font=Clazz.new_($I$(1,1).c$$S$I$I,[this.fontname, this.fontstyle, this.fontsize]);
this.guiChangeListener=((P$.MessageDrawable$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "MessageDrawable$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.beans.PropertyChangeListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
if (e.getPropertyName$().equals$O("level")) {
var level=(e.getNewValue$()).intValue$();
this.b$['org.opensourcephysics.display.MessageDrawable'].setFontLevel$I.apply(this.b$['org.opensourcephysics.display.MessageDrawable'], [level]);
}});
})()
), Clazz.new_(P$.MessageDrawable$1.$init$,[this, null]));
$I$(2).addPropertyChangeListener$S$java_beans_PropertyChangeListener("level", this.guiChangeListener);
}, 1);

Clazz.newMeth(C$, 'setFontLevel$I', function (level) {
this.font=$I$(2).getResizedFont$java_awt_Font$I(this.font, level);
});

Clazz.newMeth(C$, 'setFontFactor$D', function (factor) {
this.font=$I$(2).getResizedFont$java_awt_Font$D(this.font, factor);
});

Clazz.newMeth(C$, 'setMessage$S', function (msg) {
this.brStr=msg;
});

Clazz.newMeth(C$, 'setMessage$S$I', function (msg, location) {
switch (location) {
case 0:
this.blStr=msg;
break;
case 1:
this.brStr=msg;
break;
case 2:
this.trStr=msg;
break;
case 3:
this.tlStr=msg;
break;
}
});

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
g=g.create$();
var oldFont=g.getFont$();
g.setFont$java_awt_Font(this.font);
var fm=g.getFontMetrics$();
var height=fm.getAscent$() + 4;
var width=0;
g.setClip$I$I$I$I(0, 0, panel.getWidth$(), panel.getHeight$());
if (this.tlStr != null  && !this.tlStr.equals$O("") ) {
g.setColor$java_awt_Color($I$(3).YELLOW);
width=fm.stringWidth$S(this.tlStr) + 6;
g.fillRect$I$I$I$I(1, 0, width, height);
g.setColor$java_awt_Color($I$(3).BLACK);
g.drawRect$I$I$I$I(1, 0, width, height);
g.drawString$S$I$I(this.tlStr, 3, height - 4);
}if (this.trStr != null  && !this.trStr.equals$O("") ) {
g.setColor$java_awt_Color($I$(3).YELLOW);
width=fm.stringWidth$S(this.trStr) + 8;
g.fillRect$I$I$I$I(panel.getWidth$() - width - 1 , 0, width, height);
g.setColor$java_awt_Color($I$(3).BLACK);
g.drawRect$I$I$I$I(panel.getWidth$() - width - 1 , 0, width, height);
g.drawString$S$I$I(this.trStr, panel.getWidth$() - width + 4, height - 4);
}if (this.blStr != null  && !this.blStr.equals$O("") ) {
g.setColor$java_awt_Color($I$(3).YELLOW);
width=fm.stringWidth$S(this.blStr) + 6;
g.fillRect$I$I$I$I(1, panel.getHeight$() - height - 1 , width, height);
g.setColor$java_awt_Color($I$(3).BLACK);
g.drawRect$I$I$I$I(1, panel.getHeight$() - height - 1 , width, height);
g.drawString$S$I$I(this.blStr, 3, panel.getHeight$() - 4);
}if (this.brStr != null  && !this.brStr.equals$O("") ) {
g.setColor$java_awt_Color($I$(3).YELLOW);
width=fm.stringWidth$S(this.brStr) + 8;
g.fillRect$I$I$I$I(panel.getWidth$() - width - 1 , panel.getHeight$() - height - 1 , width, height);
g.setColor$java_awt_Color($I$(3).BLACK);
g.drawRect$I$I$I$I(panel.getWidth$() - width - 1 , panel.getHeight$() - height - 1 , width, height);
g.drawString$S$I$I(this.brStr, panel.getWidth$() - width + 4, panel.getHeight$() - 4);
}g.setFont$java_awt_Font(oldFont);
g.dispose$();
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:22 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
