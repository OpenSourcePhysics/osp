(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[[0,'javax.swing.ImageIcon','java.awt.image.BufferedImage']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ResizableIcon", null, null, 'javax.swing.Icon');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['baseWidth','baseHeight','w','h'],'O',['baseImage','java.awt.image.BufferedImage','icon','javax.swing.Icon']]]

Clazz.newMeth(C$, 'c$$java_net_URL', function (location) {
C$.c$$javax_swing_Icon.apply(this, [Clazz.new_($I$(1,1).c$$java_net_URL,[location])]);
}, 1);

Clazz.newMeth(C$, 'c$$javax_swing_Icon', function (icon) {
;C$.$init$.apply(this);
while (Clazz.instanceOf(icon, "org.opensourcephysics.display.ResizableIcon")){
icon=(icon).icon;
}
this.icon=icon;
if (icon == null ) {
this.baseWidth=this.w=0;
this.baseHeight=this.h=0;
} else {
this.baseWidth=this.w=icon.getIconWidth$();
this.baseHeight=this.h=icon.getIconHeight$();
}}, 1);

Clazz.newMeth(C$, 'paintIcon$java_awt_Component$java_awt_Graphics$I$I', function (c, g, x, y) {
if (this.icon == null ) {
return;
}if (this.baseImage == null ) {
this.baseImage=Clazz.new_($I$(2,1).c$$I$I$I,[this.baseWidth, this.baseHeight, 2]);
}var g2=this.baseImage.createGraphics$();
this.icon.paintIcon$java_awt_Component$java_awt_Graphics$I$I(c, g2, 0, 0);
g2.dispose$();
g.drawImage$java_awt_Image$I$I$I$I$java_awt_image_ImageObserver(this.baseImage, x, y, this.w, this.h, c);
});

Clazz.newMeth(C$, 'getIconWidth$', function () {
return this.w;
});

Clazz.newMeth(C$, 'getIconHeight$', function () {
return this.h;
});

Clazz.newMeth(C$, 'getBaseIcon$', function () {
return this.icon;
});

Clazz.newMeth(C$, 'resize$I', function (factor) {
var n=Math.max(factor, 1);
this.w=n * this.baseWidth;
this.h=n * this.baseHeight;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-26 22:52:33 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
