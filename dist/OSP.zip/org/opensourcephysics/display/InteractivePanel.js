(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),I$=[[0,'java.awt.Cursor',['org.opensourcephysics.display.InteractivePanel','.IADMouseController']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InteractivePanel", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.display.DrawingPanel', 'org.opensourcephysics.display.InteractiveMouseHandler');
C$.$classes$=[['IADMouseController',4]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.containsInteractive=false;
this.mouseAction=0;
this.mouseEvent=null;
this.interactive=null;
this.iaDraggable=null;
this.iaSelectable=null;
},1);

C$.$fields$=[['Z',['containsInteractive'],'I',['mouseAction'],'O',['mouseEvent','java.awt.event.MouseEvent','interactive','org.opensourcephysics.display.InteractiveMouseHandler','iaDraggable','org.opensourcephysics.display.Interactive','iaSelectable','org.opensourcephysics.display.Selectable']]]

Clazz.newMeth(C$, 'c$$org_opensourcephysics_display_InteractiveMouseHandler', function ($in) {
C$.c$.apply(this, []);
this.interactive=$in;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.removeMouseListener$java_awt_event_MouseListener(this.mouseController);
this.removeMouseMotionListener$java_awt_event_MouseMotionListener(this.mouseController);
this.mouseController=Clazz.new_($I$(2,1),[this, null]);
this.addMouseListener$java_awt_event_MouseListener(this.mouseController);
this.addMouseMotionListener$java_awt_event_MouseMotionListener(this.mouseController);
this.interactive=this;
}, 1);

Clazz.newMeth(C$, 'addDrawable$org_opensourcephysics_display_Drawable', function (drawable) {
C$.superclazz.prototype.addDrawable$org_opensourcephysics_display_Drawable.apply(this, [drawable]);
if (Clazz.instanceOf(drawable, "org.opensourcephysics.display.Interactive")) {
this.containsInteractive=true;
}});

Clazz.newMeth(C$, 'clear$', function () {
C$.superclazz.prototype.clear$.apply(this, []);
this.containsInteractive=false;
});

Clazz.newMeth(C$, 'scaleX$java_util_ArrayList', function (tempList) {
var tempmin=this.xminPreferred;
var tempmax=this.xmaxPreferred;
C$.superclazz.prototype.scaleX$java_util_ArrayList.apply(this, [tempList]);
if (this.autoscaleX && (this.mouseAction == 3) ) {
if (this.xminPreferred > tempmin ) {
this.xminPreferred=tempmin;
}if (this.xmaxPreferred < tempmax ) {
this.xmaxPreferred=tempmax;
}}});

Clazz.newMeth(C$, 'scaleY$java_util_ArrayList', function (tempList) {
var tempmin=this.yminPreferred;
var tempmax=this.ymaxPreferred;
C$.superclazz.prototype.scaleY$java_util_ArrayList.apply(this, [tempList]);
if (this.autoscaleY && (this.mouseAction == 3) ) {
if (this.yminPreferred > tempmin ) {
this.yminPreferred=tempmin;
}if (this.ymaxPreferred < tempmax ) {
this.ymaxPreferred=tempmax;
}}});

Clazz.newMeth(C$, 'setInteractiveMouseHandler$org_opensourcephysics_display_InteractiveMouseHandler', function (handler) {
this.interactive=handler;
});

Clazz.newMeth(C$, 'handleMouseAction$org_opensourcephysics_display_InteractivePanel$java_awt_event_MouseEvent', function (panel, evt) {
switch (panel.getMouseAction$()) {
case 4:
var clickedIA=this.getInteractive$();
if ((panel.getMouseClickCount$() < 2) || (clickedIA == null ) || !(Clazz.instanceOf(clickedIA, "org.opensourcephysics.display.Selectable"))  ) {
return;
}if ((this.iaSelectable != null ) && (this.iaSelectable !== clickedIA ) ) {
this.iaSelectable.setSelected$Z(false);
}this.iaSelectable=(clickedIA);
this.iaSelectable.toggleSelected$();
this.invalidateImage$();
if (!this.getIgnoreRepaint$()) {
panel.repaint$();
}break;
case 3:
if (this.iaDraggable == null ) {
return;
}var x=panel.getMouseX$();
var y=panel.getMouseY$();
if (!this.autoscaleX && (evt.getX$() < 1 + this.leftGutter) ) {
x=panel.pixToX$I(1 + this.leftGutter);
}if (!this.autoscaleX && (evt.getX$() > panel.getWidth$() - 1 - this.rightGutter ) ) {
x=panel.pixToX$I(panel.getWidth$() - 1 - this.rightGutter );
}if (!this.autoscaleY && (evt.getY$() < 1 + this.topGutter) ) {
y=panel.pixToY$I(1 + this.topGutter);
}if (!this.autoscaleY && (evt.getY$() > panel.getHeight$() - 1 - this.bottomGutter ) ) {
y=panel.pixToY$I(panel.getHeight$() - 1 - this.bottomGutter );
}this.iaDraggable.setXY$D$D(x, y);
this.invalidateImage$();
if (!this.getIgnoreRepaint$()) {
panel.repaint$();
}break;
case 2:
if ((this.autoscaleX || this.autoscaleY ) && !this.getIgnoreRepaint$() ) {
panel.repaint$();
}break;
}
});

Clazz.newMeth(C$, 'getCurrentDraggable$', function () {
return this.iaDraggable;
});

Clazz.newMeth(C$, 'getInteractive$', function () {
if (!this.containsInteractive) {
return null;
}if (this.iaDraggable != null ) {
return this.iaDraggable;
}if ((this.iaSelectable != null ) && this.iaSelectable.isSelected$() ) {
var iad=(this.iaSelectable).findInteractive$org_opensourcephysics_display_DrawingPanel$I$I(this, this.mouseEvent.getX$(), this.mouseEvent.getY$());
return iad;
}var array=null;
{
array=this.drawableList.toArray$();
}for (var i=array.length - 1; i >= 0; i--) {
var obj=array[i];
if (Clazz.instanceOf(obj, "org.opensourcephysics.display.Interactive")) {
var iad=(obj).findInteractive$org_opensourcephysics_display_DrawingPanel$I$I(this, this.mouseEvent.getX$(), this.mouseEvent.getY$());
if (iad != null ) {
return iad;
}}}
return null;
});

Clazz.newMeth(C$, 'setShowCoordinates$Z', function (show) {
this.showCoordinates=show;
});

Clazz.newMeth(C$, 'getMouseButton$', function () {
switch (this.mouseEvent.getModifiers$()) {
case 16:
return 1;
case 8:
return 2;
case 4:
return 3;
default:
return 0;
}
});

Clazz.newMeth(C$, 'getMouseClickCount$', function () {
return this.mouseEvent.getClickCount$();
});

Clazz.newMeth(C$, 'getMouseAction$', function () {
return this.mouseAction;
});

Clazz.newMeth(C$, 'getMouseIntX$', function () {
return this.mouseEvent.getX$();
});

Clazz.newMeth(C$, 'getMouseIntY$', function () {
return this.mouseEvent.getY$();
});

Clazz.newMeth(C$, 'getMouseX$', function () {
return this.pixToX$I(this.mouseEvent.getX$());
});

Clazz.newMeth(C$, 'getMouseY$', function () {
return this.pixToY$I(this.mouseEvent.getY$());
});

Clazz.newMeth(C$, 'saveMouseEvent$I$java_awt_event_MouseEvent', function (type, evt) {
this.mouseAction=type;
this.mouseEvent=evt;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.InteractivePanel, "IADMouseController", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.event.MouseInputAdapter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.this$0.mouseEvent=e;
this.this$0.mouseAction=1;
if (this.this$0.interactive != null ) {
this.this$0.interactive.handleMouseAction$org_opensourcephysics_display_InteractivePanel$java_awt_event_MouseEvent(this.this$0, e);
this.this$0.iaDraggable=null;
this.this$0.iaDraggable=this.this$0.getInteractive$.apply(this.this$0, []);
if (this.this$0.iaDraggable != null ) {
if (Clazz.instanceOf(this.this$0.iaDraggable, "org.opensourcephysics.display.Selectable")) {
this.b$['org.opensourcephysics.display.DrawingPanel'].setMouseCursor$java_awt_Cursor.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], [(this.this$0.iaDraggable).getPreferredCursor$()]);
} else {
this.b$['org.opensourcephysics.display.DrawingPanel'].setMouseCursor$java_awt_Cursor.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], [$I$(1).getPredefinedCursor$I(12)]);
}}}if (this.this$0.showCoordinates) {
var s=this.this$0.coordinateStrBuilder.getCoordinateString$org_opensourcephysics_display_DrawingPanel$java_awt_event_MouseEvent(this.this$0, e);
this.this$0.blMessageBox.setText$S(s);
this.this$0.messages.setMessage$S$I(s, 0);
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
}});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.this$0.mouseEvent=e;
this.this$0.mouseAction=2;
if (this.this$0.interactive != null ) {
this.this$0.interactive.handleMouseAction$org_opensourcephysics_display_InteractivePanel$java_awt_event_MouseEvent(this.this$0, e);
}this.this$0.iaDraggable=null;
if (this.this$0.showCoordinates) {
this.this$0.blMessageBox.setText$S(null);
this.this$0.messages.setMessage$S$I(null, 0);
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
}this.b$['org.opensourcephysics.display.DrawingPanel'].setMouseCursor$java_awt_Cursor.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], [$I$(1).getPredefinedCursor$I(1)]);
});

Clazz.newMeth(C$, 'mouseEntered$java_awt_event_MouseEvent', function (e) {
if (this.this$0.showCoordinates) {
this.b$['org.opensourcephysics.display.DrawingPanel'].setMouseCursor$java_awt_Cursor.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], [$I$(1).getPredefinedCursor$I(1)]);
}this.this$0.mouseEvent=e;
this.this$0.mouseAction=5;
if (this.this$0.interactive != null ) {
this.this$0.interactive.handleMouseAction$org_opensourcephysics_display_InteractivePanel$java_awt_event_MouseEvent(this.this$0, e);
}});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
this.b$['org.opensourcephysics.display.DrawingPanel'].setMouseCursor$java_awt_Cursor.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], [$I$(1).getPredefinedCursor$I(0)]);
this.this$0.mouseEvent=e;
this.this$0.mouseAction=6;
if (this.this$0.interactive != null ) {
this.this$0.interactive.handleMouseAction$org_opensourcephysics_display_InteractivePanel$java_awt_event_MouseEvent(this.this$0, e);
}});

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
this.this$0.mouseEvent=e;
this.this$0.mouseAction=4;
if (this.this$0.interactive == null ) {
return;
}this.this$0.interactive.handleMouseAction$org_opensourcephysics_display_InteractivePanel$java_awt_event_MouseEvent(this.this$0, e);
});

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
this.this$0.mouseEvent=e;
this.this$0.mouseAction=3;
if (this.this$0.interactive != null ) {
this.this$0.interactive.handleMouseAction$org_opensourcephysics_display_InteractivePanel$java_awt_event_MouseEvent(this.this$0, e);
}if (this.this$0.showCoordinates) {
var s=this.this$0.coordinateStrBuilder.getCoordinateString$org_opensourcephysics_display_DrawingPanel$java_awt_event_MouseEvent(this.this$0, e);
this.this$0.blMessageBox.setText$S(s);
this.this$0.messages.setMessage$S$I(s, 0);
this.b$['java.awt.Component'].repaint$.apply(this.b$['java.awt.Component'], []);
}});

Clazz.newMeth(C$, 'mouseMoved$java_awt_event_MouseEvent', function (e) {
this.this$0.mouseEvent=e;
this.this$0.mouseAction=7;
this.this$0.iaDraggable=null;
if (this.this$0.interactive != null ) {
this.this$0.interactive.handleMouseAction$org_opensourcephysics_display_InteractivePanel$java_awt_event_MouseEvent(this.this$0, e);
var iad=this.this$0.getInteractive$.apply(this.this$0, []);
if (iad == null ) {
this.b$['org.opensourcephysics.display.DrawingPanel'].setMouseCursor$java_awt_Cursor.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], [$I$(1).getPredefinedCursor$I(1)]);
} else {
if (Clazz.instanceOf(iad, "org.opensourcephysics.display.Selectable")) {
this.b$['org.opensourcephysics.display.DrawingPanel'].setMouseCursor$java_awt_Cursor.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], [(iad).getPreferredCursor$()]);
} else {
this.b$['org.opensourcephysics.display.DrawingPanel'].setMouseCursor$java_awt_Cursor.apply(this.b$['org.opensourcephysics.display.DrawingPanel'], [$I$(1).getPredefinedCursor$I(12)]);
}}}});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-27 14:51:43 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
