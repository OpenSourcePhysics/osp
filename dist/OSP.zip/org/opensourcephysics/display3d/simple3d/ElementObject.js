(function(){var P$=Clazz.newPackage("org.opensourcephysics.display3d.simple3d"),I$=[[0,'org.opensourcephysics.display3d.simple3d.ElementObject',['org.opensourcephysics.display3d.simple3d.ElementObject','.Loader']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ElementObject", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.display3d.simple3d.ElementBox', 'org.opensourcephysics.display3d.core.ElementObject');
C$.$classes$=[['Loader',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.file=null;
this.angle=0.0;
},1);

C$.$fields$=[['D',['angle'],'S',['file']]]

Clazz.newMeth(C$, 'setObjectFile$S', function (file) {
this.file=file;
});

Clazz.newMeth(C$, 'getObjectFile$', function () {
return this.file;
});

Clazz.newMeth(C$, 'setRotationAngle$D', function (angle) {
this.angle=angle;
});

Clazz.newMeth(C$, 'getRotationAngle$', function () {
return this.angle;
});

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(2,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ElementObject, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, ['org.opensourcephysics.display3d.core.ElementObject','.Loader']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(1,1));
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-05 21:20:30 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
