(function(){var P$=Clazz.newPackage("org.opensourcephysics.display3d.simple3d"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Resolution", null, 'org.opensourcephysics.display3d.core.Resolution');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$D', function (max) {
;C$.superclazz.c$$D.apply(this,[max]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I', function (n1, n2, n3) {
;C$.superclazz.c$$I$I$I.apply(this,[n1, n2, n3]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-05 21:20:31 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
