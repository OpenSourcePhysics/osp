(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.gif"),p$1={},I$=[[0,'org.opensourcephysics.controls.XML','org.opensourcephysics.media.gif.GifVideo','org.opensourcephysics.media.core.VideoIO','org.opensourcephysics.controls.OSPLog','java.util.HashSet','Boolean','org.opensourcephysics.media.gif.GifDecoder','org.opensourcephysics.tools.ResourceLoader','java.awt.Dimension','org.opensourcephysics.media.core.ImageCoordSystem','org.opensourcephysics.media.core.DoubleArray','javax.swing.Timer',['org.opensourcephysics.media.gif.GifVideo','.Loader']]],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GifVideo", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.media.core.VideoAdapter');
C$.$classes$=[['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.panels=Clazz.new_($I$(5,1));
},1);

C$.$fields$=[['O',['decoder','org.opensourcephysics.media.gif.GifDecoder','startTimes','int[]','timer','javax.swing.Timer','panels','java.util.HashSet']]]

Clazz.newMeth(C$, 'c$$S', function (gifName) {
Clazz.super_(C$, this);
this.load$S(gifName);
p$1.createTimer.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
this.panels.add$O(panel);
C$.superclazz.prototype.draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics.apply(this, [panel, g]);
});

Clazz.newMeth(C$, 'finalize$', function () {
});

Clazz.newMeth(C$, 'play$', function () {
if (this.getFrameCount$() == 1) {
return;
}if (!this.timer.isRunning$()) {
if (this.getFrameNumber$() >= this.getEndFrameNumber$()) {
this.setFrameNumber$I(this.getStartFrameNumber$());
}this.timer.restart$();
this.support.firePropertyChange$S$O$O("playing", null, $I$(6).TRUE);
}});

Clazz.newMeth(C$, 'stop$', function () {
if (this.timer.isRunning$()) {
this.timer.stop$();
this.support.firePropertyChange$S$O$O("playing", null, $I$(6).FALSE);
}});

Clazz.newMeth(C$, 'setFrameNumber$I', function (n) {
C$.superclazz.prototype.setFrameNumber$I.apply(this, [n]);
n=this.getFrameNumber$();
var index=Math.min(n, this.decoder.getFrameCount$() - 1);
this.rawImage=this.decoder.getFrame$I(index);
this.isValidImage=false;
this.isValidFilteredImage=false;
this.support.firePropertyChange$S$O$O("framenumber", null, Integer.valueOf$I(n));
var it=this.panels.iterator$();
while (it.hasNext$()){
var panel=it.next$();
panel.repaint$();
}
});

Clazz.newMeth(C$, 'getFrameTime$I', function (n) {
if ((n >= this.startTimes.length) || (n < 0) ) {
return -1;
}return this.startTimes[n];
});

Clazz.newMeth(C$, 'getTime$', function () {
return this.getFrameTime$I(this.getFrameNumber$());
});

Clazz.newMeth(C$, 'setTime$D', function (millis) {
millis=Math.abs(millis);
for (var i=0; i < this.startTimes.length; i++) {
var t=this.startTimes[i];
if (millis < t ) {
this.setFrameNumber$I(i - 1);
break;
}}
});

Clazz.newMeth(C$, 'getStartTime$', function () {
return this.getFrameTime$I(this.getStartFrameNumber$());
});

Clazz.newMeth(C$, 'setStartTime$D', function (millis) {
millis=Math.abs(millis);
for (var i=0; i < this.startTimes.length; i++) {
var t=this.startTimes[i];
if (millis < t ) {
this.setStartFrameNumber$I(i - 1);
break;
}}
});

Clazz.newMeth(C$, 'getEndTime$', function () {
var n=this.getEndFrameNumber$();
return this.getFrameTime$I(n) + this.decoder.getDelay$I(n);
});

Clazz.newMeth(C$, 'setEndTime$D', function (millis) {
millis=Math.abs(millis);
millis=Math.min(this.getDuration$(), millis);
for (var i=0; i < this.startTimes.length; i++) {
var t=this.startTimes[i];
if (millis < t ) {
this.setEndFrameNumber$I(i - 1);
break;
}}
});

Clazz.newMeth(C$, 'getDuration$', function () {
var n=this.getFrameCount$() - 1;
return this.getFrameTime$I(n) + this.decoder.getDelay$I(n);
});

Clazz.newMeth(C$, 'load$S', function (gifName) {
this.decoder=Clazz.new_($I$(7,1));
var status=this.decoder.read$S(gifName);
if (status == 2) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["Gif " + gifName + " not found" ]);
} else if (status == 1) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["File format error"]);
}this.setProperty$S$O("name", gifName);
if (gifName.indexOf$S(":") == -1) {
this.setProperty$S$O("path", $I$(1).forwardSlash$S(gifName));
var res=$I$(8).getResource$S(gifName);
if (res != null ) this.setProperty$S$O("absolutePath", res.getAbsolutePath$());
} else {
this.setProperty$S$O("path", $I$(1).getRelativePath$S(gifName));
this.setProperty$S$O("absolutePath", gifName);
}this.frameCount=this.decoder.getFrameCount$();
this.startFrameNumber=0;
this.endFrameNumber=this.frameCount - 1;
this.startTimes=Clazz.array(Integer.TYPE, [this.frameCount]);
this.startTimes[0]=0;
for (var i=1; i < this.startTimes.length; i++) {
this.startTimes[i]=this.startTimes[i - 1] + this.decoder.getDelay$I(i - 1);
}
p$1.setImage$java_awt_image_BufferedImage.apply(this, [this.decoder.getFrame$I(0)]);
});

Clazz.newMeth(C$, 'setImage$java_awt_image_BufferedImage', function (image) {
this.rawImage=image;
this.size=Clazz.new_([image.getWidth$(), image.getHeight$()],$I$(9,1).c$$I$I);
this.refreshBufferedImage$();
this.coords=Clazz.new_($I$(10,1).c$$I,[this.frameCount]);
this.coords.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
this.aspects=Clazz.new_($I$(11,1).c$$I$D,[this.frameCount, 1]);
}, p$1);

Clazz.newMeth(C$, 'createTimer', function () {
var delay=this.decoder.getDelay$I(0);
this.timer=Clazz.new_([delay, ((P$.GifVideo$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "GifVideo$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoAdapter'].getFrameNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoAdapter'], []) < this.b$['org.opensourcephysics.media.core.VideoAdapter'].getEndFrameNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoAdapter'], [])) {
var delay=this.b$['org.opensourcephysics.media.gif.GifVideo'].decoder.getDelay$I(this.b$['org.opensourcephysics.media.core.VideoAdapter'].getFrameNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoAdapter'], []) + 1);
this.b$['org.opensourcephysics.media.gif.GifVideo'].timer.setDelay$I(((delay / this.b$['org.opensourcephysics.media.core.VideoAdapter'].getRate$.apply(this.b$['org.opensourcephysics.media.core.VideoAdapter'], []))|0));
this.b$['org.opensourcephysics.media.gif.GifVideo'].setFrameNumber$I.apply(this.b$['org.opensourcephysics.media.gif.GifVideo'], [this.b$['org.opensourcephysics.media.core.VideoAdapter'].getFrameNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoAdapter'], []) + 1]);
} else if (this.b$['org.opensourcephysics.media.gif.GifVideo'].looping) {
var delay=this.b$['org.opensourcephysics.media.gif.GifVideo'].decoder.getDelay$I(this.b$['org.opensourcephysics.media.core.VideoAdapter'].getStartFrameNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoAdapter'], []));
this.b$['org.opensourcephysics.media.gif.GifVideo'].timer.setDelay$I(((delay / this.b$['org.opensourcephysics.media.core.VideoAdapter'].getRate$.apply(this.b$['org.opensourcephysics.media.core.VideoAdapter'], []))|0));
this.b$['org.opensourcephysics.media.gif.GifVideo'].setFrameNumber$I.apply(this.b$['org.opensourcephysics.media.gif.GifVideo'], [this.b$['org.opensourcephysics.media.core.VideoAdapter'].getStartFrameNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoAdapter'], [])]);
} else {
this.b$['org.opensourcephysics.media.gif.GifVideo'].stop$.apply(this.b$['org.opensourcephysics.media.gif.GifVideo'], []);
}});
})()
), Clazz.new_(P$.GifVideo$1.$init$,[this, null]))],$I$(12,1).c$$I$java_awt_event_ActionListener);
}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(13,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.GifVideo, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var video=obj;
var base=video.getProperty$S("base");
var absPath=video.getProperty$S("absolutePath");
if (base != null  && absPath != null  ) control.setValue$S$O("path", $I$(1).getPathRelativeTo$S$S(absPath, base));
 else {
var path=video.getProperty$S("path");
control.setValue$S$O("path", path);
}if (!video.getFilterStack$().isEmpty$()) {
control.setValue$S$O("filters", video.getFilterStack$().getFilters$());
}});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
try {
var path=control.getString$S("path");
var video=Clazz.new_($I$(2,1).c$$S,[path]);
var gifType=$I$(3).getVideoType$S$S("gif", null);
if (gifType != null ) video.setProperty$S$O("video_type", gifType);
return video;
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
$I$(4,"fine$S",[ex.getMessage$()]);
return null;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var video=obj;
var filters=control.getObject$S("filters");
if (filters != null ) {
video.getFilterStack$().clear$();
var it=filters.iterator$();
while (it.hasNext$()){
var filter=it.next$();
video.getFilterStack$().addFilter$org_opensourcephysics_media_core_Filter(filter);
}
}return obj;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:29 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
