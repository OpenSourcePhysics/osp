(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'org.opensourcephysics.media.core.VidCartesianCoordinateStringBuilder','java.awt.geom.AffineTransform','java.awt.Point',['java.awt.geom.Point2D','.Double'],['org.opensourcephysics.media.core.TPoint','.Follower'],'javax.swing.event.SwingPropertyChangeSupport']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TPoint", function(){
Clazz.newInstance(this, arguments,0,C$);
}, ['java.awt.geom.Point2D','.Double'], ['org.opensourcephysics.display.Interactive', 'org.opensourcephysics.media.core.Trackable']);
C$.$classes$=[['Follower',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.enabled=true;
this.trackEditTrigger=false;
this.coordsEditTrigger=false;
this.stepEditTrigger=false;
this.isAdjusting=false;
},1);

C$.$fields$=[['Z',['enabled','trackEditTrigger','coordsEditTrigger','stepEditTrigger','isAdjusting'],'O',['screenPt','java.awt.Point','worldPt','java.awt.geom.Point2D','support','java.beans.PropertyChangeSupport','attachedTo','org.opensourcephysics.media.core.TPoint','toScreen','java.awt.geom.AffineTransform']]
,['Z',['coordsVisibleInMouseBox'],'O',['xyStringBuilder','org.opensourcephysics.media.core.XYCoordinateStringBuilder']]]

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D$D.apply(this, [0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (x, y) {
;C$.superclazz.c$$D$D.apply(this,[x, y]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D', function (point) {
C$.c$$D$D.apply(this, [point.getX$(), point.getY$()]);
}, 1);

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, _g) {
});

Clazz.newMeth(C$, 'findInteractive$org_opensourcephysics_display_DrawingPanel$I$I', function (panel, xpix, ypix) {
return null;
});

Clazz.newMeth(C$, 'setX$D', function (x) {
this.setXY$D$D(x, this.getY$());
});

Clazz.newMeth(C$, 'setY$D', function (y) {
this.setXY$D$D(this.getX$(), y);
});

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
this.setLocation$D$D(x, y);
});

Clazz.newMeth(C$, 'setLocation$D$D', function (x, y) {
if ((this.getX$() == x ) && (this.getY$() == y ) ) {
return;
}C$.superclazz.prototype.setLocation$D$D.apply(this, [x, y]);
if (this.support != null ) {
this.support.firePropertyChange$S$O$O("location", null, this);
}});

Clazz.newMeth(C$, 'getFrameNumber$org_opensourcephysics_media_core_VideoPanel', function (vidPanel) {
return vidPanel.getFrameNumber$();
});

Clazz.newMeth(C$, 'getScreenPosition$org_opensourcephysics_media_core_VideoPanel', function (vidPanel) {
if (this.screenPt == null ) {
this.toScreen=Clazz.new_($I$(2,1));
this.screenPt=Clazz.new_($I$(3,1));
}this.toScreen.setTransform$java_awt_geom_AffineTransform(vidPanel.getPixelTransform$());
if (!vidPanel.isDrawingInImageSpace$()) {
var n=this.getFrameNumber$org_opensourcephysics_media_core_VideoPanel(vidPanel);
this.toScreen.concatenate$java_awt_geom_AffineTransform(vidPanel.getCoords$().getToWorldTransform$I(n));
}this.toScreen.transform$java_awt_geom_Point2D$java_awt_geom_Point2D(this, this.screenPt);
return this.screenPt;
});

Clazz.newMeth(C$, 'setScreenPosition$I$I$org_opensourcephysics_media_core_VideoPanel', function (x, y, vidPanel) {
if (this.screenPt == null ) {
this.screenPt=Clazz.new_($I$(3,1));
this.toScreen=Clazz.new_($I$(2,1));
}if (this.worldPt == null ) {
this.worldPt=Clazz.new_($I$(4,1));
}this.screenPt.setLocation$I$I(x, y);
this.toScreen.setTransform$java_awt_geom_AffineTransform(vidPanel.getPixelTransform$());
if (!vidPanel.isDrawingInImageSpace$()) {
var n=this.getFrameNumber$org_opensourcephysics_media_core_VideoPanel(vidPanel);
this.toScreen.concatenate$java_awt_geom_AffineTransform(vidPanel.getCoords$().getToWorldTransform$I(n));
}try {
this.toScreen.inverseTransform$java_awt_geom_Point2D$java_awt_geom_Point2D(this.screenPt, this.worldPt);
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.awt.geom.NoninvertibleTransformException")){
ex.printStackTrace$();
} else {
throw ex;
}
}
this.setXY$D$D(this.worldPt.getX$(), this.worldPt.getY$());
});

Clazz.newMeth(C$, 'setScreenPosition$I$I$org_opensourcephysics_media_core_VideoPanel$java_awt_event_InputEvent', function (x, y, vidPanel, e) {
this.setScreenPosition$I$I$org_opensourcephysics_media_core_VideoPanel(x, y, vidPanel);
});

Clazz.newMeth(C$, 'getWorldPosition$org_opensourcephysics_media_core_VideoPanel', function (vidPanel) {
var n=this.getFrameNumber$org_opensourcephysics_media_core_VideoPanel(vidPanel);
var at=vidPanel.getCoords$().getToWorldTransform$I(n);
if (this.worldPt == null ) {
this.worldPt=Clazz.new_($I$(4,1));
}return at.transform$java_awt_geom_Point2D$java_awt_geom_Point2D(this, this.worldPt);
});

Clazz.newMeth(C$, 'setWorldPosition$D$D$org_opensourcephysics_media_core_VideoPanel', function (x, y, vidPanel) {
var n=this.getFrameNumber$org_opensourcephysics_media_core_VideoPanel(vidPanel);
var at=vidPanel.getCoords$().getToWorldTransform$I(n);
if (this.worldPt == null ) {
this.worldPt=Clazz.new_($I$(4,1));
}this.worldPt.setLocation$D$D(x, y);
try {
at.inverseTransform$java_awt_geom_Point2D$java_awt_geom_Point2D(this.worldPt, this.worldPt);
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.awt.geom.NoninvertibleTransformException")){
ex.printStackTrace$();
} else {
throw ex;
}
}
this.setXY$D$D(this.worldPt.getX$(), this.worldPt.getY$());
});

Clazz.newMeth(C$, 'showCoordinates$org_opensourcephysics_media_core_VideoPanel', function (vidPanel) {
if (C$.coordsVisibleInMouseBox) {
this.getWorldPosition$org_opensourcephysics_media_core_VideoPanel(vidPanel);
var builder=vidPanel.getXYCoordinateStringBuilder$org_opensourcephysics_media_core_TPoint(this);
var s=builder.getCoordinateString$org_opensourcephysics_media_core_VideoPanel$D$D(vidPanel, this.worldPt.getX$(), this.worldPt.getY$());
vidPanel.setMessage$S$I(s, 0);
}});

Clazz.newMeth(C$, 'attachTo$org_opensourcephysics_media_core_TPoint', function (p) {
if (p == null  || p === this  ) return false;
if (p === this.attachedTo  && p.getX$() == this.getX$()   && p.getY$() == this.getY$()  ) return false;
this.detach$();
this.attachedTo=p;
p.addPropertyChangeListener$S$java_beans_PropertyChangeListener("location", Clazz.new_($I$(5,1),[this, null]));
this.setXY$D$D(p.getX$(), p.getY$());
return true;
});

Clazz.newMeth(C$, 'detach$', function () {
if (this.attachedTo != null ) {
var listeners=this.attachedTo.support.getPropertyChangeListeners$S("location");
for (var next, $next = 0, $$next = listeners; $next<$$next.length&&((next=($$next[$next])),1);$next++) {
if (Clazz.instanceOf(next, "org.opensourcephysics.media.core.TPoint.Follower")) {
var follower=next;
if (follower.getTarget$() === this ) this.attachedTo.removePropertyChangeListener$S$java_beans_PropertyChangeListener("location", next);
}}
this.attachedTo=null;
}});

Clazz.newMeth(C$, 'isAttached$', function () {
return this.attachedTo != null ;
});

Clazz.newMeth(C$, 'setEnabled$Z', function (enabled) {
this.enabled=enabled;
});

Clazz.newMeth(C$, 'isEnabled$', function () {
return this.enabled;
});

Clazz.newMeth(C$, 'setTrackEditTrigger$Z', function (edit) {
this.trackEditTrigger=edit;
});

Clazz.newMeth(C$, 'isTrackEditTrigger$', function () {
return this.trackEditTrigger;
});

Clazz.newMeth(C$, 'setCoordsEditTrigger$Z', function (edit) {
this.coordsEditTrigger=edit;
});

Clazz.newMeth(C$, 'isCoordsEditTrigger$', function () {
return this.coordsEditTrigger;
});

Clazz.newMeth(C$, 'setStepEditTrigger$Z', function (stepEditTrigger) {
this.stepEditTrigger=stepEditTrigger;
});

Clazz.newMeth(C$, 'isStepEditTrigger$', function () {
return this.stepEditTrigger;
});

Clazz.newMeth(C$, 'getBounds$org_opensourcephysics_media_core_VideoPanel', function (vidPanel) {
return null;
});

Clazz.newMeth(C$, 'isMeasured$', function () {
return false;
});

Clazz.newMeth(C$, 'getXMin$', function () {
return this.getX$();
});

Clazz.newMeth(C$, 'getXMax$', function () {
return this.getX$();
});

Clazz.newMeth(C$, 'getYMin$', function () {
return this.getY$();
});

Clazz.newMeth(C$, 'getYMax$', function () {
return this.getY$();
});

Clazz.newMeth(C$, 'angle$D$D', function (x, y) {
return Math.atan2(y - this.getY$(), x - this.getX$());
});

Clazz.newMeth(C$, 'angle$java_awt_geom_Point2D', function (pt) {
return Math.atan2(pt.getY$() - this.getY$(), pt.getX$() - this.getX$());
});

Clazz.newMeth(C$, 'sin$D$D', function (x, y) {
return (this.getY$() - y) / this.distance$D$D(x, y);
});

Clazz.newMeth(C$, 'sin$java_awt_geom_Point2D', function (pt) {
return (this.getY$() - pt.getY$()) / this.distance$java_awt_geom_Point2D(pt);
});

Clazz.newMeth(C$, 'cos$D$D', function (x, y) {
return (x - this.getX$()) / this.distance$D$D(x, y);
});

Clazz.newMeth(C$, 'cos$java_awt_geom_Point2D', function (pt) {
return (pt.getX$() - this.getX$()) / this.distance$java_awt_geom_Point2D(pt);
});

Clazz.newMeth(C$, 'center$java_awt_geom_Point2D$java_awt_geom_Point2D', function (pt1, pt2) {
var x=(pt1.getX$() + pt2.getX$()) / 2.0;
var y=(pt1.getY$() + pt2.getY$()) / 2.0;
this.setLocation$D$D(x, y);
});

Clazz.newMeth(C$, 'translate$D$D', function (dx, dy) {
this.setXY$D$D(this.getX$() + dx, this.getY$() + dy);
});

Clazz.newMeth(C$, 'setAdjusting$Z', function (adjusting) {
this.isAdjusting=adjusting;
});

Clazz.newMeth(C$, 'isAdjusting$', function () {
return this.isAdjusting;
});

Clazz.newMeth(C$, 'addPropertyChangeListener$java_beans_PropertyChangeListener', function (listener) {
if (this.support == null ) {
this.support=Clazz.new_($I$(6,1).c$$O,[this]);
}this.support.addPropertyChangeListener$java_beans_PropertyChangeListener(listener);
});

Clazz.newMeth(C$, 'addPropertyChangeListener$S$java_beans_PropertyChangeListener', function (property, listener) {
if (this.support == null ) {
this.support=Clazz.new_($I$(6,1).c$$O,[this]);
}this.support.addPropertyChangeListener$S$java_beans_PropertyChangeListener(property, listener);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$java_beans_PropertyChangeListener', function (listener) {
if (this.support != null ) {
this.support.removePropertyChangeListener$java_beans_PropertyChangeListener(listener);
}});

Clazz.newMeth(C$, 'removePropertyChangeListener$S$java_beans_PropertyChangeListener', function (property, listener) {
this.support.removePropertyChangeListener$S$java_beans_PropertyChangeListener(property, listener);
});

Clazz.newMeth(C$, 'toString', function () {
return "TPoint [" + new Double(this.x).toString() + ", " + new Double(this.y).toString() + "]" ;
});

Clazz.newMeth(C$, 'equals$O', function (obj) {
if (obj === this ) return true;
if ((obj == null ) || (obj.getClass$() !== this.getClass$() ) ) return false;
var p=obj;
return p.getX$() == this.getX$()  && p.getY$() == this.getY$()   && p.screenPt === this.screenPt   && p.worldPt === this.worldPt  ;
});

Clazz.newMeth(C$, 'setPositionOnLine$I$I$org_opensourcephysics_media_core_VideoPanel$org_opensourcephysics_media_core_TPoint$org_opensourcephysics_media_core_TPoint', function (xScreen, yScreen, vidPanel, end1, end2) {
if (this.screenPt == null ) {
this.screenPt=Clazz.new_($I$(3,1));
this.toScreen=Clazz.new_($I$(2,1));
}if (this.worldPt == null ) {
this.worldPt=Clazz.new_($I$(4,1));
}this.screenPt.setLocation$I$I(xScreen, yScreen);
this.toScreen.setTransform$java_awt_geom_AffineTransform(vidPanel.getPixelTransform$());
if (!vidPanel.isDrawingInImageSpace$()) {
var n=this.getFrameNumber$org_opensourcephysics_media_core_VideoPanel(vidPanel);
this.toScreen.concatenate$java_awt_geom_AffineTransform(vidPanel.getCoords$().getToWorldTransform$I(n));
}try {
this.toScreen.inverseTransform$java_awt_geom_Point2D$java_awt_geom_Point2D(this.screenPt, this.worldPt);
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.awt.geom.NoninvertibleTransformException")){
ex.printStackTrace$();
} else {
throw ex;
}
}
var dx=end2.getX$() - end1.getX$();
var dy=end2.getY$() - end1.getY$();
var u=((this.worldPt.getX$() - end1.getX$()) * dx + (this.worldPt.getY$() - end1.getY$()) * dy) / end1.distanceSq$java_awt_geom_Point2D(end2);
if (java.lang.Double.isNaN$D(u)) {
u=0;
}var xLine=end1.getX$() + u * dx;
var yLine=end1.getY$() + u * dy;
this.setLocation$D$D(xLine, yLine);
});

C$.$static$=function(){C$.$static$=0;
C$.coordsVisibleInMouseBox=true;
C$.xyStringBuilder=Clazz.new_($I$(1,1));
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.TPoint, "Follower", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.beans.PropertyChangeListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
var p=e.getSource$();
this.this$0.setXY$D$D.apply(this.this$0, [p.getX$(), p.getY$()]);
});

Clazz.newMeth(C$, 'getTarget$', function () {
return this.this$0;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-29 00:28:29 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
