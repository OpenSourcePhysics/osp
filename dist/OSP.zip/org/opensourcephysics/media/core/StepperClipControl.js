(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'javax.swing.Timer','javax.swing.SwingUtilities',['org.opensourcephysics.media.core.ClipControl','.Loader']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StepperClipControl", null, 'org.opensourcephysics.media.core.ClipControl');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.frameDuration=100;
this.playing=false;
this.readyToStep=true;
this.stepDisplayed=true;
this.minDelay=10;
this.maxDelay=5000;
},1);

C$.$fields$=[['Z',['playing','readyToStep','stepDisplayed'],'D',['frameDuration'],'I',['minDelay','maxDelay'],'O',['timer','javax.swing.Timer']]]

Clazz.newMeth(C$, 'c$$org_opensourcephysics_media_core_VideoClip', function (videoClip) {
;C$.superclazz.c$$org_opensourcephysics_media_core_VideoClip.apply(this,[videoClip]);C$.$init$.apply(this);
videoClip.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
if (this.video != null ) {
this.video.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
if (this.video.getFrameCount$() > 1 && this.video.getDuration$() > 0  ) {
var ti=this.video.getFrameTime$I(this.video.getStartFrameNumber$());
var tf=this.video.getFrameTime$I(this.video.getEndFrameNumber$());
var count=this.video.getEndFrameNumber$() - this.video.getStartFrameNumber$();
if ((count != 0) && (tf - ti) > 0  ) {
this.frameDuration=(((tf - ti)|0)/count|0);
}}}this.timer=Clazz.new_([p$1.getTimerDelay.apply(this, []), ((P$.StepperClipControl$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "StepperClipControl$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.StepperClipControl'].readyToStep=true;
this.b$['org.opensourcephysics.media.core.StepperClipControl'].step$.apply(this.b$['org.opensourcephysics.media.core.StepperClipControl'], []);
});
})()
), Clazz.new_(P$.StepperClipControl$1.$init$,[this, null]))],$I$(1,1).c$$I$java_awt_event_ActionListener);
this.timer.setRepeats$Z(false);
this.timer.setCoalesce$Z(false);
}, 1);

Clazz.newMeth(C$, 'play$', function () {
if (this.clip.getStepCount$() == 1) {
return;
}this.playing=true;
this.readyToStep=true;
if (this.stepNumber == this.clip.getStepCount$() - 1) {
this.setStepNumber$I(0);
} else {
this.step$();
}this.support.firePropertyChange$S$O$O("playing", null,  Boolean.from(true));
});

Clazz.newMeth(C$, 'stop$', function () {
this.timer.stop$();
this.readyToStep=true;
this.stepDisplayed=true;
this.playing=false;
this.support.firePropertyChange$S$O$O("playing", null,  Boolean.from(false));
});

Clazz.newMeth(C$, 'step$', function () {
if ((this.stepNumber >= this.clip.getStepCount$() - 1) && !this.looping ) {
this.stop$();
} else if (this.stepDisplayed && (!this.playing || this.readyToStep ) ) {
this.stepDisplayed=false;
if (this.playing) {
this.readyToStep=false;
this.timer.restart$();
}if (this.stepNumber < this.clip.getStepCount$() - 1) {
this.setStepNumber$I(this.stepNumber + 1);
} else if (this.looping) {
this.setStepNumber$I(0);
}}});

Clazz.newMeth(C$, 'back$', function () {
if (this.stepDisplayed && (this.stepNumber > 0) ) {
this.stepDisplayed=false;
this.setStepNumber$I(this.stepNumber - 1);
}});

Clazz.newMeth(C$, 'setStepNumber$I', function (n) {
n=Math.max(0, n);
n=Math.min(this.clip.getStepCount$() - 1, n);
if (n == this.stepNumber && this.clip.stepToFrame$I(n) == this.getFrameNumber$() ) {
return;
}if (this.video == null ) {
C$.superclazz.prototype.setStepNumber$I.apply(this, [n]);
this.stepDisplayed=true;
this.support.firePropertyChange$S$O$O("stepnumber", null,  new Integer(n));
} else {
var end=this.video.getEndFrameNumber$();
var m=this.clip.stepToFrame$I(n) + this.clip.getFrameShift$();
var stepNum=n;
if (m > end) {
C$.superclazz.prototype.setStepNumber$I.apply(this, [n]);
this.video.setVisible$Z(false);
this.stepDisplayed=true;
this.support.firePropertyChange$S$O$O("stepnumber", null,  new Integer(n));
} else {
this.video.setVisible$Z(this.videoVisible);
var runner=((P$.StepperClipControl$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "StepperClipControl$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
if (this.b$['org.opensourcephysics.media.core.StepperClipControl'].videoFrameNumber == this.$finals$.m) {
this.b$['org.opensourcephysics.media.core.StepperClipControl'].stepDisplayed=true;
} else {
if (this.b$['org.opensourcephysics.media.core.StepperClipControl'].video.getFrameNumber$() == this.$finals$.m) {
P$.StepperClipControl.prototype.setStepNumber$I.apply(this, [this.$finals$.stepNum]);
this.b$['org.opensourcephysics.media.core.StepperClipControl'].stepDisplayed=true;
this.b$['org.opensourcephysics.media.core.StepperClipControl'].support.firePropertyChange$S$O$O("stepnumber", null,  new Integer(this.$finals$.stepNum));
} else {
this.b$['org.opensourcephysics.media.core.StepperClipControl'].video.setFrameNumber$I(this.$finals$.m);
}}});
})()
), Clazz.new_(P$.StepperClipControl$2.$init$,[this, {m:m,stepNum:stepNum}]));
$I$(2).invokeLater$Runnable(runner);
}}});

Clazz.newMeth(C$, 'setRate$D', function (newRate) {
if ((newRate == 0 ) || (newRate == this.rate ) ) {
return;
}this.rate=Math.abs(newRate);
this.timer.setInitialDelay$I(p$1.getTimerDelay.apply(this, []));
this.support.firePropertyChange$S$O$O("rate", null,  new Double(this.rate));
});

Clazz.newMeth(C$, 'getMeanFrameDuration$', function () {
if (this.video != null  && this.video.getDuration$() > 0  ) {
var count=this.video.getEndFrameNumber$() - this.video.getStartFrameNumber$();
if (count != 0) {
var ti=this.video.getFrameTime$I(this.video.getStartFrameNumber$());
var tf=this.video.getFrameTime$I(this.video.getEndFrameNumber$());
return this.timeStretch * (tf - ti) / count;
}return this.timeStretch * this.video.getDuration$() / this.video.getFrameCount$();
}return this.frameDuration;
});

Clazz.newMeth(C$, 'setFrameDuration$D', function (duration) {
duration=Math.abs(duration);
if (duration == 0  || duration == this.getMeanFrameDuration$()  ) {
return;
}if (this.video != null  && Clazz.instanceOf(this.video, "org.opensourcephysics.media.core.ImageVideo") ) {
var iVideo=this.video;
iVideo.setFrameDuration$D(duration);
this.frameDuration=duration;
this.timer.setInitialDelay$I(p$1.getTimerDelay.apply(this, []));
} else if (this.video != null  && this.video.getDuration$() > 0  ) {
var ti=this.video.getFrameTime$I(this.video.getStartFrameNumber$());
var tf=this.video.getFrameTime$I(this.video.getEndFrameNumber$());
var count=this.video.getEndFrameNumber$() - this.video.getStartFrameNumber$();
if (count != 0) {
this.timeStretch=duration * count / (tf - ti);
}} else {
this.frameDuration=duration;
this.timer.setInitialDelay$I(p$1.getTimerDelay.apply(this, []));
}this.support.firePropertyChange$S$O$O("frameduration", null,  new Double(duration));
});

Clazz.newMeth(C$, 'setLooping$Z', function (loops) {
if (loops == this.looping ) {
return;
}this.looping=loops;
this.support.firePropertyChange$S$O$O("looping", null,  Boolean.from(loops));
});

Clazz.newMeth(C$, 'isPlaying$', function () {
return this.playing;
});

Clazz.newMeth(C$, 'getTime$', function () {
if (this.video != null  && this.video.getDuration$() > 0  ) {
var n=this.video.getFrameNumber$();
var videoTime=this.video.getFrameTime$I(n);
var m=this.clip.stepToFrame$I(this.getStepNumber$()) + this.clip.getFrameShift$();
if (m > this.video.getFrameCount$() - 1) {
var extra=m - this.video.getFrameCount$() + 1;
videoTime=this.video.getFrameTime$I(this.video.getFrameCount$() - 1) + extra * this.frameDuration;
}return (videoTime - this.video.getStartTime$()) * this.timeStretch;
}return this.stepNumber * this.frameDuration * this.clip.getStepSize$() ;
});

Clazz.newMeth(C$, 'getStepTime$I', function (stepNumber) {
if (this.video != null  && this.video.getDuration$() > 0  ) {
var n=this.clip.stepToFrame$I(stepNumber) + this.clip.getFrameShift$();
var videoTime=this.video.getFrameTime$I(n);
if (n > this.video.getFrameCount$() - 1) {
var extra=n - this.video.getFrameCount$() + 1;
videoTime=this.video.getFrameTime$I(this.video.getFrameCount$() - 1) + extra * this.frameDuration;
}return (videoTime - this.video.getStartTime$()) * this.timeStretch;
}return stepNumber * this.frameDuration * this.clip.getStepSize$() ;
});

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
var name=e.getPropertyName$();
if (name.equals$O("stepsize")) {
this.timer.setInitialDelay$I(p$1.getTimerDelay.apply(this, []));
} else if (name.equals$O("framenumber")) {
var n=(e.getNewValue$()).intValue$();
this.stepDisplayed=true;
if (n != this.videoFrameNumber) {
C$.superclazz.prototype.setFrameNumber$I.apply(this, [n - this.clip.getFrameShift$()]);
this.support.firePropertyChange$S$O$O("stepnumber", null,  new Integer(this.stepNumber));
}if (this.playing) {
this.step$();
}} else C$.superclazz.prototype.propertyChange$java_beans_PropertyChangeEvent.apply(this, [e]);
});

Clazz.newMeth(C$, 'getTimerDelay', function () {
var duration=this.frameDuration;
if (this.video != null  && this.video.getDuration$() > 0  ) {
var count=this.video.getEndFrameNumber$() - this.video.getStartFrameNumber$();
if (count != 0) {
var ti=this.video.getFrameTime$I(this.video.getStartFrameNumber$());
var tf=this.video.getFrameTime$I(this.video.getEndFrameNumber$());
duration=(tf - ti) / count;
} else duration=this.video.getDuration$() / this.video.getFrameCount$();
}var delay=((duration * this.clip.getStepSize$() / this.rate)|0);
delay=Math.min(delay, this.maxDelay);
delay=Math.max(delay, this.minDelay);
return delay;
}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(3,1));
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-27 14:51:46 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
