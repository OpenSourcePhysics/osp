(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SimpleJTextField", null, 'javax.swing.JTextField');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['mytext']]]

Clazz.newMeth(C$, 'c$$I', function (columns) {
;C$.superclazz.c$$I.apply(this,[columns]);C$.$init$.apply(this);
C$.superclazz.prototype.setDocument$javax_swing_text_Document.apply(this, [null]);
}, 1);

Clazz.newMeth(C$, 'setText$S', function (text) {
this.mytext=text;
});

Clazz.newMeth(C$, 'getText$', function () {
return this.mytext;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-27 09:35:13 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
