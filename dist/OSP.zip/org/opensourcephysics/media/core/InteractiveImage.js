(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "InteractiveImage", null, null, ['org.opensourcephysics.display.Interactive', 'org.opensourcephysics.media.core.DrawableImage']);

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-05 21:20:33 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
