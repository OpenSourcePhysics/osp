(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'java.awt.Toolkit','org.opensourcephysics.media.core.MediaRes','java.awt.event.WindowAdapter','javax.swing.JLabel','org.opensourcephysics.media.core.IntegerField','javax.swing.JSlider','javax.swing.BorderFactory','org.opensourcephysics.media.core.DecimalField','javax.swing.JTextField','java.awt.GridBagLayout','javax.swing.JPanel','java.awt.GridBagConstraints','java.awt.Insets','java.awt.FlowLayout','org.opensourcephysics.media.core.BrightnessFilter','org.opensourcephysics.controls.XMLControlElement',['org.opensourcephysics.media.core.BrightnessFilter','.Inspector'],'javax.swing.JOptionPane','java.awt.image.BufferedImage',['org.opensourcephysics.media.core.BrightnessFilter','.Loader']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BrightnessFilter", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.media.core.Filter');
C$.$classes$=[['Inspector',2],['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.defaultBrightness=0;
this.defaultContrast=50;
this.brightness=this.defaultBrightness;
this.contrast=this.defaultContrast;
},1);

C$.$fields$=[['D',['defaultContrast','contrast','previousContrast','slope','offset1','offset2'],'I',['defaultBrightness','brightness','previousBrightness'],'O',['pixels','int[]','inspector','org.opensourcephysics.media.core.BrightnessFilter.Inspector','brightnessLabel','javax.swing.JLabel','brightnessField','org.opensourcephysics.media.core.IntegerField','brightnessSlider','javax.swing.JSlider','contrastLabel','javax.swing.JLabel','contrastField','org.opensourcephysics.media.core.NumberField','contrastSlider','javax.swing.JSlider']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.setBrightness$I(this.defaultBrightness);
this.setContrast$D(this.defaultContrast);
this.hasInspector=true;
}, 1);

Clazz.newMeth(C$, 'setContrast$D', function (contrast) {
if (this.previousState == null ) {
this.previousState=Clazz.new_($I$(16,1).c$$O,[this]).toXML$();
this.previousBrightness=this.brightness;
this.previousContrast=contrast;
}this.changed=this.changed || this.contrast != contrast  ;
var prev= new Double(this.contrast);
this.contrast=contrast;
p$1.updateFactors.apply(this, []);
this.support.firePropertyChange$S$O$O("contrast", prev,  new Double(contrast));
});

Clazz.newMeth(C$, 'getContrast$', function () {
return this.contrast;
});

Clazz.newMeth(C$, 'setBrightness$I', function (brightness) {
if (this.previousState == null ) {
this.previousState=Clazz.new_($I$(16,1).c$$O,[this]).toXML$();
this.previousBrightness=this.brightness;
this.previousContrast=this.contrast;
}this.changed=this.changed || this.brightness != brightness ;
var prev= new Integer(this.brightness);
this.brightness=brightness;
p$1.updateFactors.apply(this, []);
this.support.firePropertyChange$S$O$O("brightness", prev,  new Integer(brightness));
});

Clazz.newMeth(C$, 'getBrightness$', function () {
return this.brightness;
});

Clazz.newMeth(C$, 'isChanged$', function () {
if (!this.changed) return false;
return this.previousBrightness != this.brightness || this.previousContrast != this.contrast  ;
});

Clazz.newMeth(C$, 'getFilteredImage$java_awt_image_BufferedImage', function (sourceImage) {
if (!this.isEnabled$()) {
return sourceImage;
}if (sourceImage !== this.source ) {
p$1.initialize$java_awt_image_BufferedImage.apply(this, [sourceImage]);
}if (sourceImage !== this.input ) {
this.gIn.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.source, 0, 0, null);
}p$1.setOutputToBright.apply(this, []);
return this.output;
});

Clazz.newMeth(C$, 'getInspector$', function () {
var myInspector=this.inspector;
if (myInspector == null ) {
myInspector=Clazz.new_($I$(17,1),[this, null]);
}if (myInspector.isModal$() && this.vidPanel != null  ) {
this.frame=$I$(18).getFrameForComponent$java_awt_Component(this.vidPanel);
myInspector.dispose$();
myInspector=Clazz.new_($I$(17,1),[this, null]);
}this.inspector=myInspector;
this.inspector.initialize$();
return this.inspector;
});

Clazz.newMeth(C$, 'clear$', function () {
this.setBrightness$I(this.defaultBrightness);
this.setContrast$D(this.defaultContrast);
if (this.inspector != null ) {
this.inspector.updateDisplay$();
}});

Clazz.newMeth(C$, 'refresh$', function () {
C$.superclazz.prototype.refresh$.apply(this, []);
this.brightnessLabel.setText$S($I$(2).getString$S("Filter.Brightness.Label.Brightness"));
this.brightnessSlider.setToolTipText$S($I$(2).getString$S("Filter.Brightness.ToolTip.Brightness"));
this.contrastLabel.setText$S($I$(2).getString$S("Filter.Brightness.Label.Contrast"));
this.contrastSlider.setToolTipText$S($I$(2).getString$S("Filter.Brightness.ToolTip.Contrast"));
var enabled=this.isEnabled$();
this.brightnessLabel.setEnabled$Z(enabled);
this.brightnessSlider.setEnabled$Z(enabled);
this.brightnessField.setEnabled$Z(enabled);
this.contrastLabel.setEnabled$Z(enabled);
this.contrastSlider.setEnabled$Z(enabled);
this.contrastField.setEnabled$Z(enabled);
this.clearButton.setText$S($I$(2).getString$S("Dialog.Button.Reset"));
if (this.inspector != null ) {
this.inspector.setTitle$S($I$(2).getString$S("Filter.Brightness.Title"));
this.inspector.updateDisplay$();
this.inspector.pack$();
}});

Clazz.newMeth(C$, 'dispose$', function () {
if (this.gIn != null ) this.gIn.dispose$();
if (this.source != null ) this.source.flush$();
if (this.input != null ) this.input.flush$();
if (this.output != null ) this.output.flush$();
C$.superclazz.prototype.dispose$.apply(this, []);
this.inspector=null;
});

Clazz.newMeth(C$, 'initialize$java_awt_image_BufferedImage', function (image) {
this.source=image;
this.w=this.source.getWidth$();
this.h=this.source.getHeight$();
this.pixels=Clazz.array(Integer.TYPE, [this.w * this.h]);
this.output=Clazz.new_($I$(19,1).c$$I$I$I,[this.w, this.h, 1]);
if (this.source.getType$() == 1) {
this.input=this.source;
} else {
this.input=Clazz.new_($I$(19,1).c$$I$I$I,[this.w, this.h, 1]);
this.gIn=this.input.createGraphics$();
}}, p$1);

Clazz.newMeth(C$, 'setOutputToBright', function () {
this.input.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
var pixel;
var r;
var g;
var b;
for (var i=0; i < this.pixels.length; i++) {
pixel=this.pixels[i];
r=(pixel >> 16) & 255;
r=Math.max(((this.slope * (r + this.offset1) + this.offset2)|0), 0);
r=Math.min(r, 255);
g=(pixel >> 8) & 255;
g=Math.max(((this.slope * (g + this.offset1) + this.offset2)|0), 0);
g=Math.min(g, 255);
b=(pixel) & 255;
b=Math.max(((this.slope * (b + this.offset1) + this.offset2)|0), 0);
b=Math.min(b, 255);
this.pixels[i]=(r << 16) | (g << 8) | b ;
}
this.output.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
}, p$1);

Clazz.newMeth(C$, 'updateFactors', function () {
var theta=3.141592653589793 * this.contrast / 200;
var sin=Math.sin(theta);
this.offset1=sin * sin * this.brightness  - 127;
var cos=Math.cos(theta);
this.offset2=127 + cos * cos * this.brightness ;
this.slope=sin / cos;
}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(20,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.BrightnessFilter, "Inspector", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$java_awt_Frame$Z.apply(this,[this.this$0.frame, !(Clazz.instanceOf(this.this$0.frame, "org.opensourcephysics.display.OSPFrame"))]);C$.$init$.apply(this);
this.setResizable$Z(false);
this.createGUI$();
this.this$0.refresh$.apply(this.this$0, []);
this.pack$();
var rect=this.getBounds$();
var dim=$I$(1).getDefaultToolkit$().getScreenSize$();
var x=((dim.width - rect.width)/2|0);
var y=((dim.height - rect.height)/2|0);
this.setLocation$I$I(x, y);
}, 1);

Clazz.newMeth(C$, 'createGUI$', function () {
this.setTitle$S($I$(2).getString$S("Filter.Brightness.Title"));
this.addWindowFocusListener$java_awt_event_WindowFocusListener(((P$.BrightnessFilter$Inspector$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "BrightnessFilter$Inspector$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'windowLostFocus$java_awt_event_WindowEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.BrightnessFilter'].isChanged$.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter'], []) && this.b$['org.opensourcephysics.media.core.BrightnessFilter'].previousState != null  ) {
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].changed=false;
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].support.firePropertyChange$S$O$O("filterChanged", this.b$['org.opensourcephysics.media.core.BrightnessFilter'].previousState, this.b$['org.opensourcephysics.media.core.BrightnessFilter']);
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].previousState=null;
}});
})()
), Clazz.new_($I$(3,1),[this, null],P$.BrightnessFilter$Inspector$1)));
this.this$0.brightnessLabel=Clazz.new_($I$(4,1));
this.this$0.brightnessField=Clazz.new_($I$(5,1).c$$I,[3]);
this.this$0.brightnessField.setMaxValue$D(128);
this.this$0.brightnessField.setMinValue$D(-128);
this.this$0.brightnessField.addActionListener$java_awt_event_ActionListener(((P$.BrightnessFilter$Inspector$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "BrightnessFilter$Inspector$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].setBrightness$I.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter'], [this.b$['org.opensourcephysics.media.core.BrightnessFilter'].brightnessField.getIntValue$()]);
this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'].updateDisplay$.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'], []);
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].brightnessField.selectAll$();
});
})()
), Clazz.new_(P$.BrightnessFilter$Inspector$2.$init$,[this, null])));
this.this$0.brightnessField.addFocusListener$java_awt_event_FocusListener(((P$.BrightnessFilter$Inspector$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "BrightnessFilter$Inspector$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.FocusListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'focusGained$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].brightnessField.selectAll$();
});

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].setBrightness$I.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter'], [this.b$['org.opensourcephysics.media.core.BrightnessFilter'].brightnessField.getIntValue$()]);
this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'].updateDisplay$.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'], []);
});
})()
), Clazz.new_(P$.BrightnessFilter$Inspector$3.$init$,[this, null])));
this.this$0.brightnessSlider=Clazz.new_($I$(6,1).c$$I$I$I,[0, 0, 0]);
this.this$0.brightnessSlider.setMaximum$I(128);
this.this$0.brightnessSlider.setMinimum$I(-128);
this.this$0.brightnessSlider.setBorder$javax_swing_border_Border($I$(7).createEmptyBorder$I$I$I$I(0, 2, 0, 2));
this.this$0.brightnessSlider.addChangeListener$javax_swing_event_ChangeListener(((P$.BrightnessFilter$Inspector$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "BrightnessFilter$Inspector$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.ChangeListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
var i=this.b$['org.opensourcephysics.media.core.BrightnessFilter'].brightnessSlider.getValue$();
if (i != this.b$['org.opensourcephysics.media.core.BrightnessFilter'].getBrightness$.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter'], [])) {
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].setBrightness$I.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter'], [i]);
this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'].updateDisplay$.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'], []);
}});
})()
), Clazz.new_(P$.BrightnessFilter$Inspector$4.$init$,[this, null])));
this.this$0.contrastLabel=Clazz.new_($I$(4,1));
this.this$0.contrastField=Clazz.new_($I$(8,1).c$$I$I,[4, 1]);
this.this$0.contrastField.setMaxValue$D(100);
this.this$0.contrastField.setMinValue$D(0);
this.this$0.contrastField.addActionListener$java_awt_event_ActionListener(((P$.BrightnessFilter$Inspector$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "BrightnessFilter$Inspector$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].setContrast$D.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter'], [this.b$['org.opensourcephysics.media.core.BrightnessFilter'].contrastField.getValue$()]);
this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'].updateDisplay$.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'], []);
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].contrastField.selectAll$();
});
})()
), Clazz.new_(P$.BrightnessFilter$Inspector$5.$init$,[this, null])));
this.this$0.contrastField.addFocusListener$java_awt_event_FocusListener(((P$.BrightnessFilter$Inspector$6||
(function(){/*a*/var C$=Clazz.newClass(P$, "BrightnessFilter$Inspector$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.FocusListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'focusGained$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].contrastField.selectAll$();
});

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].setContrast$D.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter'], [this.b$['org.opensourcephysics.media.core.BrightnessFilter'].contrastField.getValue$()]);
this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'].updateDisplay$.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'], []);
});
})()
), Clazz.new_(P$.BrightnessFilter$Inspector$6.$init$,[this, null])));
this.this$0.contrastSlider=Clazz.new_($I$(6,1).c$$I$I$I,[0, 0, 0]);
this.this$0.contrastSlider.setMaximum$I(100);
this.this$0.contrastSlider.setBorder$javax_swing_border_Border($I$(7).createEmptyBorder$I$I$I$I(0, 2, 0, 2));
this.this$0.contrastSlider.addChangeListener$javax_swing_event_ChangeListener(((P$.BrightnessFilter$Inspector$7||
(function(){/*a*/var C$=Clazz.newClass(P$, "BrightnessFilter$Inspector$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.ChangeListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
var i=this.b$['org.opensourcephysics.media.core.BrightnessFilter'].contrastSlider.getValue$();
if (i != (this.b$['org.opensourcephysics.media.core.BrightnessFilter'].getContrast$.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter'], [])|0)) {
this.b$['org.opensourcephysics.media.core.BrightnessFilter'].setContrast$D.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter'], [i]);
this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'].updateDisplay$.apply(this.b$['org.opensourcephysics.media.core.BrightnessFilter.Inspector'], []);
}});
})()
), Clazz.new_(P$.BrightnessFilter$Inspector$7.$init$,[this, null])));
var labels=Clazz.array($I$(4), -1, [this.this$0.brightnessLabel, this.this$0.contrastLabel]);
var fields=Clazz.array($I$(9), -1, [this.this$0.brightnessField, this.this$0.contrastField]);
var sliders=Clazz.array($I$(6), -1, [this.this$0.brightnessSlider, this.this$0.contrastSlider]);
var gridbag=Clazz.new_($I$(10,1));
var panel=Clazz.new_($I$(11,1).c$$java_awt_LayoutManager,[gridbag]);
this.setContentPane$java_awt_Container(panel);
var c=Clazz.new_($I$(12,1));
c.anchor=13;
var i=0;
for (; i < labels.length; i++) {
c.gridy=i;
c.fill=0;
c.weightx=0.0;
c.gridx=0;
c.insets=Clazz.new_($I$(13,1).c$$I$I$I$I,[5, 5, 0, 2]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(labels[i], c);
panel.add$java_awt_Component(labels[i]);
c.fill=2;
c.gridx=1;
c.insets=Clazz.new_($I$(13,1).c$$I$I$I$I,[5, 0, 0, 0]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(fields[i], c);
panel.add$java_awt_Component(fields[i]);
c.gridx=2;
c.insets=Clazz.new_($I$(13,1).c$$I$I$I$I,[5, 0, 0, 0]);
c.weightx=1.0;
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(sliders[i], c);
panel.add$java_awt_Component(sliders[i]);
}
var buttonbar=Clazz.new_([Clazz.new_($I$(14,1))],$I$(11,1).c$$java_awt_LayoutManager);
buttonbar.add$java_awt_Component(this.this$0.ableButton);
buttonbar.add$java_awt_Component(this.this$0.clearButton);
buttonbar.add$java_awt_Component(this.this$0.closeButton);
c.gridx=2;
c.gridy=i + 1;
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(buttonbar, c);
panel.add$java_awt_Component(buttonbar);
});

Clazz.newMeth(C$, 'initialize$', function () {
this.updateDisplay$();
this.this$0.refresh$.apply(this.this$0, []);
});

Clazz.newMeth(C$, 'updateDisplay$', function () {
this.this$0.brightnessField.setIntValue$I(this.this$0.getBrightness$.apply(this.this$0, []));
this.this$0.contrastField.setValue$D(this.this$0.getContrast$.apply(this.this$0, []));
this.this$0.brightnessSlider.setValue$I(this.this$0.getBrightness$.apply(this.this$0, []));
this.this$0.contrastSlider.setValue$I((this.this$0.getContrast$.apply(this.this$0, [])|0));
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.BrightnessFilter, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
control.setValue$S$I("brightness", filter.getBrightness$());
control.setValue$S$D("contrast", filter.getContrast$());
if ((filter.frame != null ) && (filter.inspector != null ) && filter.inspector.isVisible$()  ) {
var x=filter.inspector.getLocation$().x - filter.frame.getLocation$().x;
var y=filter.inspector.getLocation$().y - filter.frame.getLocation$().y;
control.setValue$S$I("inspector_x", x);
control.setValue$S$I("inspector_y", y);
}});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(15,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
if (control.getPropertyNames$().contains$O("brightness")) {
filter.setBrightness$I(control.getInt$S("brightness"));
}if (control.getPropertyNames$().contains$O("contrast")) {
filter.setContrast$D(control.getDouble$S("contrast"));
}filter.inspectorX=control.getInt$S("inspector_x");
filter.inspectorY=control.getInt$S("inspector_y");
filter.previousState=null;
filter.changed=false;
if (filter.inspector != null ) {
filter.inspector.updateDisplay$();
}return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-27 09:57:27 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
