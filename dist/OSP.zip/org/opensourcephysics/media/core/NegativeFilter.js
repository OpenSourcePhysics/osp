(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'java.awt.image.BufferedImage']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "NegativeFilter", null, 'org.opensourcephysics.media.core.Filter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pixels','int[]']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.refresh$();
}, 1);

Clazz.newMeth(C$, 'getFilteredImage$java_awt_image_BufferedImage', function (sourceImage) {
if (!this.isEnabled$()) {
return sourceImage;
}if (sourceImage !== this.source ) {
p$1.initialize$java_awt_image_BufferedImage.apply(this, [sourceImage]);
}if (sourceImage !== this.input ) {
this.gIn.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.source, 0, 0, null);
}p$1.setOutputToNegative$java_awt_image_BufferedImage.apply(this, [this.input]);
return this.output;
});

Clazz.newMeth(C$, 'getInspector$', function () {
return null;
});

Clazz.newMeth(C$, 'initialize$java_awt_image_BufferedImage', function (image) {
this.source=image;
this.w=this.source.getWidth$();
this.h=this.source.getHeight$();
this.pixels=Clazz.array(Integer.TYPE, [this.w * this.h]);
this.output=Clazz.new_($I$(1,1).c$$I$I$I,[this.w, this.h, 1]);
if (this.source.getType$() == 1) {
this.input=this.source;
} else {
this.input=Clazz.new_($I$(1,1).c$$I$I$I,[this.w, this.h, 1]);
this.gIn=this.input.createGraphics$();
}}, p$1);

Clazz.newMeth(C$, 'setOutputToNegative$java_awt_image_BufferedImage', function (image) {
image.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
var pixel;
var r;
var g;
var b;
for (var i=0; i < this.pixels.length; i++) {
pixel=this.pixels[i];
r=255 - ((pixel >> 16) & 255);
g=255 - ((pixel >> 8) & 255);
b=255 - ((pixel) & 255);
this.pixels[i]=(r << 16) | (g << 8) | b ;
}
this.output.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
}, p$1);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-05 21:20:33 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
