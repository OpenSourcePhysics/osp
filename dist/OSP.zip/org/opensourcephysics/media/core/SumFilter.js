(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'org.opensourcephysics.media.core.MediaRes','java.awt.Toolkit','javax.swing.JLabel','org.opensourcephysics.media.core.DecimalField','javax.swing.JSlider','javax.swing.JCheckBox','org.opensourcephysics.media.core.IntegerField','javax.swing.JPanel','java.awt.BorderLayout','java.awt.GridBagLayout','java.awt.GridBagConstraints','java.awt.Insets','java.awt.FlowLayout','org.opensourcephysics.media.core.SumFilter',['org.opensourcephysics.media.core.SumFilter','.Inspector'],'javax.swing.JOptionPane','java.awt.image.BufferedImage',['org.opensourcephysics.media.core.SumFilter','.Loader']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SumFilter", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.media.core.Filter');
C$.$classes$=[['Inspector',2],['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.imageCount=1;
this.brightness=1;
this.skipSum=true;
},1);

C$.$fields$=[['Z',['mean','skipSum'],'D',['brightness'],'I',['imageCount'],'O',['pixels','int[]','+rsums','+gsums','+bsums','inspector','org.opensourcephysics.media.core.SumFilter.Inspector','percentLabel','javax.swing.JLabel','percentField','org.opensourcephysics.media.core.DecimalField','percentSlider','javax.swing.JSlider','showMeanCheckBox','javax.swing.JCheckBox','frameCountLabel','javax.swing.JLabel','frameCountField','org.opensourcephysics.media.core.IntegerField']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.hasInspector=true;
}, 1);

Clazz.newMeth(C$, 'setBrightness$D', function (fraction) {
if (fraction != this.brightness ) {
this.brightness=Math.abs(fraction);
this.support.firePropertyChange$S$O$O("brightness", null, null);
}});

Clazz.newMeth(C$, 'setMean$Z', function (mean) {
if (this.mean != mean ) {
this.mean=mean;
this.refresh$();
this.support.firePropertyChange$S$O$O("mean", null, null);
}});

Clazz.newMeth(C$, 'setEnabled$Z', function (enabled) {
C$.superclazz.prototype.setEnabled$Z.apply(this, [enabled]);
this.refresh$();
});

Clazz.newMeth(C$, 'getFilteredImage$java_awt_image_BufferedImage', function (sourceImage) {
if (!this.isEnabled$()) {
return sourceImage;
}if (sourceImage !== this.source ) {
p$1.initialize$java_awt_image_BufferedImage.apply(this, [sourceImage]);
}if (sourceImage !== this.input ) {
this.gIn.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.source, 0, 0, null);
}if (!this.skipSum) {
p$1.addPixels.apply(this, []);
this.skipSum=true;
}p$1.setOutputPixels.apply(this, []);
return this.output;
});

Clazz.newMeth(C$, 'getInspector$', function () {
var myInspector=this.inspector;
if (myInspector == null ) {
myInspector=Clazz.new_($I$(15,1),[this, null]);
}if (myInspector.isModal$() && this.vidPanel != null  ) {
this.frame=$I$(16).getFrameForComponent$java_awt_Component(this.vidPanel);
myInspector.setVisible$Z(false);
myInspector.dispose$();
myInspector=Clazz.new_($I$(15,1),[this, null]);
}this.inspector=myInspector;
this.inspector.initialize$();
return this.inspector;
});

Clazz.newMeth(C$, 'clear$', function () {
if (this.source != null ) {
p$1.initialize$java_awt_image_BufferedImage.apply(this, [this.source]);
this.brightness=1;
this.skipSum=true;
this.support.firePropertyChange$S$O$O("reset", null, null);
}});

Clazz.newMeth(C$, 'refresh$', function () {
C$.superclazz.prototype.refresh$.apply(this, []);
this.percentLabel.setText$S($I$(1).getString$S("Filter.Sum.Label.Percent"));
this.percentField.setToolTipText$S($I$(1).getString$S("Filter.Sum.ToolTip.Percent"));
this.percentSlider.setToolTipText$S($I$(1).getString$S("Filter.Sum.ToolTip.Percent"));
this.showMeanCheckBox.setText$S($I$(1).getString$S("Filter.Sum.CheckBox.ShowMean"));
this.frameCountLabel.setText$S($I$(1).getString$S("Filter.Sum.Label.FrameCount"));
if (this.inspector != null ) {
this.inspector.setTitle$S($I$(1).getString$S("Filter.Sum.Title"));
this.inspector.pack$();
}var enabled=this.isEnabled$();
this.showMeanCheckBox.setEnabled$Z(enabled);
this.frameCountLabel.setEnabled$Z(enabled);
this.frameCountField.setEnabled$Z(enabled);
this.percentLabel.setEnabled$Z(enabled && !this.mean );
this.percentField.setEnabled$Z(enabled && !this.mean );
this.percentSlider.setEnabled$Z(enabled && !this.mean );
this.frameCountField.setIntValue$I(this.imageCount);
if (this.mean) {
this.percentField.setValue$D(100.0 / this.imageCount);
this.percentSlider.setValue$I(Math.round(100.0 / this.imageCount));
} else {
this.percentField.setValue$D(this.brightness * 100);
this.percentSlider.setValue$I(Math.round(this.brightness * 100));
}});

Clazz.newMeth(C$, 'addNextImage$', function () {
this.skipSum=false;
});

Clazz.newMeth(C$, 'initialize$java_awt_image_BufferedImage', function (sourceImage) {
this.source=sourceImage;
this.w=this.source.getWidth$();
this.h=this.source.getHeight$();
this.pixels=Clazz.array(Integer.TYPE, [this.w * this.h]);
this.rsums=Clazz.array(Integer.TYPE, [this.w * this.h]);
this.gsums=Clazz.array(Integer.TYPE, [this.w * this.h]);
this.bsums=Clazz.array(Integer.TYPE, [this.w * this.h]);
if (this.source.getType$() == 1) {
this.input=this.source;
} else {
this.input=Clazz.new_($I$(17,1).c$$I$I$I,[this.w, this.h, 1]);
this.gIn=this.input.createGraphics$();
}this.output=Clazz.new_($I$(17,1).c$$I$I$I,[this.w, this.h, 1]);
this.output.createGraphics$().drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.source, 0, 0, null);
this.imageCount=0;
p$1.addPixels.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'addPixels', function () {
this.imageCount++;
this.input.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
var pixel;
for (var i=0; i < this.pixels.length; i++) {
pixel=this.pixels[i];
this.rsums[i]+=(pixel >> 16) & 255;
this.gsums[i]+=(pixel >> 8) & 255;
this.bsums[i]+=(pixel) & 255;
}
if ((this.inspector != null ) && this.inspector.isVisible$() ) {
this.refresh$();
}}, p$1);

Clazz.newMeth(C$, 'setOutputPixels', function () {
var r;
var g;
var b;
var percent=this.mean ? 1.0 / this.imageCount : this.brightness;
for (var i=0; i < this.pixels.length; i++) {
r=(Math.min(this.rsums[i] * percent, 255)|0);
g=(Math.min(this.gsums[i] * percent, 255)|0);
b=(Math.min(this.bsums[i] * percent, 255)|0);
this.pixels[i]=(r << 16) | (g << 8) | b ;
}
this.output.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
if (this.mean && (this.inspector != null ) ) {
this.refresh$();
}}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(18,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.SumFilter, "Inspector", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$java_awt_Frame$Z.apply(this,[this.this$0.frame, !(Clazz.instanceOf(this.this$0.frame, "org.opensourcephysics.display.OSPFrame"))]);C$.$init$.apply(this);
this.setTitle$S($I$(1).getString$S("Filter.Sum.Title"));
this.setResizable$Z(false);
this.createGUI$();
this.this$0.refresh$.apply(this.this$0, []);
this.pack$();
var rect=this.getBounds$();
var dim=$I$(2).getDefaultToolkit$().getScreenSize$();
var x=((dim.width - rect.width)/2|0);
var y=((dim.height - rect.height)/2|0);
this.setLocation$I$I(x, y);
}, 1);

Clazz.newMeth(C$, 'createGUI$', function () {
this.this$0.percentLabel=Clazz.new_($I$(3,1));
this.this$0.percentLabel.setHorizontalAlignment$I(11);
this.this$0.percentField=Clazz.new_($I$(4,1).c$$I$I,[3, 1]);
this.this$0.percentField.setMaxValue$D(100);
this.this$0.percentField.setMinValue$D(0);
this.this$0.percentField.addActionListener$java_awt_event_ActionListener(((P$.SumFilter$Inspector$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "SumFilter$Inspector$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.SumFilter'].setBrightness$D.apply(this.b$['org.opensourcephysics.media.core.SumFilter'], [this.b$['org.opensourcephysics.media.core.SumFilter'].percentField.getValue$() / 100]);
this.b$['org.opensourcephysics.media.core.SumFilter'].refresh$.apply(this.b$['org.opensourcephysics.media.core.SumFilter'], []);
this.b$['org.opensourcephysics.media.core.SumFilter'].percentField.selectAll$();
});
})()
), Clazz.new_(P$.SumFilter$Inspector$1.$init$,[this, null])));
this.this$0.percentField.addFocusListener$java_awt_event_FocusListener(((P$.SumFilter$Inspector$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "SumFilter$Inspector$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.FocusListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'focusGained$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.SumFilter'].percentField.selectAll$();
});

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.SumFilter'].setBrightness$D.apply(this.b$['org.opensourcephysics.media.core.SumFilter'], [this.b$['org.opensourcephysics.media.core.SumFilter'].percentField.getValue$() / 100]);
this.b$['org.opensourcephysics.media.core.SumFilter'].refresh$.apply(this.b$['org.opensourcephysics.media.core.SumFilter'], []);
});
})()
), Clazz.new_(P$.SumFilter$Inspector$2.$init$,[this, null])));
this.this$0.percentSlider=Clazz.new_($I$(5,1).c$$I$I$I,[0, 100, 100]);
this.this$0.percentSlider.addChangeListener$javax_swing_event_ChangeListener(((P$.SumFilter$Inspector$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "SumFilter$Inspector$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.ChangeListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.SumFilter'].percentSlider.isEnabled$() && (this.b$['org.opensourcephysics.media.core.SumFilter'].percentSlider.getValue$() != Math.round(this.b$['org.opensourcephysics.media.core.SumFilter'].brightness * 100)) ) {
this.b$['org.opensourcephysics.media.core.SumFilter'].setBrightness$D.apply(this.b$['org.opensourcephysics.media.core.SumFilter'], [this.b$['org.opensourcephysics.media.core.SumFilter'].percentSlider.getValue$() / 100.0]);
this.b$['org.opensourcephysics.media.core.SumFilter'].refresh$.apply(this.b$['org.opensourcephysics.media.core.SumFilter'], []);
}});
})()
), Clazz.new_(P$.SumFilter$Inspector$3.$init$,[this, null])));
this.this$0.showMeanCheckBox=Clazz.new_($I$(6,1));
this.this$0.showMeanCheckBox.addActionListener$java_awt_event_ActionListener(((P$.SumFilter$Inspector$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "SumFilter$Inspector$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.SumFilter'].setMean$Z.apply(this.b$['org.opensourcephysics.media.core.SumFilter'], [this.b$['org.opensourcephysics.media.core.SumFilter'].showMeanCheckBox.isSelected$()]);
this.b$['org.opensourcephysics.media.core.SumFilter'].refresh$.apply(this.b$['org.opensourcephysics.media.core.SumFilter'], []);
});
})()
), Clazz.new_(P$.SumFilter$Inspector$4.$init$,[this, null])));
this.this$0.frameCountLabel=Clazz.new_($I$(3,1));
this.this$0.frameCountLabel.setHorizontalAlignment$I(11);
this.this$0.frameCountField=Clazz.new_($I$(7,1).c$$I,[3]);
this.this$0.frameCountField.setEditable$Z(false);
var contentPane=Clazz.new_([Clazz.new_($I$(9,1))],$I$(8,1).c$$java_awt_LayoutManager);
this.setContentPane$java_awt_Container(contentPane);
var gridbag=Clazz.new_($I$(10,1));
var panel=Clazz.new_($I$(8,1).c$$java_awt_LayoutManager,[gridbag]);
contentPane.add$java_awt_Component$O(panel, "Center");
var c=Clazz.new_($I$(11,1));
c.anchor=17;
c.fill=0;
c.weightx=0.0;
c.gridx=0;
c.insets=Clazz.new_($I$(12,1).c$$I$I$I$I,[5, 5, 0, 2]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.percentLabel, c);
panel.add$java_awt_Component(this.this$0.percentLabel);
c.anchor=13;
c.fill=2;
c.gridx=1;
c.insets=Clazz.new_($I$(12,1).c$$I$I$I$I,[5, 0, 0, 0]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.percentField, c);
panel.add$java_awt_Component(this.this$0.percentField);
c.gridx=2;
c.weightx=1.0;
c.insets=Clazz.new_($I$(12,1).c$$I$I$I$I,[5, 0, 0, 5]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.percentSlider, c);
panel.add$java_awt_Component(this.this$0.percentSlider);
c.weightx=0.0;
c.gridx=0;
c.gridy=1;
c.insets=Clazz.new_($I$(12,1).c$$I$I$I$I,[5, 5, 0, 2]);
c.anchor=17;
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.frameCountLabel, c);
panel.add$java_awt_Component(this.this$0.frameCountLabel);
c.gridx=1;
c.insets=Clazz.new_($I$(12,1).c$$I$I$I$I,[5, 0, 0, 0]);
c.anchor=13;
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.frameCountField, c);
panel.add$java_awt_Component(this.this$0.frameCountField);
c.gridx=2;
c.insets=Clazz.new_($I$(12,1).c$$I$I$I$I,[8, 0, 0, 0]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.showMeanCheckBox, c);
panel.add$java_awt_Component(this.this$0.showMeanCheckBox);
var buttonbar=Clazz.new_([Clazz.new_($I$(13,1))],$I$(8,1).c$$java_awt_LayoutManager);
buttonbar.add$java_awt_Component(this.this$0.ableButton);
buttonbar.add$java_awt_Component(this.this$0.clearButton);
buttonbar.add$java_awt_Component(this.this$0.closeButton);
contentPane.add$java_awt_Component$O(buttonbar, "South");
});

Clazz.newMeth(C$, 'initialize$', function () {
this.this$0.showMeanCheckBox.setSelected$Z(this.this$0.mean);
this.this$0.refresh$.apply(this.this$0, []);
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.SumFilter, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
if ((filter.frame != null ) && (filter.inspector != null ) && filter.inspector.isVisible$()  ) {
var x=filter.inspector.getLocation$().x - filter.frame.getLocation$().x;
var y=filter.inspector.getLocation$().y - filter.frame.getLocation$().y;
control.setValue$S$I("inspector_x", x);
control.setValue$S$I("inspector_y", y);
}});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(14,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
filter.inspectorX=control.getInt$S("inspector_x");
filter.inspectorY=control.getInt$S("inspector_y");
return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-26 22:52:37 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
