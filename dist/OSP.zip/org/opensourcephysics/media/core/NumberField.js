(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'java.awt.Color','java.text.NumberFormat','javax.swing.SwingUtilities','java.awt.event.KeyAdapter','java.awt.event.FocusAdapter','java.awt.event.MouseAdapter','java.awt.Toolkit','org.opensourcephysics.display.OSPRuntime']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "NumberField", null, 'javax.swing.JTextField');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.format=$I$(2).getInstance$();
this.fixedPattern=false;
this.patterns=Clazz.array(String, [5]);
this.ranges=Clazz.array(Double.TYPE, -1, [0.1, 10, 100, 1000]);
this.conversionFactor=1.0;
this.userPattern="";
},1);

C$.$fields$=[['Z',['fixedPattern','fixedPatternByDefault'],'D',['prevValue','conversionFactor'],'I',['sigfigs'],'S',['units','userPattern'],'O',['format','java.text.DecimalFormat','maxValue','Double','+minValue','patterns','String[]','ranges','double[]']]
,['O',['DISABLED_COLOR','java.awt.Color']]]

Clazz.newMeth(C$, 'c$$I', function (columns) {
C$.c$$I$I.apply(this, [columns, 4]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (columns, sigfigs) {
;C$.superclazz.c$$I.apply(this,[columns]);C$.$init$.apply(this);
this.setBackground$java_awt_Color($I$(1).white);
this.setDisabledTextColor$java_awt_Color(C$.DISABLED_COLOR);
this.setText$S("0");
this.addKeyListener$java_awt_event_KeyListener(((P$.NumberField$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "NumberField$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
if (!this.b$['javax.swing.text.JTextComponent'].isEditable$.apply(this.b$['javax.swing.text.JTextComponent'], [])) return;
if (e.getKeyCode$() == 10) {
var runner=((P$.NumberField$1$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "NumberField$1$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
this.b$['javax.swing.JComponent'].setBackground$java_awt_Color.apply(this.b$['javax.swing.JComponent'], [$I$(1).white]);
this.b$['org.opensourcephysics.media.core.NumberField'].setValue$D.apply(this.b$['org.opensourcephysics.media.core.NumberField'], [this.b$['org.opensourcephysics.media.core.NumberField'].getValue$.apply(this.b$['org.opensourcephysics.media.core.NumberField'], [])]);
});
})()
), Clazz.new_(P$.NumberField$1$1.$init$,[this, null]));
$I$(3).invokeLater$Runnable(runner);
} else {
this.b$['javax.swing.JComponent'].setBackground$java_awt_Color.apply(this.b$['javax.swing.JComponent'], [$I$(1).yellow]);
}});
})()
), Clazz.new_($I$(4,1),[this, null],P$.NumberField$1)));
this.addFocusListener$java_awt_event_FocusListener(((P$.NumberField$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "NumberField$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.FocusAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
if (!this.b$['javax.swing.text.JTextComponent'].isEditable$.apply(this.b$['javax.swing.text.JTextComponent'], [])) return;
var runner=((P$.NumberField$2$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "NumberField$2$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
this.b$['javax.swing.JComponent'].setBackground$java_awt_Color.apply(this.b$['javax.swing.JComponent'], [$I$(1).white]);
this.b$['org.opensourcephysics.media.core.NumberField'].setValue$D.apply(this.b$['org.opensourcephysics.media.core.NumberField'], [this.b$['org.opensourcephysics.media.core.NumberField'].getValue$.apply(this.b$['org.opensourcephysics.media.core.NumberField'], [])]);
});
})()
), Clazz.new_(P$.NumberField$2$1.$init$,[this, null]));
$I$(3).invokeLater$Runnable(runner);
});
})()
), Clazz.new_($I$(5,1),[this, null],P$.NumberField$2)));
this.addMouseListener$java_awt_event_MouseListener(((P$.NumberField$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "NumberField$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
if (!this.b$['javax.swing.text.JTextComponent'].isEditable$.apply(this.b$['javax.swing.text.JTextComponent'], [])) return;
if (e.getClickCount$() == 2) {
this.b$['javax.swing.text.JTextComponent'].selectAll$.apply(this.b$['javax.swing.text.JTextComponent'], []);
}});
})()
), Clazz.new_($I$(6,1),[this, null],P$.NumberField$3)));
this.setSigFigs$I(sigfigs);
}, 1);

Clazz.newMeth(C$, 'getValue$', function () {
var s=this.getText$().trim$();
if ("".equals$O(s)) return this.prevValue;
if ((this.units != null ) && !this.units.equals$O("") ) {
var n=s.indexOf$S(this.units);
while (n > -1){
s=s.substring$I$I(0, n);
n=s.indexOf$S(this.units);
}
}if (s.equals$O(this.format.format$D(this.prevValue * this.conversionFactor))) {
return this.prevValue;
}var retValue;
try {
retValue=this.format.parse$S(s).doubleValue$() / this.conversionFactor;
if (this.minValue != null  && retValue < (this.minValue).valueOf()  ) {
this.setValue$D((this.minValue).valueOf());
return (this.minValue).valueOf();
}if (this.maxValue != null  && retValue > (this.maxValue).valueOf()  ) {
this.setValue$D((this.maxValue).valueOf());
return (this.maxValue).valueOf();
}} catch (e) {
if (Clazz.exceptionOf(e,"java.text.ParseException")){
$I$(7).getDefaultToolkit$().beep$();
this.setValue$D(this.prevValue);
return this.prevValue;
} else {
throw e;
}
}
return retValue;
});

Clazz.newMeth(C$, 'setValue$D', function (value) {
if (!this.isVisible$()) {
return;
}if (this.minValue != null ) {
value=Math.max(value, this.minValue.doubleValue$());
}if (this.maxValue != null ) {
value=Math.min(value, this.maxValue.doubleValue$());
}this.prevValue=value;
value=this.conversionFactor * value;
this.setFormatFor$D(value);
var s=this.getFormat$().format$D(value);
if (this.units != null ) {
s += this.units;
}if (!s.equals$O(this.getText$())) {
this.setText$S(s);
}});

Clazz.newMeth(C$, 'setExpectedRange$D$D', function (lower, upper) {
this.fixedPattern=this.fixedPatternByDefault=true;
var range=Math.max(Math.abs(lower), Math.abs(upper));
if ((range < 0.1 ) || (range >= 1000 ) ) {
var s="";
for (var i=0; i < this.sigfigs - 1; i++) {
s += "0";
}
this.format.applyPattern$S("0." + s + "E0" );
} else {
var n;
if (range < 1 ) {
n=this.sigfigs;
} else if (range < 10 ) {
n=this.sigfigs - 1;
} else if (range < 100 ) {
n=this.sigfigs - 2;
} else {
n=this.sigfigs - 3;
}var s="";
for (var i=0; i < n; i++) {
s += "0";
}
if (s.equals$O("")) {
this.format.applyPattern$S("0");
} else {
this.format.applyPattern$S("0." + s);
}}});

Clazz.newMeth(C$, 'setSigFigs$I', function (sigfigs) {
if (this.sigfigs == sigfigs) {
return;
}this.ranges=Clazz.array(Double.TYPE, -1, [0.1, 10, 100, 1000]);
sigfigs=Math.max(sigfigs, 2);
this.sigfigs=Math.min(sigfigs, 6);
var d=".";
if (sigfigs == 2) {
this.patterns[0]="0" + d + "0E0" ;
this.patterns[1]="0" + d + "0" ;
this.patterns[2]="0";
this.patterns[3]="0" + d + "0E0" ;
this.patterns[4]="0" + d + "0E0" ;
} else if (sigfigs == 3) {
this.patterns[0]="0" + d + "00E0" ;
this.patterns[1]="0" + d + "00" ;
this.patterns[2]="0" + d + "0" ;
this.patterns[3]="0";
this.patterns[4]="0" + d + "00E0" ;
} else if (sigfigs >= 4) {
this.patterns[0]="0" + d + "000E0" ;
this.patterns[1]="0" + d + "000" ;
this.patterns[2]="0" + d + "00" ;
this.patterns[3]="0" + d + "0" ;
this.patterns[4]="0" + d + "000E0" ;
var n=sigfigs - 4;
for (var i=0; i < n; i++) {
for (var j=0; j < this.patterns.length; j++) {
this.patterns[j]="0" + d + "0" + this.patterns[j].substring$I(2) ;
}
}
}});

Clazz.newMeth(C$, 'setMinValue$D', function (min) {
if (Double.isNaN$D(min)) {
this.minValue=null;
} else {
this.minValue= new Double(min);
}});

Clazz.newMeth(C$, 'setMaxValue$D', function (max) {
if (Double.isNaN$D(max)) {
this.maxValue=null;
} else {
this.maxValue= new Double(max);
}});

Clazz.newMeth(C$, 'setUnits$S', function (units) {
var val=this.getValue$();
this.units=units;
this.setValue$D(val);
});

Clazz.newMeth(C$, 'getUnits$', function () {
return this.units;
});

Clazz.newMeth(C$, 'setConversionFactor$D', function (factor) {
this.conversionFactor=factor;
this.setValue$D(this.prevValue);
});

Clazz.newMeth(C$, 'getConversionFactor$', function () {
return this.conversionFactor;
});

Clazz.newMeth(C$, 'getFormat$', function () {
this.format.setDecimalFormatSymbols$java_text_DecimalFormatSymbols($I$(8).getDecimalFormatSymbols$());
return this.format;
});

Clazz.newMeth(C$, 'setFormatFor$D', function (value) {
if (this.fixedPattern) {
return;
}value=Math.abs(value);
if (value == 0 ) {
if (this.sigfigs == 1) {
this.format.applyPattern$S("0");
} else if (this.sigfigs == 2) {
this.format.applyPattern$S("0.0");
} else if (this.sigfigs == 3) {
this.format.applyPattern$S("0.00");
} else {
this.format.applyPattern$S("0.000");
}} else if (value < this.ranges[0] ) {
this.format.applyPattern$S(this.patterns[0]);
} else if (value < this.ranges[1] ) {
this.format.applyPattern$S(this.patterns[1]);
} else if (value < this.ranges[2] ) {
this.format.applyPattern$S(this.patterns[2]);
} else if (value < this.ranges[3] ) {
this.format.applyPattern$S(this.patterns[3]);
} else {
this.format.applyPattern$S(this.patterns[4]);
}});

Clazz.newMeth(C$, 'setPatterns$SA', function (patterns) {
this.setPatterns$SA$DA(patterns, Clazz.array(Double.TYPE, -1, [0.1, 10, 100, 1000]));
});

Clazz.newMeth(C$, 'setPatterns$SA$DA', function (patterns, limits) {
if (patterns.length > 4 && limits.length > 3 ) {
this.patterns=patterns;
this.ranges=limits;
}});

Clazz.newMeth(C$, 'setFixedPattern$S', function (pattern) {
if (pattern == null ) pattern="";
pattern=pattern.trim$();
if (pattern.equals$O(this.userPattern)) return;
this.userPattern=pattern;
if (this.userPattern.equals$O("")) {
this.fixedPattern=this.fixedPatternByDefault;
this.setFormatFor$D(this.getValue$());
} else {
this.fixedPattern=true;
this.format.applyPattern$S(this.userPattern);
}this.setValue$D(this.prevValue);
});

Clazz.newMeth(C$, 'getFixedPattern$', function () {
return this.userPattern;
});

C$.$static$=function(){C$.$static$=0;
C$.DISABLED_COLOR=Clazz.new_($I$(1,1).c$$I$I$I,[120, 120, 120]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-05 21:40:09 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
