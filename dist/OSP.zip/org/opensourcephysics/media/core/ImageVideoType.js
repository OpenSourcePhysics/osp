(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'java.util.TreeSet','org.opensourcephysics.media.core.ImageVideo','org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XMLControlElement','org.opensourcephysics.media.core.ImageVideoRecorder','org.opensourcephysics.media.core.MediaRes','org.opensourcephysics.media.core.VideoFileFilter']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ImageVideoType", null, null, 'org.opensourcephysics.media.core.VideoType');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['singleTypeFilter','org.opensourcephysics.media.core.VideoFileFilter']]
,['O',['imageFileFilters','java.util.TreeSet']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_media_core_VideoFileFilter', function (filter) {
C$.c$.apply(this, []);
if (filter != null ) {
this.singleTypeFilter=filter;
C$.imageFileFilters.add$O(filter);
}}, 1);

Clazz.newMeth(C$, 'getVideo$java_io_File', function (file) {
try {
var video=Clazz.new_([file.getAbsolutePath$(), true],$I$(2,1).c$$S$Z);
video.setProperty$S$O("video_type", this);
return video;
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
return null;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'getVideo$S', function (name) {
var xmlName=$I$(3).stripExtension$S(name) + ".xml";
var control=Clazz.new_($I$(4,1).c$$S,[xmlName]);
if (!control.failedToRead$() && control.getObjectClass$() === Clazz.getClass($I$(2))  ) {
return control.loadObject$O(null);
}try {
var video=Clazz.new_($I$(2,1).c$$S$Z,[name, true]);
video.setProperty$S$O("video_type", this);
return video;
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
return null;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'getRecorder$', function () {
return Clazz.new_($I$(5,1).c$$org_opensourcephysics_media_core_ImageVideoType,[this]);
});

Clazz.newMeth(C$, 'canRecord$', function () {
return true;
});

Clazz.newMeth(C$, 'getDescription$', function () {
if (this.singleTypeFilter != null ) return this.singleTypeFilter.getDescription$();
return $I$(6).getString$S("ImageVideoType.Description");
});

Clazz.newMeth(C$, 'getDefaultExtension$', function () {
if (this.singleTypeFilter != null ) {
return this.singleTypeFilter.getDefaultExtension$();
}return null;
});

Clazz.newMeth(C$, 'getFileFilters$', function () {
return C$.imageFileFilters.toArray$OA(Clazz.array($I$(7), [0]));
});

Clazz.newMeth(C$, 'getDefaultFileFilter$', function () {
if (this.singleTypeFilter != null ) return this.singleTypeFilter;
return null;
});

Clazz.newMeth(C$, 'isType$org_opensourcephysics_media_core_Video', function (video) {
return video.getClass$().equals$O(Clazz.getClass($I$(2)));
});

C$.$static$=function(){C$.$static$=0;
C$.imageFileFilters=Clazz.new_($I$(1,1));
};
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-26 22:52:37 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
