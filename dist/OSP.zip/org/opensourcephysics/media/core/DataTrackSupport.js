(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'org.opensourcephysics.controls.XMLControlElement','org.opensourcephysics.media.core.DataTrackSupport','javax.swing.event.SwingPropertyChangeSupport','java.util.HashSet','org.opensourcephysics.display.OSPRuntime','java.io.File','java.util.ArrayList','ProcessBuilder','org.opensourcephysics.controls.OSPLog','javax.swing.Timer','java.util.TreeMap','org.opensourcephysics.tools.LocalJob','java.util.jar.JarFile','java.io.InputStreamReader','java.io.BufferedReader','Thread','java.rmi.registry.LocateRegistry',['org.opensourcephysics.media.core.DataTrackSupport','.SupportTool'],['org.opensourcephysics.media.core.DataTrackSupport','.Message']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DataTrackSupport", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['SupportTool',10],['Message',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['Z',['connected'],'O',['remoteTool','org.opensourcephysics.tools.Tool','+supportTool','messageControl','org.opensourcephysics.controls.XMLControl','timer','javax.swing.Timer','support','java.beans.PropertyChangeSupport','dataNames','java.util.HashSet']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'connect$I$java_beans_PropertyChangeListener', function (id, listener) {
if (!C$.isTrackerAvailable$()) return false;
C$.support.removePropertyChangeListener$java_beans_PropertyChangeListener(listener);
C$.support.addPropertyChangeListener$java_beans_PropertyChangeListener(listener);
if (C$.getRemoteTool$() != null ) {
if (C$.connected) {
return true;
}return C$.sendHandshake$I(id);
}var trackerHome=$I$(5).getPreference$S("TRACKER_HOME");
var trackerPath=Clazz.new_($I$(6,1).c$$S$S,[trackerHome, "tracker.jar"]).getAbsolutePath$();
var cmd=Clazz.new_($I$(7,1));
cmd.add$O("java");
cmd.add$O("-classpath");
cmd.add$O(trackerPath);
cmd.add$O("org.opensourcephysics.cabrillo.tracker.deploy.TrackerStarter");
var builder=Clazz.new_($I$(8,1).c$$java_util_List,[cmd]);
var launchMessage="launching Tracker with command ";
for (var next, $next = cmd.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
launchMessage += next + " ";
}
$I$(9).config$S(launchMessage);
C$.startProcess$ProcessBuilder(builder);
if (C$.timer == null ) {
C$.timer=Clazz.new_([500, ((P$.DataTrackSupport$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTrackSupport$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if ($I$(2).getRemoteTool$() != null ) {
$I$(2).timer.stop$();
$I$(2).sendHandshake$I(this.$finals$.id);
}});
})()
), Clazz.new_(P$.DataTrackSupport$1.$init$,[this, {id:id}]))],$I$(10,1).c$$I$java_awt_event_ActionListener);
}C$.timer.setInitialDelay$I(1000);
C$.timer.setRepeats$Z(true);
C$.timer.start$();
return true;
}, 1);

Clazz.newMeth(C$, 'sendData$I$org_opensourcephysics_display_Data', function (id, data) {
if (data == null ) return false;
var message=Clazz.new_($I$(11,1));
message.put$O$O("data", data);
return C$.sendMessage$I$java_util_Map(id, message);
}, 1);

Clazz.newMeth(C$, 'sendAppendedData$I$org_opensourcephysics_display_Data', function (id, data) {
if (data == null ) return false;
if (!C$.dataNames.contains$O(data.getName$())) {
return C$.sendData$I$org_opensourcephysics_display_Data(id, data);
}var message=Clazz.new_($I$(11,1));
message.put$O$O("data", data);
message.put$O$O("append", new Boolean(true));
return C$.sendMessage$I$java_util_Map(id, message);
}, 1);

Clazz.newMeth(C$, 'sendMessage$I$java_util_Map', function (id, message) {
var tool=C$.getRemoteTool$();
if (tool == null ) return false;
var control=C$.getMessageControl$I(id);
var data=null;
for (var key, $key = message.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
var value=message.get$O(key);
if (key.equals$O("data")) {
data=value;
}control.setValue$S$O(key, value);
}
try {
tool.send$org_opensourcephysics_tools_Job$org_opensourcephysics_tools_Tool(Clazz.new_([control.toXML$()],$I$(12,1).c$$S), C$.getSupportTool$());
} catch (e) {
if (Clazz.exceptionOf(e,"java.rmi.RemoteException")){
return false;
} else {
throw e;
}
}
if (data != null ) {
C$.dataNames.add$O(data.getName$());
}return true;
}, 1);

Clazz.newMeth(C$, 'isTrackerAvailable$', function () {
var trackerHome=$I$(5).getPreference$S("TRACKER_HOME");
if (trackerHome == null ) {
return false;
}var file=Clazz.new_($I$(6,1).c$$S$S,[trackerHome, "tracker.jar"]);
if (!file.exists$()) {
return false;
}try {
var jar=Clazz.new_($I$(13,1).c$$java_io_File,[file]);
var mf=jar.getManifest$();
jar.close$();
var attributes=mf.getMainAttributes$();
for (var obj, $obj = attributes.keySet$().iterator$(); $obj.hasNext$()&&((obj=($obj.next$())),1);) {
var key=obj.toString();
if (key.contains$CharSequence("Build-Date")) {
var val=attributes.getValue$S(key);
var year=Integer.parseInt$S(val.substring$I$I(val.length$() - 4, val.length$()));
if (year < 2015) return false;
}}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return false;
} else {
throw e;
}
}
return true;
}, 1);

Clazz.newMeth(C$, 'isDataRequested$', function () {
return System.getenv$S("DATA_REQUESTED") != null ;
}, 1);

Clazz.newMeth(C$, 'sendHandshake$I', function (id) {
var control=C$.getMessageControl$I(id);
control.setValue$S$Z("handshake", true);
control.setValue$S$O("jar_path", $I$(5).getLaunchJarPath$());
try {
C$.remoteTool.send$org_opensourcephysics_tools_Job$org_opensourcephysics_tools_Tool(Clazz.new_([control.toXML$()],$I$(12,1).c$$S), C$.getSupportTool$());
} catch (e) {
if (Clazz.exceptionOf(e,"java.rmi.RemoteException")){
return false;
} else {
throw e;
}
}
return true;
}, 1);

Clazz.newMeth(C$, 'startProcess$ProcessBuilder', function (builder) {
var runner=((P$.DataTrackSupport$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "DataTrackSupport$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
try {
var process=this.$finals$.builder.start$();
var is=process.getInputStream$();
var isr=Clazz.new_($I$(14,1).c$$java_io_InputStream,[is]);
var br=Clazz.new_($I$(15,1).c$$java_io_Reader,[isr]);
var line;
while ((line=br.readLine$()) != null ){
System.out.println$S(line);
}
br.close$();
var result=process.waitFor$();
if (result > 0) {
isr=Clazz.new_([process.getErrorStream$()],$I$(14,1).c$$java_io_InputStream);
br=Clazz.new_($I$(15,1).c$$java_io_Reader,[isr]);
while ((line=br.readLine$()) != null ){
System.err.println$S(line);
}
br.close$();
}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
ex.printStackTrace$();
} else {
throw ex;
}
}
});
})()
), Clazz.new_(P$.DataTrackSupport$2.$init$,[this, {builder:builder}]));
Clazz.new_($I$(16,1).c$$Runnable,[runner]).start$();
}, 1);

Clazz.newMeth(C$, 'getRemoteTool$', function () {
if (C$.remoteTool == null ) {
try {
var registry=$I$(17).getRegistry$S$I("localhost", 1099);
C$.remoteTool=registry.lookup$S("DataTrackTool");
return C$.remoteTool;
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
}return C$.remoteTool;
}, 1);

Clazz.newMeth(C$, 'getSupportTool$', function () {
if (C$.supportTool == null ) {
try {
C$.supportTool=Clazz.new_($I$(18,1));
} catch (e) {
if (Clazz.exceptionOf(e,"java.rmi.RemoteException")){
} else {
throw e;
}
}
}return C$.supportTool;
}, 1);

Clazz.newMeth(C$, 'getMessageControl$I', function (id) {
if (C$.messageControl == null ) {
C$.messageControl=Clazz.new_([Clazz.new_($I$(19,1))],$I$(1,1).c$$O);
}for (var name, $name = C$.messageControl.getPropertyNames$().iterator$(); $name.hasNext$()&&((name=($name.next$())),1);) {
C$.messageControl.setValue$S$O(name, null);
}
C$.messageControl.setValue$S$I("sourceID", id);
return C$.messageControl;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.support=Clazz.new_([ Clazz.new_()],$I$(3,1).c$$O);
C$.dataNames=Clazz.new_($I$(4,1));
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTrackSupport, "SupportTool", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'java.rmi.server.UnicastRemoteObject', 'org.opensourcephysics.tools.Tool');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'send$org_opensourcephysics_tools_Job$org_opensourcephysics_tools_Tool', function (job, replyTo) {
var control=Clazz.new_($I$(1,1));
control.readXML$S(job.getXML$());
if (control.failedToRead$()) return;
var sourceID=control.getInt$S("sourceID");
if (control.getBoolean$S("handshake")) {
$I$(2).connected=true;
$I$(2).support.firePropertyChange$S$O$O("tracker_ready", new Integer(sourceID), null);
} else if (control.getBoolean$S("exiting")) {
$I$(2).remoteTool=null;
$I$(2).connected=false;
$I$(2).support.firePropertyChange$S$O$O("tracker_exited", null, null);
}});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DataTrackSupport, "Message", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-05 21:40:08 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
