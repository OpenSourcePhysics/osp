(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'org.opensourcephysics.media.core.VideoClip','org.opensourcephysics.tools.ResourceLoader','org.opensourcephysics.media.core.VideoIO','org.opensourcephysics.controls.OSPLog','java.util.ArrayList','org.opensourcephysics.controls.XML','javax.swing.JOptionPane','org.opensourcephysics.media.core.MediaRes','javax.swing.JCheckBox','java.io.File','javax.swing.event.SwingPropertyChangeSupport','org.opensourcephysics.media.core.ClipInspector',['org.opensourcephysics.media.core.VideoClip','.Loader']]],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VideoClip", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.startFrame=0;
this.stepSize=1;
this.stepCount=10;
this.frameCount=this.stepCount;
this.maxFrameCount=300000;
this.frameShift=0;
this.startTime=0;
this.isDefaultStartTime=true;
this.video=null;
this.playAllSteps=false;
this.isAdjusting=false;
this.startTimeIsSaved=false;
this.extraFrames=0;
},1);

C$.$fields$=[['Z',['changeEngine','isDefaultStartTime','playAllSteps','isDefaultState','isAdjusting','startTimeIsSaved'],'D',['startTime','savedStartTime'],'I',['startFrame','stepSize','stepCount','frameCount','maxFrameCount','frameShift','endFrame','extraFrames'],'S',['readoutType','videoPath'],'O',['video','org.opensourcephysics.media.core.Video','stepFrames','int[]','inspector','org.opensourcephysics.media.core.ClipInspector','support','java.beans.PropertyChangeSupport']]]

Clazz.newMeth(C$, 'c$$org_opensourcephysics_media_core_Video', function (video) {
;C$.$init$.apply(this);
this.support=Clazz.new_($I$(11,1).c$$O,[this]);
this.video=video;
if (video != null ) {
video.setProperty$S$O("videoclip", this);
this.setStartFrameNumber$I(video.getStartFrameNumber$());
if (video.getFrameCount$() > 1) {
this.setStepCount$I(video.getEndFrameNumber$() - this.startFrame + 1);
}}p$1.updateArray.apply(this, []);
this.isDefaultState=true;
}, 1);

Clazz.newMeth(C$, 'getVideo$', function () {
return this.video;
});

Clazz.newMeth(C$, 'getVideoPath$', function () {
if (this.video != null ) return this.video.getProperty$S("absolutePath");
return this.videoPath;
});

Clazz.newMeth(C$, 'setStartFrameNumber$I', function (start) {
var maxEndFrame=this.getLastFrameNumber$();
return this.setStartFrameNumber$I$I(start, maxEndFrame);
});

Clazz.newMeth(C$, 'setStartFrameNumber$I$I', function (start, maxStart) {
var prevStart=this.getStartFrameNumber$();
var prevEnd=this.getEndFrameNumber$();
start=Math.max(start, this.getFirstFrameNumber$());
start=Math.min(start, maxStart);
if (this.video != null  && this.video.getFrameCount$() > 1 ) {
this.video.setEndFrameNumber$I(this.video.getFrameCount$() - 1);
var vidStart=Math.max(0, start + this.frameShift);
this.video.setStartFrameNumber$I(vidStart);
this.startFrame=Math.max(0, this.video.getStartFrameNumber$() - this.frameShift);
} else {
this.startFrame=start;
p$1.updateArray.apply(this, []);
}start=this.getStartFrameNumber$();
this.setEndFrameNumber$I(prevEnd);
if (prevStart != start) {
this.isDefaultState=false;
this.support.firePropertyChange$S$O$O("startframe", null,  new Integer(start));
}return prevStart != start;
});

Clazz.newMeth(C$, 'getStartFrameNumber$', function () {
return this.startFrame;
});

Clazz.newMeth(C$, 'setStepSize$I', function (size) {
this.isDefaultState=false;
if (size == 0) {
return false;
}size=Math.abs(size);
if (this.video != null  && this.video.getFrameCount$() > 1 ) {
var maxSize=Math.max(this.video.getFrameCount$() - this.startFrame - 1  + this.extraFrames, 1);
size=Math.min(size, maxSize);
}if (this.stepSize == size) {
return false;
}var endFrame=this.getEndFrameNumber$();
this.stepSize=size;
this.stepCount=1 + ((endFrame - this.getStartFrameNumber$())/this.stepSize|0);
p$1.updateArray.apply(this, []);
this.support.firePropertyChange$S$O$O("stepsize", null,  new Integer(size));
this.setEndFrameNumber$I(endFrame);
return true;
});

Clazz.newMeth(C$, 'getStepSize$', function () {
return this.stepSize;
});

Clazz.newMeth(C$, 'setStepCount$I', function (count) {
if (count == 0) {
return;
}count=Math.abs(count);
if (this.video != null ) {
if (this.video.getFrameCount$() > 1) {
var end=this.video.getFrameCount$() - 1 - this.frameShift  + this.extraFrames;
var maxCount=1 + (((end - this.startFrame) / (1.0 * this.stepSize))|0);
count=Math.min(count, maxCount);
}var end=this.startFrame + (count - 1) * this.stepSize + this.frameShift;
if (end != this.video.getEndFrameNumber$()) {
this.video.setEndFrameNumber$I(end);
}} else {
count=Math.min(count, this.frameToStep$I(this.maxFrameCount - 1) + 1);
}count=Math.max(count, 1);
if (this.stepCount == count) {
p$1.updateArray.apply(this, []);
return;
}var prev= new Integer(this.stepCount);
this.stepCount=count;
p$1.updateArray.apply(this, []);
this.support.firePropertyChange$S$O$O("stepcount", prev,  new Integer(this.stepCount));
});

Clazz.newMeth(C$, 'getStepCount$', function () {
return this.stepCount;
});

Clazz.newMeth(C$, 'setFrameShift$I', function (n) {
var start=this.getStartFrameNumber$();
var steps=this.getStepCount$();
return this.setFrameShift$I$I$I(n, start, steps);
});

Clazz.newMeth(C$, 'setFrameShift$I$I$I', function (n, start, stepCount) {
return this.frameShift;
});

Clazz.newMeth(C$, 'getFrameShift$', function () {
return this.frameShift;
});

Clazz.newMeth(C$, 'setExtraFrames$I', function (extras) {
var prev=this.extraFrames;
this.extraFrames=Math.max(extras, 0);
if (prev != this.extraFrames) {
$I$(4).finest$S("set extra frames to " + this.extraFrames);
this.setStepCount$I(this.stepCount);
}});

Clazz.newMeth(C$, 'getExtraFrames$', function () {
return this.extraFrames;
});

Clazz.newMeth(C$, 'getFrameCount$', function () {
if (this.video != null  && this.video.getFrameCount$() > 1 ) {
var n=this.video.getFrameCount$() + this.extraFrames;
n=Math.min(n, n - this.frameShift);
n=Math.max(1, n);
return n;
}var frames=this.getEndFrameNumber$() + 1;
this.frameCount=Math.max(this.frameCount, frames);
this.frameCount=Math.min(this.frameCount, this.maxFrameCount);
return this.frameCount;
});

Clazz.newMeth(C$, 'setStartTime$D', function (t0) {
this.isDefaultState=false;
if (this.startTime == t0  || (this.isDefaultStartTime && Double.isNaN$D(t0) ) ) {
return;
}this.isDefaultStartTime=Double.isNaN$D(t0);
this.startTime=Double.isNaN$D(t0) ? 0.0 : t0;
this.support.firePropertyChange$S$O$O("starttime", null,  new Double(this.startTime));
});

Clazz.newMeth(C$, 'getStartTime$', function () {
return this.startTime;
});

Clazz.newMeth(C$, 'getEndFrameNumber$', function () {
this.endFrame=this.startFrame + this.stepSize * (this.stepCount - 1);
return this.endFrame;
});

Clazz.newMeth(C$, 'setEndFrameNumber$I', function (end) {
return p$1.setEndFrameNumber$I$I$Z.apply(this, [end, this.maxFrameCount - 1 - this.frameShift , true]);
});

Clazz.newMeth(C$, 'extendEndFrameNumber$I', function (end) {
if (this.video != null  && this.getFrameCount$() <= end ) {
this.setExtraFrames$I(end + 1 - this.getFrameCount$() + this.extraFrames);
}return this.setEndFrameNumber$I(end);
});

Clazz.newMeth(C$, 'setEndFrameNumber$I$I$Z', function (end, max, onlyIfChanged) {
var prev=this.getEndFrameNumber$();
if (prev == end && onlyIfChanged ) return false;
this.isDefaultState=false;
end=Math.max(end, this.startFrame);
var rem=(end - this.startFrame) % this.stepSize;
var count=((end - this.startFrame)/this.stepSize|0);
if (rem * 1.0 / this.stepSize > 0.5 ) {
count++;
}while (this.stepToFrame$I(count) > max){
count--;
}
this.setStepCount$I(count + 1);
end=this.getEndFrameNumber$();
if (end != this.startFrame) {
var maxStepSize=Math.max(end - this.startFrame, 1);
if (maxStepSize < this.stepSize) {
this.stepSize=maxStepSize;
}}return prev != end;
}, p$1);

Clazz.newMeth(C$, 'stepToFrame$I', function (stepNumber) {
return this.startFrame + stepNumber * this.stepSize;
});

Clazz.newMeth(C$, 'frameToStep$I', function (n) {
return (((n - this.startFrame) / (1.0 * this.stepSize))|0);
});

Clazz.newMeth(C$, 'includesFrame$I', function (n) {
for (var i=0; i < this.stepCount; i++) {
if (this.stepFrames[i] == n) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'getClipInspector$', function () {
return this.inspector;
});

Clazz.newMeth(C$, 'getClipInspector$org_opensourcephysics_media_core_ClipControl$java_awt_Frame', function (control, frame) {
if (this.inspector == null ) {
this.inspector=Clazz.new_($I$(12,1).c$$org_opensourcephysics_media_core_VideoClip$org_opensourcephysics_media_core_ClipControl$java_awt_Frame,[this, control, frame]);
}return this.inspector;
});

Clazz.newMeth(C$, 'hideClipInspector$', function () {
if (this.inspector != null ) {
this.inspector.setVisible$Z(false);
}});

Clazz.newMeth(C$, 'isDefaultState$', function () {
return this.isDefaultState && this.inspector == null  ;
});

Clazz.newMeth(C$, 'setAdjusting$Z', function (adjusting) {
if (this.isAdjusting == adjusting ) return;
this.isAdjusting=adjusting;
this.support.firePropertyChange$S$O$O("adjusting", null, new Boolean(adjusting));
});

Clazz.newMeth(C$, 'isAdjusting$', function () {
return this.isAdjusting;
});

Clazz.newMeth(C$, 'setPlayAllSteps$Z', function (all) {
this.playAllSteps=all;
});

Clazz.newMeth(C$, 'isPlayAllSteps$', function () {
return this.playAllSteps;
});

Clazz.newMeth(C$, 'addPropertyChangeListener$java_beans_PropertyChangeListener', function (listener) {
this.support.addPropertyChangeListener$java_beans_PropertyChangeListener(listener);
});

Clazz.newMeth(C$, 'addPropertyChangeListener$S$java_beans_PropertyChangeListener', function (property, listener) {
this.support.addPropertyChangeListener$S$java_beans_PropertyChangeListener(property, listener);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$java_beans_PropertyChangeListener', function (listener) {
this.support.removePropertyChangeListener$java_beans_PropertyChangeListener(listener);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$S$java_beans_PropertyChangeListener', function (property, listener) {
this.support.removePropertyChangeListener$S$java_beans_PropertyChangeListener(property, listener);
});

Clazz.newMeth(C$, 'trimFrameCount$', function () {
if (this.video == null  || this.video.getFrameCount$() == 1 ) {
this.frameCount=this.getEndFrameNumber$() + 1;
this.support.firePropertyChange$S$O$O("framecount", null,  new Integer(this.frameCount));
}});

Clazz.newMeth(C$, 'updateArray', function () {
this.stepFrames=Clazz.array(Integer.TYPE, [this.stepCount]);
for (var i=0; i < this.stepCount; i++) {
this.stepFrames[i]=this.stepToFrame$I(i);
}
}, p$1);

Clazz.newMeth(C$, 'getFirstFrameNumber$', function () {
if (this.video == null ) return 0;
return Math.max(0, -this.frameShift);
});

Clazz.newMeth(C$, 'getLastFrameNumber$', function () {
if (this.video == null  || this.video.getFrameCount$() == 1 ) {
return this.getEndFrameNumber$();
}var finalVideoFrame=this.video.getFrameCount$() - 1 + this.extraFrames;
return Math.max(0, finalVideoFrame - this.frameShift);
});

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(13,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.VideoClip, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var clip=obj;
var video=clip.getVideo$();
if (video != null ) {
if (Clazz.instanceOf(video, "org.opensourcephysics.media.core.ImageVideo")) {
var vid=video;
if (vid.isFileBased$()) {
control.setValue$S$O("video", video);
}control.setValue$S$I("video_framecount", clip.getFrameCount$());
} else {
control.setValue$S$O("video", video);
control.setValue$S$I("video_framecount", video.getFrameCount$());
}}control.setValue$S$I("startframe", clip.getStartFrameNumber$());
control.setValue$S$I("stepsize", clip.getStepSize$());
control.setValue$S$I("stepcount", clip.getStepCount$());
control.setValue$S$D("starttime", clip.startTimeIsSaved ? clip.savedStartTime : clip.getStartTime$());
control.setValue$S$O("readout", clip.readoutType);
control.setValue$S$Z("playallsteps", clip.playAllSteps);
});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
var hasVideo=control.getPropertyNames$().contains$O("video");
if (!hasVideo) {
return Clazz.new_($I$(1,1).c$$org_opensourcephysics_media_core_Video,[null]);
}$I$(2,"addSearchPath$S",[control.getString$S("basepath")]);
var child=control.getChildControl$S("video");
var path=child.getString$S("path");
var video=$I$(3).getVideo$S$org_opensourcephysics_media_core_VideoType(path, null);
var engineChange=false;
if (video == null  && path != null   && !$I$(3).isCanceled$() ) {
if ($I$(2).getResource$S(path) != null ) {
$I$(4).info$S("\"" + path + "\" could not be opened" );
var otherEngines=Clazz.new_($I$(5,1));
var engine=$I$(3).getEngine$();
var ext=$I$(6).getExtension$S(path);
if (!engine.equals$O("Xuggle")) {
var xuggleType=$I$(3).getVideoType$S$S("Xuggle", ext);
if (xuggleType != null ) otherEngines.add$O(xuggleType);
}if (otherEngines.isEmpty$()) {
$I$(7,"showMessageDialog$java_awt_Component$O$S$I",[null, $I$(8).getString$S("VideoIO.Dialog.BadVideo.Message") + "\n\n" + path , $I$(8).getString$S("VideoClip.Dialog.BadVideo.Title"), 2]);
} else {
var changePreferredEngine=Clazz.new_([$I$(8).getString$S("VideoIO.Dialog.TryDifferentEngine.Checkbox")],$I$(9,1).c$$S);
video=$I$(3).getVideo$S$java_util_ArrayList$javax_swing_JComponent$javax_swing_JFrame(path, otherEngines, changePreferredEngine, null);
engineChange=changePreferredEngine.isSelected$();
if (video != null  && changePreferredEngine.isSelected$() ) {
var typeName=video.getClass$().getSimpleName$();
var newEngine=typeName.indexOf$S("Xuggle") > -1 ? "Xuggle" : "none";
$I$(3).setEngine$S(newEngine);
}}} else {
var response=$I$(7,"showConfirmDialog$java_awt_Component$O$S$I$I",[null, "\"" + path + "\" " + $I$(8).getString$S("VideoClip.Dialog.VideoNotFound.Message") , $I$(8).getString$S("VideoClip.Dialog.VideoNotFound.Title"), 0, 2]);
if (response == 0) {
$I$(3).getChooser$().setAccessory$javax_swing_JComponent($I$(3).videoEnginePanel);
$I$(3).videoEnginePanel.reset$();
$I$(3).getChooser$().setSelectedFile$java_io_File(Clazz.new_($I$(10,1).c$$S,[path]));
var files=$I$(3).getChooserFiles$S("open video");
if (files != null  && files.length > 0 ) {
var selectedType=$I$(3).videoEnginePanel.getSelectedVideoType$();
path=$I$(6).getAbsolutePath$java_io_File(files[0]);
video=$I$(3).getVideo$S$org_opensourcephysics_media_core_VideoType(path, selectedType);
}}}}if (video != null ) {
var filters=child.getObject$S("filters");
if (filters != null ) {
video.getFilterStack$().clear$();
var it=filters.iterator$();
while (it.hasNext$()){
var filter=it.next$();
video.getFilterStack$().addFilter$org_opensourcephysics_media_core_Filter(filter);
}
}if (Clazz.instanceOf(video, "org.opensourcephysics.media.core.ImageVideo")) {
var dt=child.getDouble$S("delta_t");
if (!Double.isNaN$D(dt)) {
(video).setFrameDuration$D(dt);
}}}var clip=Clazz.new_($I$(1,1).c$$org_opensourcephysics_media_core_Video,[video]);
clip.changeEngine=engineChange;
if (path != null ) {
if (!path.startsWith$S("/") && path.indexOf$S(":") == -1 ) {
var base=control.getString$S("basepath");
path=$I$(6).getResolvedPath$S$S(path, base);
}clip.videoPath=path;
}return clip;
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var clip=obj;
var start=control.getInt$S("startframe");
var stepSize=control.getInt$S("stepsize");
var stepCount=control.getInt$S("stepcount");
var frameCount=clip.getFrameCount$();
if (control.getPropertyNames$().contains$O("video_framecount")) {
frameCount=control.getInt$S("video_framecount");
} else if (start != -2147483648 && stepSize != -2147483648  && stepCount != -2147483648 ) {
frameCount=start + stepCount * stepSize;
}clip.setStepCount$I(frameCount);
if (start != -2147483648) {
clip.setStartFrameNumber$I(start);
}if (stepSize != -2147483648) {
clip.setStepSize$I(stepSize);
}if (stepCount != -2147483648) {
clip.setStepCount$I(stepCount);
}var t=control.getDouble$S("starttime");
if (!Double.isNaN$D(t)) {
clip.startTime=t;
}clip.readoutType=control.getString$S("readout");
clip.playAllSteps=true;
if (control.getPropertyNames$().contains$O("playallsteps")) {
clip.playAllSteps=control.getBoolean$S("playallsteps");
}return obj;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-29 00:28:30 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
