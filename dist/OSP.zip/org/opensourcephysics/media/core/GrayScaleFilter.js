(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'org.opensourcephysics.media.core.MediaRes','java.awt.Toolkit','javax.swing.JLabel','org.opensourcephysics.media.core.DecimalField','javax.swing.AbstractAction','java.awt.GridBagLayout','javax.swing.JPanel','java.awt.GridBagConstraints','java.awt.Insets','javax.swing.JRadioButton','javax.swing.ButtonGroup','javax.swing.Box','java.awt.BorderLayout','java.awt.FlowLayout','org.opensourcephysics.media.core.GrayScaleFilter','org.opensourcephysics.media.core.NumberField',['org.opensourcephysics.media.core.GrayScaleFilter','.Inspector'],'javax.swing.JOptionPane','javax.swing.BorderFactory','java.awt.image.BufferedImage',['org.opensourcephysics.media.core.GrayScaleFilter','.Loader']]],$I$=function(i,n){return(i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i};
/*c*/var C$=Clazz.newClass(P$, "GrayScaleFilter", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.media.core.Filter');
C$.$classes$=[['Inspector',2],['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.colorLabels=Clazz.array($I$(3), [3]);
this.colorFields=Clazz.array($I$(16), [3]);
},1);

C$.$fields$=[['D',['redWt','greenWt','blueWt'],'O',['pixels','int[]','inspector','org.opensourcephysics.media.core.GrayScaleFilter.Inspector','vidButton','javax.swing.JRadioButton','+flatButton','+customButton','buttons','javax.swing.ButtonGroup','colorLabels','javax.swing.JLabel[]','colorFields','org.opensourcephysics.media.core.NumberField[]','typePanel','javax.swing.JComponent','+rgbPanel']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.setWeights$D$D$D(0.3, 0.59, 0.11);
this.hasInspector=true;
}, 1);

Clazz.newMeth(C$, 'getFilteredImage$java_awt_image_BufferedImage', function (sourceImage) {
if (!this.isEnabled$()) {
return sourceImage;
}if (sourceImage !== this.source ) {
p$1.initialize$java_awt_image_BufferedImage.apply(this, [sourceImage]);
}if (sourceImage !== this.input ) {
this.gIn.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.source, 0, 0, null);
}p$1.setOutputToGray.apply(this, []);
return this.output;
});

Clazz.newMeth(C$, 'getInspector$', function () {
var myInspector=this.inspector;
if (myInspector == null ) {
myInspector=Clazz.new_($I$(17,1),[this, null]);
}if (myInspector.isModal$() && this.vidPanel != null  ) {
this.frame=$I$(18).getFrameForComponent$java_awt_Component(this.vidPanel);
myInspector.setVisible$Z(false);
myInspector.dispose$();
myInspector=Clazz.new_($I$(17,1),[this, null]);
}this.inspector=myInspector;
this.inspector.initialize$();
return this.inspector;
});

Clazz.newMeth(C$, 'setWeights$D$D$D', function (r, g, b) {
this.redWt=r;
this.greenWt=g;
this.blueWt=b;
});

Clazz.newMeth(C$, 'refresh$', function () {
C$.superclazz.prototype.refresh$.apply(this, []);
if (this.inspector != null ) {
this.inspector.setTitle$S($I$(1).getString$S("Filter.GrayScale.Title"));
}this.typePanel.setBorder$javax_swing_border_Border((function(a,f){return f.apply(null,a)})([$I$(1).getString$S("Filter.GrayScale.Label.Type")],$I$(19).createTitledBorder$S));
this.rgbPanel.setBorder$javax_swing_border_Border((function(a,f){return f.apply(null,a)})([$I$(1).getString$S("Filter.GrayScale.Label.Weight")],$I$(19).createTitledBorder$S));
this.vidButton.setText$S($I$(1).getString$S("Filter.GrayScale.Button.Video"));
this.flatButton.setText$S($I$(1).getString$S("Filter.GrayScale.Button.Flat"));
this.customButton.setText$S($I$(1).getString$S("Filter.GrayScale.Button.Custom"));
this.colorLabels[0].setText$S($I$(1).getString$S("Filter.GrayScale.Label.Red"));
this.colorLabels[1].setText$S($I$(1).getString$S("Filter.GrayScale.Label.Green"));
this.colorLabels[2].setText$S($I$(1).getString$S("Filter.GrayScale.Label.Blue"));
this.vidButton.setEnabled$Z(this.isEnabled$());
this.flatButton.setEnabled$Z(this.isEnabled$());
this.customButton.setEnabled$Z(this.isEnabled$());
for (var i=0; i < 3; i++) {
this.colorFields[i].setEditable$Z(this.buttons.isSelected$javax_swing_ButtonModel(this.customButton.getModel$()));
this.colorFields[i].setEnabled$Z(this.isEnabled$());
this.colorLabels[i].setEnabled$Z(this.isEnabled$());
}
});

Clazz.newMeth(C$, 'initialize$java_awt_image_BufferedImage', function (image) {
this.source=image;
this.w=this.source.getWidth$();
this.h=this.source.getHeight$();
this.pixels=Clazz.array(Integer.TYPE, [this.w * this.h]);
this.output=Clazz.new_($I$(20,1).c$$I$I$I,[this.w, this.h, 1]);
if (this.source.getType$() == 1) {
this.input=this.source;
} else {
this.input=Clazz.new_($I$(20,1).c$$I$I$I,[this.w, this.h, 1]);
this.gIn=this.input.createGraphics$();
}}, p$1);

Clazz.newMeth(C$, 'setOutputToGray', function () {
this.input.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
var pixel;
var r;
var g;
var b;
var v;
for (var i=0; i < this.pixels.length; i++) {
pixel=this.pixels[i];
r=(pixel >> 16) & 255;
g=(pixel >> 8) & 255;
b=(pixel) & 255;
v=p$1.getGray$I$I$I.apply(this, [r, g, b]);
this.pixels[i]=(v << 16) | (v << 8) | v ;
}
this.output.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
}, p$1);

Clazz.newMeth(C$, 'getGray$I$I$I', function (r, g, b) {
var gray=(this.redWt * r + this.greenWt * g + this.blueWt * b) / (this.redWt + this.greenWt + this.blueWt );
return (gray|0);
}, p$1);

Clazz.newMeth(C$, 'setWeights$DA', function (weights) {
this.redWt=weights[0];
this.greenWt=weights[1];
this.blueWt=weights[2];
}, p$1);

Clazz.newMeth(C$, 'getWeights', function () {
return Clazz.array(Double.TYPE, -1, [this.redWt, this.greenWt, this.blueWt]);
}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(21,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.GrayScaleFilter, "Inspector", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$java_awt_Frame$Z.apply(this,[this.this$0.frame, !(Clazz.instanceOf(this.this$0.frame, "org.opensourcephysics.display.OSPFrame"))]);C$.$init$.apply(this);
this.setResizable$Z(false);
this.createGUI$();
this.setTitle$S($I$(1).getString$S("Filter.GrayScale.Title"));
this.this$0.refresh$.apply(this.this$0, []);
this.pack$();
var rect=this.getBounds$();
var dim=$I$(2).getDefaultToolkit$().getScreenSize$();
var x=((dim.width - rect.width)/2|0);
var y=((dim.height - rect.height)/2|0);
this.setLocation$I$I(x, y);
}, 1);

Clazz.newMeth(C$, 'createGUI$', function () {
for (var i=0; i < 3; i++) {
this.this$0.colorLabels[i]=Clazz.new_($I$(3,1));
this.this$0.colorFields[i]=Clazz.new_($I$(4,1).c$$I$I,[3, 2]);
this.this$0.colorFields[i].setMaxValue$D(1.0);
this.this$0.colorFields[i].setMinValue$D(0.0);
this.this$0.colorFields[i].addActionListener$java_awt_event_ActionListener(((P$.GrayScaleFilter$Inspector$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "GrayScaleFilter$Inspector$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.GrayScaleFilter.Inspector'].readFields$org_opensourcephysics_media_core_NumberField.apply(this.b$['org.opensourcephysics.media.core.GrayScaleFilter.Inspector'], [e.getSource$()]);
});
})()
), Clazz.new_($I$(5,1),[this, null],P$.GrayScaleFilter$Inspector$1)));
this.this$0.colorFields[i].addFocusListener$java_awt_event_FocusListener(((P$.GrayScaleFilter$Inspector$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "GrayScaleFilter$Inspector$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.FocusListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'focusGained$java_awt_event_FocusEvent', function (e) {
(e.getSource$()).selectAll$();
});

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.GrayScaleFilter.Inspector'].readFields$org_opensourcephysics_media_core_NumberField.apply(this.b$['org.opensourcephysics.media.core.GrayScaleFilter.Inspector'], [e.getSource$()]);
});
})()
), Clazz.new_(P$.GrayScaleFilter$Inspector$2.$init$,[this, null])));
}
var gridbag=Clazz.new_($I$(6,1));
this.this$0.rgbPanel=Clazz.new_($I$(7,1).c$$java_awt_LayoutManager,[gridbag]);
var c=Clazz.new_($I$(8,1));
c.anchor=13;
for (var i=0; i < 3; i++) {
c.gridy=i;
c.fill=0;
c.weightx=0.0;
c.gridx=0;
c.insets=Clazz.new_($I$(9,1).c$$I$I$I$I,[3, 20, 0, 3]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.colorLabels[i], c);
this.this$0.rgbPanel.add$java_awt_Component(this.this$0.colorLabels[i]);
c.fill=2;
c.gridx=1;
c.insets=Clazz.new_($I$(9,1).c$$I$I$I$I,[3, 0, 0, 5]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.colorFields[i], c);
this.this$0.rgbPanel.add$java_awt_Component(this.this$0.colorFields[i]);
}
this.this$0.vidButton=Clazz.new_($I$(10,1));
this.this$0.flatButton=Clazz.new_($I$(10,1));
this.this$0.customButton=Clazz.new_($I$(10,1));
this.this$0.buttons=Clazz.new_($I$(11,1));
this.this$0.buttons.add$javax_swing_AbstractButton(this.this$0.vidButton);
this.this$0.buttons.add$javax_swing_AbstractButton(this.this$0.flatButton);
this.this$0.buttons.add$javax_swing_AbstractButton(this.this$0.customButton);
var select=((P$.GrayScaleFilter$Inspector$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "GrayScaleFilter$Inspector$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.GrayScaleFilter'].buttons.isSelected$javax_swing_ButtonModel(this.b$['org.opensourcephysics.media.core.GrayScaleFilter'].vidButton.getModel$())) {
this.b$['org.opensourcephysics.media.core.GrayScaleFilter'].setWeights$D$D$D.apply(this.b$['org.opensourcephysics.media.core.GrayScaleFilter'], [0.3, 0.59, 0.11]);
} else if (this.b$['org.opensourcephysics.media.core.GrayScaleFilter'].buttons.isSelected$javax_swing_ButtonModel(this.b$['org.opensourcephysics.media.core.GrayScaleFilter'].flatButton.getModel$())) {
this.b$['org.opensourcephysics.media.core.GrayScaleFilter'].setWeights$D$D$D.apply(this.b$['org.opensourcephysics.media.core.GrayScaleFilter'], [0.3333333333333333, 0.3333333333333333, 0.3333333333333333]);
}this.b$['org.opensourcephysics.media.core.GrayScaleFilter'].refresh$.apply(this.b$['org.opensourcephysics.media.core.GrayScaleFilter'], []);
this.b$['org.opensourcephysics.media.core.GrayScaleFilter.Inspector'].updateDisplay$.apply(this.b$['org.opensourcephysics.media.core.GrayScaleFilter.Inspector'], []);
this.b$['org.opensourcephysics.media.core.GrayScaleFilter'].support.firePropertyChange$S$O$O("weight", null, null);
});
})()
), Clazz.new_(P$.GrayScaleFilter$Inspector$3.$init$,[this, null]));
this.this$0.vidButton.addActionListener$java_awt_event_ActionListener(select);
this.this$0.flatButton.addActionListener$java_awt_event_ActionListener(select);
this.this$0.customButton.addActionListener$java_awt_event_ActionListener(select);
this.this$0.typePanel=$I$(12).createVerticalBox$();
this.this$0.typePanel.add$java_awt_Component(this.this$0.vidButton);
this.this$0.typePanel.add$java_awt_Component(this.this$0.flatButton);
this.this$0.typePanel.add$java_awt_Component(this.this$0.customButton);
var contentPane=Clazz.new_([Clazz.new_($I$(13,1))],$I$(7,1).c$$java_awt_LayoutManager);
this.setContentPane$java_awt_Container(contentPane);
contentPane.add$java_awt_Component$O(this.this$0.typePanel, "West");
contentPane.add$java_awt_Component$O(this.this$0.rgbPanel, "East");
var buttonbar=Clazz.new_([Clazz.new_($I$(14,1))],$I$(7,1).c$$java_awt_LayoutManager);
buttonbar.add$java_awt_Component(this.this$0.ableButton);
buttonbar.add$java_awt_Component(this.this$0.closeButton);
contentPane.add$java_awt_Component$O(buttonbar, "South");
});

Clazz.newMeth(C$, 'readFields$org_opensourcephysics_media_core_NumberField', function (source) {
var rgb=Clazz.array(Double.TYPE, [3]);
for (var i=0; i < 3; i++) {
rgb[i]=this.this$0.colorFields[i].getValue$();
}
p$1.setWeights$DA.apply(this.this$0, [rgb]);
this.updateDisplay$();
this.this$0.support.firePropertyChange$S$O$O("weight", null, null);
source.selectAll$();
});

Clazz.newMeth(C$, 'initialize$', function () {
if ((this.this$0.redWt == 0.3 ) && (this.this$0.greenWt == 0.59 ) && (this.this$0.blueWt == 0.11 )  ) {
this.this$0.vidButton.setSelected$Z(true);
} else if ((this.this$0.redWt == 0.3333333333333333 ) && (this.this$0.greenWt == 0.3333333333333333 ) && (this.this$0.blueWt == 0.3333333333333333 )  ) {
this.this$0.flatButton.setSelected$Z(true);
} else {
this.this$0.customButton.setSelected$Z(true);
}this.this$0.refresh$.apply(this.this$0, []);
this.updateDisplay$();
});

Clazz.newMeth(C$, 'updateDisplay$', function () {
this.this$0.colorFields[0].setValue$D(this.this$0.redWt);
this.this$0.colorFields[1].setValue$D(this.this$0.greenWt);
this.this$0.colorFields[2].setValue$D(this.this$0.blueWt);
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.GrayScaleFilter, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
control.setValue$S$O("weights", p$1.getWeights.apply(filter, []));
if ((filter.frame != null ) && (filter.inspector != null ) && filter.inspector.isVisible$()  ) {
var x=filter.inspector.getLocation$().x - filter.frame.getLocation$().x;
var y=filter.inspector.getLocation$().y - filter.frame.getLocation$().y;
control.setValue$S$I("inspector_x", x);
control.setValue$S$I("inspector_y", y);
}});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(15,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
if (control.getPropertyNames$().contains$O("weights")) {
p$1.setWeights$DA.apply(filter, [control.getObject$S("weights")]);
}filter.inspectorX=control.getInt$S("inspector_x");
filter.inspectorY=control.getInt$S("inspector_y");
return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-20 00:04:10 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
