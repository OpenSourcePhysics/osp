(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'org.opensourcephysics.media.core.MediaRes','java.awt.Toolkit','javax.swing.JLabel','org.opensourcephysics.media.core.IntegerField','javax.swing.JPanel','java.awt.BorderLayout','java.awt.GridBagLayout','java.awt.GridBagConstraints','java.awt.Insets','java.awt.FlowLayout','org.opensourcephysics.media.core.ResizeFilter',['org.opensourcephysics.media.core.ResizeFilter','.Inspector'],'javax.swing.JOptionPane','java.awt.image.BufferedImage','java.awt.geom.AffineTransform',['org.opensourcephysics.media.core.ResizeFilter','.Loader']]],$I$=function(i,n){return(i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i};
/*c*/var C$=Clazz.newClass(P$, "ResizeFilter", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.media.core.Filter');
C$.$classes$=[['Inspector',2],['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.widthFactor=1.0;
this.heightFactor=1.0;
},1);

C$.$fields$=[['D',['widthFactor','heightFactor'],'O',['gOut','java.awt.Graphics2D','inspector','org.opensourcephysics.media.core.ResizeFilter.Inspector','widthLabel','javax.swing.JLabel','+heightLabel','+inputLabel','+outputLabel','widthInField','org.opensourcephysics.media.core.IntegerField','+heightInField','+widthOutField','+heightOutField']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.hasInspector=true;
}, 1);

Clazz.newMeth(C$, 'setWidthFactor$D', function (factor) {
this.source=null;
var prev= new Double(this.widthFactor);
this.widthFactor=Math.min(Math.abs(factor), 10);
this.widthFactor=Math.max(this.widthFactor, 0.01);
this.support.firePropertyChange$S$O$O("width", prev,  new Double(this.widthFactor));
});

Clazz.newMeth(C$, 'setHeightFactor$D', function (factor) {
this.source=null;
var prev= new Double(this.heightFactor);
this.heightFactor=Math.min(Math.abs(factor), 10);
this.heightFactor=Math.max(this.heightFactor, 0.01);
this.support.firePropertyChange$S$O$O("height", prev,  new Double(this.heightFactor));
});

Clazz.newMeth(C$, 'getWidthFactor$', function () {
return this.widthFactor;
});

Clazz.newMeth(C$, 'getHeightFactor$', function () {
return this.heightFactor;
});

Clazz.newMeth(C$, 'getFilteredImage$java_awt_image_BufferedImage', function (sourceImage) {
if (!this.isEnabled$()) {
return sourceImage;
}if (sourceImage !== this.source ) {
p$1.initialize$java_awt_image_BufferedImage.apply(this, [sourceImage]);
}if (sourceImage !== this.input ) {
this.gIn.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.source, 0, 0, null);
}this.gOut.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.input, 0, 0, null);
return this.output;
});

Clazz.newMeth(C$, 'getInspector$', function () {
var myInspector=this.inspector;
if (myInspector == null ) {
myInspector=Clazz.new_($I$(12,1),[this, null]);
}if (myInspector.isModal$() && this.vidPanel != null  ) {
this.frame=$I$(13).getFrameForComponent$java_awt_Component(this.vidPanel);
myInspector.setVisible$Z(false);
myInspector.dispose$();
myInspector=Clazz.new_($I$(12,1),[this, null]);
}this.inspector=myInspector;
this.inspector.initialize$();
return this.inspector;
});

Clazz.newMeth(C$, 'refresh$', function () {
C$.superclazz.prototype.refresh$.apply(this, []);
this.widthLabel.setText$S($I$(1).getString$S("Filter.Resize.Label.Width"));
this.heightLabel.setText$S($I$(1).getString$S("Filter.Resize.Label.Height"));
this.inputLabel.setText$S($I$(1).getString$S("Filter.Resize.Label.Input"));
this.outputLabel.setText$S($I$(1).getString$S("Filter.Resize.Label.Output"));
if (this.inspector != null ) {
this.inspector.setTitle$S($I$(1).getString$S("Filter.Resize.Title"));
this.inspector.pack$();
}var enabled=this.isEnabled$();
this.inputLabel.setEnabled$Z(enabled);
this.outputLabel.setEnabled$Z(enabled);
this.heightLabel.setEnabled$Z(enabled);
this.widthLabel.setEnabled$Z(enabled);
this.widthInField.setEnabled$Z(enabled);
this.heightInField.setEnabled$Z(enabled);
this.widthOutField.setEnabled$Z(enabled);
this.heightOutField.setEnabled$Z(enabled);
var wOut=((this.w * this.widthFactor)|0);
var hOut=((this.h * this.heightFactor)|0);
this.widthInField.setIntValue$I(this.w);
this.widthOutField.setIntValue$I(wOut);
this.heightInField.setIntValue$I(this.h);
this.heightOutField.setIntValue$I(hOut);
});

Clazz.newMeth(C$, 'initialize$java_awt_image_BufferedImage', function (sourceImage) {
this.source=sourceImage;
this.w=this.source.getWidth$();
this.h=this.source.getHeight$();
if ((this.w == 720) && (this.h == 480) && (this.widthFactor == 1.0 ) && (this.heightFactor == 1.0 )  ) {
this.widthFactor=0.889;
}var wOut=((this.w * this.widthFactor)|0);
var hOut=((this.h * this.heightFactor)|0);
if (this.source.getType$() == 1) {
this.input=this.source;
} else {
this.input=Clazz.new_($I$(14,1).c$$I$I$I,[this.w, this.h, 1]);
this.gIn=this.input.createGraphics$();
}this.output=Clazz.new_($I$(14,1).c$$I$I$I,[wOut, hOut, 1]);
var transform=$I$(15).getScaleInstance$D$D(this.widthFactor, this.heightFactor);
this.gOut=this.output.createGraphics$();
this.gOut.setTransform$java_awt_geom_AffineTransform(transform);
}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(16,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ResizeFilter, "Inspector", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$java_awt_Frame$Z.apply(this,[this.this$0.frame, !(Clazz.instanceOf(this.this$0.frame, "org.opensourcephysics.display.OSPFrame"))]);C$.$init$.apply(this);
this.setTitle$S($I$(1).getString$S("Filter.Resize.Title"));
this.setResizable$Z(false);
this.createGUI$();
this.this$0.refresh$.apply(this.this$0, []);
this.pack$();
var rect=this.getBounds$();
var dim=$I$(2).getDefaultToolkit$().getScreenSize$();
var x=((dim.width - rect.width)/2|0);
var y=((dim.height - rect.height)/2|0);
this.setLocation$I$I(x, y);
}, 1);

Clazz.newMeth(C$, 'createGUI$', function () {
this.this$0.inputLabel=Clazz.new_($I$(3,1));
this.this$0.outputLabel=Clazz.new_($I$(3,1));
this.this$0.widthLabel=Clazz.new_($I$(3,1));
this.this$0.widthInField=Clazz.new_($I$(4,1).c$$I,[4]);
this.this$0.widthInField.setEditable$Z(false);
this.this$0.widthInField.format.applyPattern$S("0");
this.this$0.widthOutField=Clazz.new_($I$(4,1).c$$I,[4]);
this.this$0.widthOutField.format.applyPattern$S("0");
this.this$0.widthOutField.addActionListener$java_awt_event_ActionListener(((P$.ResizeFilter$Inspector$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "ResizeFilter$Inspector$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.ResizeFilter'].setWidthFactor$D.apply(this.b$['org.opensourcephysics.media.core.ResizeFilter'], [1.0 * this.b$['org.opensourcephysics.media.core.ResizeFilter'].widthOutField.getIntValue$() / this.b$['org.opensourcephysics.media.core.ResizeFilter'].w]);
this.b$['org.opensourcephysics.media.core.ResizeFilter'].refresh$.apply(this.b$['org.opensourcephysics.media.core.ResizeFilter'], []);
this.b$['org.opensourcephysics.media.core.ResizeFilter'].widthOutField.selectAll$();
});
})()
), Clazz.new_(P$.ResizeFilter$Inspector$1.$init$,[this, null])));
this.this$0.widthOutField.addFocusListener$java_awt_event_FocusListener(((P$.ResizeFilter$Inspector$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "ResizeFilter$Inspector$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.FocusListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'focusGained$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.ResizeFilter'].widthOutField.selectAll$();
});

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.ResizeFilter'].setWidthFactor$D.apply(this.b$['org.opensourcephysics.media.core.ResizeFilter'], [1.0 * this.b$['org.opensourcephysics.media.core.ResizeFilter'].widthOutField.getIntValue$() / this.b$['org.opensourcephysics.media.core.ResizeFilter'].w]);
this.b$['org.opensourcephysics.media.core.ResizeFilter'].refresh$.apply(this.b$['org.opensourcephysics.media.core.ResizeFilter'], []);
});
})()
), Clazz.new_(P$.ResizeFilter$Inspector$2.$init$,[this, null])));
this.this$0.heightLabel=Clazz.new_($I$(3,1));
this.this$0.heightInField=Clazz.new_($I$(4,1).c$$I,[4]);
this.this$0.heightInField.setEditable$Z(false);
this.this$0.heightInField.format.applyPattern$S("0");
this.this$0.heightOutField=Clazz.new_($I$(4,1).c$$I,[4]);
this.this$0.heightOutField.format.applyPattern$S("0");
this.this$0.heightOutField.addActionListener$java_awt_event_ActionListener(((P$.ResizeFilter$Inspector$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "ResizeFilter$Inspector$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.ResizeFilter'].setHeightFactor$D.apply(this.b$['org.opensourcephysics.media.core.ResizeFilter'], [1.0 * this.b$['org.opensourcephysics.media.core.ResizeFilter'].heightOutField.getIntValue$() / this.b$['org.opensourcephysics.media.core.ResizeFilter'].h]);
this.b$['org.opensourcephysics.media.core.ResizeFilter'].refresh$.apply(this.b$['org.opensourcephysics.media.core.ResizeFilter'], []);
this.b$['org.opensourcephysics.media.core.ResizeFilter'].heightOutField.selectAll$();
});
})()
), Clazz.new_(P$.ResizeFilter$Inspector$3.$init$,[this, null])));
this.this$0.heightOutField.addFocusListener$java_awt_event_FocusListener(((P$.ResizeFilter$Inspector$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "ResizeFilter$Inspector$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.FocusListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'focusGained$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.ResizeFilter'].heightOutField.selectAll$();
});

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.ResizeFilter'].setHeightFactor$D.apply(this.b$['org.opensourcephysics.media.core.ResizeFilter'], [1.0 * this.b$['org.opensourcephysics.media.core.ResizeFilter'].heightOutField.getIntValue$() / this.b$['org.opensourcephysics.media.core.ResizeFilter'].h]);
this.b$['org.opensourcephysics.media.core.ResizeFilter'].refresh$.apply(this.b$['org.opensourcephysics.media.core.ResizeFilter'], []);
});
})()
), Clazz.new_(P$.ResizeFilter$Inspector$4.$init$,[this, null])));
var contentPane=Clazz.new_([Clazz.new_($I$(6,1))],$I$(5,1).c$$java_awt_LayoutManager);
this.setContentPane$java_awt_Container(contentPane);
var gridbag=Clazz.new_($I$(7,1));
var panel=Clazz.new_($I$(5,1).c$$java_awt_LayoutManager,[gridbag]);
contentPane.add$java_awt_Component$O(panel, "Center");
var c=Clazz.new_($I$(8,1));
c.anchor=10;
c.fill=0;
c.weightx=0.5;
c.gridx=1;
c.gridy=0;
c.insets=Clazz.new_($I$(9,1).c$$I$I$I$I,[4, 2, 0, 2]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.widthLabel, c);
panel.add$java_awt_Component(this.this$0.widthLabel);
c.gridx=2;
c.insets=Clazz.new_($I$(9,1).c$$I$I$I$I,[4, 0, 0, 8]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.heightLabel, c);
panel.add$java_awt_Component(this.this$0.heightLabel);
c.gridx=0;
c.gridy=1;
c.anchor=13;
c.insets=Clazz.new_($I$(9,1).c$$I$I$I$I,[0, 4, 0, 2]);
c.weightx=0.2;
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.inputLabel, c);
panel.add$java_awt_Component(this.this$0.inputLabel);
c.gridy=2;
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.outputLabel, c);
panel.add$java_awt_Component(this.this$0.outputLabel);
c.gridy=1;
c.gridx=1;
c.anchor=10;
c.insets=Clazz.new_($I$(9,1).c$$I$I$I$I,[4, 2, 0, 2]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.widthInField, c);
panel.add$java_awt_Component(this.this$0.widthInField);
c.gridx=2;
c.insets=Clazz.new_($I$(9,1).c$$I$I$I$I,[4, 0, 0, 8]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.heightInField, c);
panel.add$java_awt_Component(this.this$0.heightInField);
c.gridy=2;
c.gridx=1;
c.insets=Clazz.new_($I$(9,1).c$$I$I$I$I,[4, 2, 0, 2]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.widthOutField, c);
panel.add$java_awt_Component(this.this$0.widthOutField);
c.gridx=2;
c.insets=Clazz.new_($I$(9,1).c$$I$I$I$I,[4, 0, 0, 8]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.heightOutField, c);
panel.add$java_awt_Component(this.this$0.heightOutField);
var buttonbar=Clazz.new_([Clazz.new_($I$(10,1))],$I$(5,1).c$$java_awt_LayoutManager);
buttonbar.add$java_awt_Component(this.this$0.ableButton);
buttonbar.add$java_awt_Component(this.this$0.closeButton);
contentPane.add$java_awt_Component$O(buttonbar, "South");
});

Clazz.newMeth(C$, 'initialize$', function () {
this.this$0.refresh$.apply(this.this$0, []);
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.ResizeFilter, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
control.setValue$S$D("width_factor", filter.widthFactor);
control.setValue$S$D("height_factor", filter.heightFactor);
if ((filter.frame != null ) && (filter.inspector != null ) && filter.inspector.isVisible$()  ) {
var x=filter.inspector.getLocation$().x - filter.frame.getLocation$().x;
var y=filter.inspector.getLocation$().y - filter.frame.getLocation$().y;
control.setValue$S$I("inspector_x", x);
control.setValue$S$I("inspector_y", y);
}});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(11,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
if (control.getPropertyNames$().contains$O("width_factor")) {
filter.setWidthFactor$D(control.getDouble$S("width_factor"));
}if (control.getPropertyNames$().contains$O("height_factor")) {
filter.setHeightFactor$D(control.getDouble$S("height_factor"));
}filter.inspectorX=control.getInt$S("inspector_x");
filter.inspectorY=control.getInt$S("inspector_y");
return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-20 00:04:10 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
