(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'org.opensourcephysics.media.core.MediaRes','java.awt.Toolkit','javax.swing.JButton','javax.swing.JPanel','java.awt.FlowLayout','org.opensourcephysics.media.core.BaselineFilter','org.opensourcephysics.tools.ResourceLoader','javax.swing.JOptionPane','javax.swing.JFileChooser','java.io.File','org.opensourcephysics.display.OSPRuntime','org.opensourcephysics.tools.FontSizer',['org.opensourcephysics.media.core.BaselineFilter','.Inspector'],'java.awt.image.BufferedImage',['org.opensourcephysics.media.core.BaselineFilter','.Loader']]],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BaselineFilter", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.media.core.Filter');
C$.$classes$=[['Inspector',2],['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['imagePath'],'O',['baseline','java.awt.image.BufferedImage','pixels','int[]','+baselinePixels','inspector','org.opensourcephysics.media.core.BaselineFilter.Inspector','chooser','javax.swing.JFileChooser','loadButton','javax.swing.JButton','+captureButton']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.hasInspector=true;
}, 1);

Clazz.newMeth(C$, 'capture$', function () {
if ((this.vidPanel == null ) || (this.vidPanel.getVideo$() == null ) ) {
return;
}this.setBaselineImage$java_awt_image_BufferedImage(this.vidPanel.getVideo$().getImage$());
});

Clazz.newMeth(C$, 'load$S', function (path) {
var image=$I$(7).getBufferedImage$S(path);
if (image != null ) {
this.imagePath=path;
this.setBaselineImage$java_awt_image_BufferedImage(image);
} else {
$I$(8,"showMessageDialog$java_awt_Component$O$S$I",[this.vidPanel, "\"" + path + "\" " + $I$(1).getString$S("Filter.Baseline.Dialog.NotImage.Message") , $I$(1).getString$S("Filter.Baseline.Dialog.NotImage.Title"), 1]);
}});

Clazz.newMeth(C$, 'load$', function () {
if (this.chooser == null ) {
this.chooser=Clazz.new_([Clazz.new_([$I$(11).chooserDir],$I$(10,1).c$$S)],$I$(9,1).c$$java_io_File);
}this.chooser.setDialogTitle$S("Open");
$I$(12,"setFonts$O$I",[this.chooser, $I$(12).getLevel$()]);
var result=this.chooser.showOpenDialog$java_awt_Component(null);
if (result == 0) {
var file=this.chooser.getSelectedFile$();
this.load$S(file.getAbsolutePath$());
}});

Clazz.newMeth(C$, 'setBaselineImage$java_awt_image_BufferedImage', function (image) {
this.baseline=image;
if (image != null ) {
var wi=image.getWidth$();
var ht=image.getHeight$();
if ((wi >= this.w) && (ht >= this.h) ) {
image.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.baselinePixels);
} else {
$I$(8,"showMessageDialog$java_awt_Component$O$S$I",[this.vidPanel, $I$(1).getString$S("Filter.Baseline.Dialog.SmallImage.Message1") + " (" + wi + "x" + ht + ") " + $I$(1).getString$S("Filter.Baseline.Dialog.SmallImage.Message2") + " (" + this.w + "x" + this.h + ")." , $I$(1).getString$S("Filter.Baseline.Dialog.SmallImage.Title"), 1]);
}}this.support.firePropertyChange$S$O$O("baseline", null, null);
});

Clazz.newMeth(C$, 'getBaselineImage$', function () {
return this.baseline;
});

Clazz.newMeth(C$, 'getFilteredImage$java_awt_image_BufferedImage', function (sourceImage) {
if (!this.isEnabled$()) {
return sourceImage;
}if (sourceImage !== this.source ) {
p$1.initialize$java_awt_image_BufferedImage.apply(this, [sourceImage]);
}if (sourceImage !== this.input ) {
this.gIn.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.source, 0, 0, null);
}p$1.subtractBaseline.apply(this, []);
return this.output;
});

Clazz.newMeth(C$, 'getInspector$', function () {
var myInspector=this.inspector;
if (myInspector == null ) {
myInspector=Clazz.new_($I$(13,1),[this, null]);
}if (myInspector.isModal$() && this.vidPanel != null  ) {
this.frame=$I$(8).getFrameForComponent$java_awt_Component(this.vidPanel);
myInspector.setVisible$Z(false);
myInspector.dispose$();
myInspector=Clazz.new_($I$(13,1),[this, null]);
}this.inspector=myInspector;
this.inspector.initialize$();
return this.inspector;
});

Clazz.newMeth(C$, 'clear$', function () {
this.setBaselineImage$java_awt_image_BufferedImage(null);
});

Clazz.newMeth(C$, 'refresh$', function () {
C$.superclazz.prototype.refresh$.apply(this, []);
this.loadButton.setText$S($I$(1).getString$S("Filter.Baseline.Button.Load"));
this.captureButton.setText$S($I$(1).getString$S("Filter.Baseline.Button.Capture"));
this.captureButton.setText$S($I$(1).getString$S("Filter.Baseline.Button.Capture"));
if (this.inspector != null ) {
this.inspector.setTitle$S($I$(1).getString$S("Filter.Baseline.Title"));
this.inspector.pack$();
}this.loadButton.setEnabled$Z(this.isEnabled$());
this.captureButton.setEnabled$Z(this.isEnabled$());
});

Clazz.newMeth(C$, 'initialize$java_awt_image_BufferedImage', function (image) {
this.source=image;
this.w=this.source.getWidth$();
this.h=this.source.getHeight$();
this.pixels=Clazz.array(Integer.TYPE, [this.w * this.h]);
this.baselinePixels=Clazz.array(Integer.TYPE, [this.w * this.h]);
this.output=Clazz.new_($I$(14,1).c$$I$I$I,[this.w, this.h, 1]);
if (this.source.getType$() == 1) {
this.input=this.source;
} else {
this.input=Clazz.new_($I$(14,1).c$$I$I$I,[this.w, this.h, 1]);
this.gIn=this.input.createGraphics$();
}}, p$1);

Clazz.newMeth(C$, 'subtractBaseline', function () {
var pixels=(this.input.getRaster$().getDataBuffer$()).getData$();
this.input.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.w, this.h, pixels);
if (this.baseline != null ) {
var pixel;
var base;
var r;
var g;
var b;
for (var i=0; i < pixels.length; i++) {
pixel=pixels[i];
base=this.baselinePixels[i];
r=(pixel >> 16) & 255;
r=r - ((base >> 16) & 255);
r=Math.max(r, 0);
g=(pixel >> 8) & 255;
g=g - ((base >> 8) & 255);
g=Math.max(g, 0);
b=pixel & 255;
b=b - (base & 255);
b=Math.max(b, 0);
pixels[i]=(r << 16) | (g << 8) | b ;
}
}}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(15,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.BaselineFilter, "Inspector", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$java_awt_Frame$Z.apply(this,[this.this$0.frame, !(Clazz.instanceOf(this.this$0.frame, "org.opensourcephysics.display.OSPFrame"))]);C$.$init$.apply(this);
this.setTitle$S($I$(1).getString$S("Filter.Baseline.Title"));
this.setResizable$Z(false);
this.createGUI$();
this.this$0.refresh$.apply(this.this$0, []);
this.pack$();
var rect=this.getBounds$();
var dim=$I$(2).getDefaultToolkit$().getScreenSize$();
var x=((dim.width - rect.width)/2|0);
var y=((dim.height - rect.height)/2|0);
this.setLocation$I$I(x, y);
}, 1);

Clazz.newMeth(C$, 'createGUI$', function () {
this.this$0.loadButton=Clazz.new_($I$(3,1));
this.this$0.loadButton.addActionListener$java_awt_event_ActionListener(((P$.BaselineFilter$Inspector$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "BaselineFilter$Inspector$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.BaselineFilter'].load$.apply(this.b$['org.opensourcephysics.media.core.BaselineFilter'], []);
});
})()
), Clazz.new_(P$.BaselineFilter$Inspector$1.$init$,[this, null])));
this.this$0.captureButton=Clazz.new_($I$(3,1));
this.this$0.captureButton.addActionListener$java_awt_event_ActionListener(((P$.BaselineFilter$Inspector$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "BaselineFilter$Inspector$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.BaselineFilter'].capture$.apply(this.b$['org.opensourcephysics.media.core.BaselineFilter'], []);
});
})()
), Clazz.new_(P$.BaselineFilter$Inspector$2.$init$,[this, null])));
var buttonbar=Clazz.new_([Clazz.new_($I$(5,1))],$I$(4,1).c$$java_awt_LayoutManager);
this.setContentPane$java_awt_Container(buttonbar);
buttonbar.add$java_awt_Component(this.this$0.ableButton);
buttonbar.add$java_awt_Component(this.this$0.loadButton);
buttonbar.add$java_awt_Component(this.this$0.captureButton);
buttonbar.add$java_awt_Component(this.this$0.clearButton);
buttonbar.add$java_awt_Component(this.this$0.closeButton);
});

Clazz.newMeth(C$, 'initialize$', function () {
this.this$0.refresh$.apply(this.this$0, []);
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.BaselineFilter, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
if (filter.imagePath != null ) {
control.setValue$S$O("imagepath", filter.imagePath);
}if ((filter.frame != null ) && (filter.inspector != null ) && filter.inspector.isVisible$()  ) {
var x=filter.inspector.getLocation$().x - filter.frame.getLocation$().x;
var y=filter.inspector.getLocation$().y - filter.frame.getLocation$().y;
control.setValue$S$I("inspector_x", x);
control.setValue$S$I("inspector_y", y);
}});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(6,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
if (control.getPropertyNames$().contains$O("imagepath")) {
filter.load$S(control.getString$S("imagepath"));
}filter.inspectorX=control.getInt$S("inspector_x");
filter.inspectorY=control.getInt$S("inspector_y");
return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-25 12:09:26 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
