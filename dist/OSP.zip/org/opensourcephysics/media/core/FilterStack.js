(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'java.util.ArrayList']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FilterStack", null, 'org.opensourcephysics.media.core.Filter', 'java.beans.PropertyChangeListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.filters=Clazz.new_($I$(1,1));
this.indexRemoved=-1;
},1);

C$.$fields$=[['I',['indexRemoved'],'O',['filters','java.util.ArrayList','postFilter','org.opensourcephysics.media.core.Filter']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'addFilter$org_opensourcephysics_media_core_Filter', function (filter) {
this.filters.add$O(filter);
filter.stack=this;
filter.removePropertyChangeListener$java_beans_PropertyChangeListener(this);
filter.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
this.support.firePropertyChange$S$O$O("image", null, null);
this.support.firePropertyChange$S$O$O("filter", null, filter);
});

Clazz.newMeth(C$, 'insertFilter$org_opensourcephysics_media_core_Filter$I', function (filter, index) {
index=Math.min(index, this.filters.size$());
index=Math.max(index, 0);
this.filters.add$I$O(index, filter);
filter.stack=this;
filter.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
this.support.firePropertyChange$S$O$O("image", null, null);
this.support.firePropertyChange$S$O$O("filter", null, filter);
});

Clazz.newMeth(C$, 'lastIndexRemoved$', function () {
return this.indexRemoved;
});

Clazz.newMeth(C$, 'setPostFilter$org_opensourcephysics_media_core_Filter', function (filter) {
if (this.postFilter != null ) {
this.postFilter.removePropertyChangeListener$java_beans_PropertyChangeListener(this);
}this.postFilter=filter;
if (filter != null ) {
filter.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
this.support.firePropertyChange$S$O$O("image", null, null);
this.support.firePropertyChange$S$O$O("filter", null, filter);
}});

Clazz.newMeth(C$, 'getPostFilter$', function () {
return this.postFilter;
});

Clazz.newMeth(C$, 'getFilter$Class', function (filterClass) {
var it=this.filters.iterator$();
while (it.hasNext$()){
var filter=it.next$();
if (filter.getClass$() === filterClass ) {
return filter;
}}
return null;
});

Clazz.newMeth(C$, 'removeFilter$org_opensourcephysics_media_core_Filter', function (filter) {
this.indexRemoved=this.filters.indexOf$O(filter);
if (this.indexRemoved > -1) {
this.filters.remove$O(filter);
filter.dispose$();
this.support.firePropertyChange$S$O$O("image", null, null);
this.support.firePropertyChange$S$O$O("filter", filter, null);
}System.gc$();
});

Clazz.newMeth(C$, 'clear$', function () {
for (var filter, $filter = this.filters.iterator$(); $filter.hasNext$()&&((filter=($filter.next$())),1);) {
filter.dispose$();
}
this.filters.clear$();
this.support.firePropertyChange$S$O$O("image", null, null);
this.support.firePropertyChange$S$O$O("filter", null, null);
System.gc$();
});

Clazz.newMeth(C$, 'isEmpty$', function () {
return this.filters.isEmpty$() && (this.postFilter == null ) ;
});

Clazz.newMeth(C$, 'getFilters$', function () {
return Clazz.new_($I$(1,1).c$$java_util_Collection,[this.filters]);
});

Clazz.newMeth(C$, 'getFilteredImage$java_awt_image_BufferedImage', function (image) {
if (!this.isEnabled$()) {
return image;
}var it=this.filters.iterator$();
while (it.hasNext$()){
var filter=it.next$();
image=filter.getFilteredImage$java_awt_image_BufferedImage(image);
}
if (this.postFilter != null ) {
image=this.postFilter.getFilteredImage$java_awt_image_BufferedImage(image);
}return image;
});

Clazz.newMeth(C$, 'getInspector$', function () {
return null;
});

Clazz.newMeth(C$, 'setInspectorsVisible$Z', function (vis) {
var filters=this.getFilters$();
var it=filters.iterator$();
while (it.hasNext$()){
var filter=it.next$();
var inspector=filter.getInspector$();
if (inspector != null ) {
if (!vis) {
filter.inspectorVisible=inspector.isVisible$();
inspector.setVisible$Z(false);
} else if (!inspector.isModal$()) {
inspector.setVisible$Z(filter.inspectorVisible);
}}}
});

Clazz.newMeth(C$, 'refresh$', function () {
var it=this.getFilters$().iterator$();
while (it.hasNext$()){
it.next$().refresh$();
}
});

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
if (e.getPropertyName$().equals$O("filterChanged")) {
this.support.firePropertyChange$S$O$O("filterChanged", e.getOldValue$(), e.getNewValue$());
} else {
this.support.firePropertyChange$S$O$O("image", null, null);
}});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-26 22:52:37 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
