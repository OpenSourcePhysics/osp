(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),I$=[[0,'java.awt.Color','java.util.logging.Level','org.opensourcephysics.controls.ConsoleLevel','java.util.logging.LogRecord','org.opensourcephysics.display.OSPRuntime','org.opensourcephysics.js.JSUtil','java.io.PrintStream','org.opensourcephysics.controls.LoggerOutputStream','org.opensourcephysics.controls.MessageFrame','org.opensourcephysics.controls.OSPLog','java.awt.EventQueue','java.io.BufferedWriter','java.io.FileWriter','javax.swing.JOptionPane','org.opensourcephysics.controls.ControlsRes','org.opensourcephysics.controls.XML','javax.swing.JPanel','java.awt.BorderLayout','java.awt.Dimension','java.awt.RenderingHints','javax.swing.JTextPane','javax.swing.JScrollPane','javax.swing.text.StyleContext','javax.swing.text.StyleConstants','org.opensourcephysics.tools.FontSizer','java.awt.event.MouseAdapter','java.util.logging.Logger','org.opensourcephysics.controls.OSPLogHandler','org.opensourcephysics.controls.ConsoleFormatter','java.util.logging.FileHandler','java.util.logging.XMLFormatter','javax.swing.JPopupMenu','javax.swing.JMenu','javax.swing.ButtonGroup','javax.swing.JRadioButtonMenuItem','javax.swing.AbstractAction','javax.swing.JMenuBar','javax.swing.JCheckBoxMenuItem','javax.swing.JFileChooser','java.io.File','java.io.BufferedReader','java.io.FileReader','StringBuffer','Throwable','java.io.StringWriter','java.io.PrintWriter','org.opensourcephysics.controls.XMLControlElement']],$I$=function(i,n){return(i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i};
/*c*/var C$=Clazz.newClass(P$, "OSPLogFormatter", null, 'java.util.logging.Formatter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.control=Clazz.new_($I$(47,1));
},1);

C$.$fields$=[['O',['control','org.opensourcephysics.controls.XMLControl']]]

Clazz.newMeth(C$, 'format$java_util_logging_LogRecord', function (record) {
this.control.saveObject$O(record);
return this.control.toXML$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-20 00:04:03 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
