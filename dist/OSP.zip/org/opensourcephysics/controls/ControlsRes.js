(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),I$=[[0,'java.util.Locale','org.opensourcephysics.display.OSPRuntime','java.util.ResourceBundle','org.opensourcephysics.js.JSUtil']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ControlsRes");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['S',['ANIMATION_NEW','ANIMATION_INIT','ANIMATION_STEP','ANIMATION_RESET','ANIMATION_START','ANIMATION_STOP','ANIMATION_RESET_TIP','ANIMATION_INIT_TIP','ANIMATION_START_TIP','ANIMATION_STOP_TIP','ANIMATION_NEW_TIP','ANIMATION_STEP_TIP','CALCULATION_CALC','CALCULATION_RESET','CALCULATION_CALC_TIP','CALCULATION_RESET_TIP','XML_NAME','XML_VALUE'],'O',['res','java.util.ResourceBundle']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getString$java_util_ResourceBundle$S', function (bundle, key) {
try {
return bundle.getString$S(key);
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.util.MissingResourceException")){
return '|' + key + '|' ;
} else {
throw ex;
}
}
}, 1);

Clazz.newMeth(C$, 'setLocale$java_util_Locale', function (locale) {
if ($I$(4).isJS) return;
C$.res=$I$(3).getBundle$S$java_util_Locale("org.opensourcephysics.resources.controls.controls_res", locale);
C$.setLocalStrings$();
}, 1);

Clazz.newMeth(C$, 'getString$S', function (key) {
try {
return C$.res.getString$S(key);
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.util.MissingResourceException")){
return "!" + key + "!" ;
} else {
throw ex;
}
}
}, 1);

Clazz.newMeth(C$, 'setLocalStrings$', function () {
C$.ANIMATION_NEW=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_NEW");
C$.ANIMATION_INIT=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_INIT");
C$.ANIMATION_STEP=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_STEP");
C$.ANIMATION_RESET=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_RESET");
C$.ANIMATION_START=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_START");
C$.ANIMATION_STOP=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_STOP");
C$.ANIMATION_RESET_TIP=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_RESET_TIP");
C$.ANIMATION_INIT_TIP=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_INIT_TIP");
C$.ANIMATION_START_TIP=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_START_TIP");
C$.ANIMATION_STOP_TIP=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_STOP_TIP");
C$.ANIMATION_NEW_TIP=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_NEW_TIP");
C$.ANIMATION_STEP_TIP=C$.getString$java_util_ResourceBundle$S(C$.res, "ANIMATION_STEP_TIP");
C$.CALCULATION_CALC=C$.getString$java_util_ResourceBundle$S(C$.res, "CALCULATION_CALC");
C$.CALCULATION_RESET=C$.getString$java_util_ResourceBundle$S(C$.res, "CALCULATION_RESET");
C$.CALCULATION_CALC_TIP=C$.getString$java_util_ResourceBundle$S(C$.res, "CALCULATION_CALC_TIP");
C$.CALCULATION_RESET_TIP=C$.getString$java_util_ResourceBundle$S(C$.res, "CALCULATION_RESET_TIP");
C$.XML_NAME=C$.getString$java_util_ResourceBundle$S(C$.res, "XML_NAME");
C$.XML_VALUE=C$.getString$java_util_ResourceBundle$S(C$.res, "XML_VALUE");
}, 1);

C$.$static$=function(){C$.$static$=0;
{
var language=$I$(1).getDefault$().getLanguage$();
var resourceLocale=$I$(1).ENGLISH;
for (var locale, $locale = 0, $$locale = $I$(2).getInstalledLocales$(); $locale<$$locale.length&&((locale=($$locale[$locale])),1);$locale++) {
if (locale.getLanguage$().equals$O(language)) {
resourceLocale=locale;
break;
}}
C$.res=$I$(3).getBundle$S$java_util_Locale("org.opensourcephysics.resources.controls.controls_res", resourceLocale);
C$.setLocalStrings$();
};
};
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:19 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
