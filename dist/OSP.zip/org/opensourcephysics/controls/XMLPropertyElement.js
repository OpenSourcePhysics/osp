(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),I$=[[0,'java.util.ArrayList','org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XMLControlElement','java.lang.reflect.Array','org.opensourcephysics.controls.XMLControl','StringBuffer']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XMLPropertyElement", null, null, 'org.opensourcephysics.controls.XMLProperty');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.content=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['Z',['writeNullFinalElement'],'S',['name','type','className'],'O',['parent','org.opensourcephysics.controls.XMLProperty','content','java.util.List']]
,['Z',['defaultWriteNullFinalArrayElements']]]

Clazz.newMeth(C$, 'c$$org_opensourcephysics_controls_XMLProperty', function (mother) {
;C$.$init$.apply(this);
this.parent=mother;
}, 1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_controls_XMLProperty$S$S$O', function (mother, propertyName, propertyType, value) {
C$.c$$org_opensourcephysics_controls_XMLProperty$S$S$O$Z.apply(this, [mother, propertyName, propertyType, value, C$.defaultWriteNullFinalArrayElements]);
}, 1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_controls_XMLProperty$S$S$O$Z', function (mother, propertyName, propertyType, value, writeNullFinalArrayElement) {
C$.c$$org_opensourcephysics_controls_XMLProperty.apply(this, [mother]);
this.name=propertyName;
this.type=propertyType;
this.writeNullFinalElement=writeNullFinalArrayElement;
if (this.type.equals$O("string")) {
if ($I$(2).requiresCDATA$S(value)) {
this.content.add$O("<![CDATA[" + value + "]]>" );
} else {
this.content.add$O(value.toString());
}} else if ("intdoubleboolean".indexOf$S(this.type) != -1) {
this.content.add$O(value.toString());
} else if (this.type.equals$O("object")) {
if (value == null ) {
this.content.add$O("null");
} else {
this.className=value.getClass$().getName$();
var control=Clazz.new_($I$(3,1).c$$org_opensourcephysics_controls_XMLProperty,[this]);
control.saveObject$O(value);
this.content.add$O(control);
}} else if (this.type.equals$O("collection")) {
this.className=value.getClass$().getName$();
var it=(value).iterator$();
while (it.hasNext$()){
var next=it.next$();
var type=$I$(2).getDataType$O(next);
if (type == null ) {
continue;
}this.content.add$O(Clazz.new_(C$.c$$org_opensourcephysics_controls_XMLProperty$S$S$O$Z,[this, "item", type, next, this.writeNullFinalElement]));
}
} else if (this.type.equals$O("array")) {
this.className=value.getClass$().getName$();
var baseType=value.getClass$().getComponentType$();
var array=value;
var count=$I$(4).getLength$O(array);
while ((count > 0) && (baseType.getComponentType$() != null ) ){
baseType=baseType.getComponentType$();
array=$I$(4).get$O$I(array, 0);
if (array == null ) {
break;
}count=count * $I$(4).getLength$O(array);
}
var primitive="intdoubleboolean".indexOf$S(baseType.getName$()) != -1;
if (primitive && (count > $I$(3).compactArraySize) ) {
var s=this.getArrayString$O(value);
this.content.add$O(Clazz.new_(C$.c$$org_opensourcephysics_controls_XMLProperty$S$S$O$Z,[this, "array", "string", s, this.writeNullFinalElement]));
} else {
var length=$I$(4).getLength$O(value);
var last=this.writeNullFinalElement ? length - 1 : length;
for (var j=0; j < length; j++) {
var next=$I$(4).get$O$I(value, j);
var type=$I$(2).getDataType$O(next);
if (type == null ) {
if (j < last) continue;
type="object";
}this.content.add$O(Clazz.new_(C$.c$$org_opensourcephysics_controls_XMLProperty$S$S$O$Z,[this, "[" + j + "]" , type, next, this.writeNullFinalElement]));
}
}}}, 1);

Clazz.newMeth(C$, 'getPropertyName$', function () {
return this.name;
});

Clazz.newMeth(C$, 'getPropertyType$', function () {
return this.type;
});

Clazz.newMeth(C$, 'getPropertyClass$', function () {
if (this.type.equals$O("int")) {
return Integer.TYPE;
} else if (this.type.equals$O("double")) {
return Double.TYPE;
} else if (this.type.equals$O("boolean")) {
return Boolean.TYPE;
} else if (this.type.equals$O("string")) {
return Clazz.getClass(String);
}try {
return Clazz.forName(this.className);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
return null;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'getParentProperty$', function () {
return this.parent;
});

Clazz.newMeth(C$, 'getLevel$', function () {
return this.parent.getLevel$() + 1;
});

Clazz.newMeth(C$, 'getPropertyContent$', function () {
return this.content;
});

Clazz.newMeth(C$, 'getChildControl$S', function (name) {
var children=this.getChildControls$();
for (var i=0; i < children.length; i++) {
if (children[i].getPropertyName$().equals$O(name)) {
return children[i];
}}
return null;
});

Clazz.newMeth(C$, 'getChildControls$', function () {
if (this.type.equals$O("object") && !this.getPropertyContent$().isEmpty$() ) {
var child=this.getPropertyContent$().get$I(0);
return Clazz.array($I$(5), -1, [child]);
} else if ("arraycollection".indexOf$S(this.type) != -1) {
var list=Clazz.new_($I$(1,1));
var it=this.getPropertyContent$().iterator$();
while (it.hasNext$()){
var prop=it.next$();
if (prop.getPropertyType$().equals$O("object") && !prop.getPropertyContent$().isEmpty$() ) {
list.add$O(prop.getPropertyContent$().get$I(0));
}}
return list.toArray$OA(Clazz.array($I$(5), [0]));
}return Clazz.array($I$(5), [0]);
});

Clazz.newMeth(C$, 'setValue$S', function (stringValue) {
var valid=true;
try {
if (this.type.equals$O("int")) {
Integer.parseInt$S(stringValue);
} else if (this.type.equals$O("double")) {
Double.parseDouble$S(stringValue);
} else if (this.type.equals$O("boolean")) {
stringValue=stringValue.equals$O("true") ? "true" : "false";
} else if ("objectarraycollection".indexOf$S(this.type) != -1) {
valid=false;
} else if (this.type.equals$O("string") && $I$(2).requiresCDATA$S(stringValue) ) {
stringValue="<![CDATA[" + stringValue + "]]>" ;
}} catch (ex) {
if (Clazz.exceptionOf(ex,"NumberFormatException")){
valid=false;
} else {
throw ex;
}
}
if (valid) {
this.content.clear$();
this.content.add$O(stringValue);
}});

Clazz.newMeth(C$, 'toString', function () {
var xml=Clazz.new_([$I$(2).NEW_LINE + this.indent$I(this.getLevel$()) + "<property name=\"" + this.name + "\" type=\"" + this.type + "\"" ],$I$(6,1).c$$S);
if ("arraycollection".indexOf$S(this.type) != -1) {
xml.append$S(" class=\"" + this.className + "\"" );
}var content=this.getPropertyContent$();
if (content.isEmpty$() && "object".equals$O(this.type) ) {
content.add$O("null");
}if (content.isEmpty$()) {
xml.append$S("/>");
return xml.toString();
}xml.append$S(">");
var hasChildren=false;
var it=content.iterator$();
while (it.hasNext$()){
var next=it.next$();
hasChildren=hasChildren || (Clazz.instanceOf(next, "org.opensourcephysics.controls.XMLProperty")) ;
xml.append$O(next);
}
if (hasChildren) {
xml.append$S($I$(2).NEW_LINE + this.indent$I(this.getLevel$()));
}xml.append$S("</property>");
return xml.toString();
});

Clazz.newMeth(C$, 'indent$I', function (level) {
var space="";
for (var i=0; i < 4 * level; i++) {
space += " ";
}
return space;
});

Clazz.newMeth(C$, 'getArrayString$O', function (array) {
var sb=Clazz.new_($I$(6,1).c$$S,["{"]);
var length=$I$(4).getLength$O(array);
for (var j=0; j < length; j++) {
if (j > 0) {
sb.append$C(",");
}var element=$I$(4).get$O$I(array, j);
if ((element != null ) && element.getClass$().isArray$() ) {
sb.append$S(this.getArrayString$O(element));
} else {
sb.append$O(element);
}}
sb.append$C("}");
return sb.toString();
});

C$.$static$=function(){C$.$static$=0;
C$.defaultWriteNullFinalArrayElements=true;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-05 21:20:25 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
