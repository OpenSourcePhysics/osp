(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),p$1={},I$=[[0,'java.util.HashMap','java.util.ArrayList','java.nio.file.Files','java.nio.file.Paths','org.opensourcephysics.controls.XMLPropertyElement','org.opensourcephysics.controls.XML','org.opensourcephysics.controls.OSPCombo','org.opensourcephysics.controls.Cryptic','org.opensourcephysics.controls.OSPLog','org.opensourcephysics.tools.ResourceLoader','java.io.BufferedReader','java.io.StringReader','java.io.File','javax.swing.JOptionPane','org.opensourcephysics.controls.ControlsRes','java.io.FileOutputStream','java.nio.charset.Charset','java.io.OutputStreamWriter','java.io.FileWriter','java.io.BufferedWriter','org.opensourcephysics.controls.XMLControl','StringBuffer','org.opensourcephysics.controls.XMLTreeChooser','org.opensourcephysics.controls.XMLTree','org.opensourcephysics.controls.ListChooser','org.opensourcephysics.controls.Password','java.lang.reflect.Array','Boolean']],$I$=function(i,n){return(i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i};
/*c*/var C$=Clazz.newClass(P$, "XMLControlElement", null, null, 'org.opensourcephysics.controls.XMLControl');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.className="java.lang.Object";
this.theClass=null;
this.counts=Clazz.new_($I$(1,1));
this.propNames=Clazz.new_($I$(2,1));
this.props=Clazz.new_($I$(2,1));
this.valid=false;
this.readFailed=false;
this.doctype="osp10.dtd";
this.decryptPolicy=0;
},1);

C$.$fields$=[['Z',['canWrite','valid','readFailed'],'I',['level','decryptPolicy'],'S',['className','name','version','doctype','basepath','password'],'O',['theClass','Class','counts','java.util.Map','object','java.lang.Object','parent','org.opensourcephysics.controls.XMLProperty','propNames','java.util.ArrayList','+props','input','java.io.BufferedReader','output','java.io.BufferedWriter']]
,['I',['compactArraySize'],'S',['encoding']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$Class', function (type) {
C$.c$.apply(this, []);
this.setObjectClass$Class(type);
}, 1);

Clazz.newMeth(C$, 'c$$O', function (obj) {
C$.c$.apply(this, []);
this.setObjectClass$Class(obj.getClass$());
this.saveObject$O(obj);
}, 1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_controls_XMLProperty', function (parent) {
C$.c$.apply(this, []);
this.parent=parent;
this.level=parent.getLevel$();
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File', function (xmlFile) {
C$.c$.apply(this, []);
p$1.readData$S.apply(this, [p$1.getFileData$java_io_File.apply(this, [xmlFile])]);
}, 1);

Clazz.newMeth(C$, 'getFileData$java_io_File', function (xmlFile) {
try {
return  String.instantialize((function(a,f){return f.apply(null,a)})([(function(a,f){return f.apply(null,a)})([xmlFile.toURI$()],$I$(4).get$java_net_URI)],$I$(3).readAllBytes$java_nio_file_Path), "UTF-8");
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
return "";
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'c$$S', function (input) {
C$.c$.apply(this, []);
p$1.readData$S.apply(this, [input]);
}, 1);

Clazz.newMeth(C$, 'readData$S', function (input) {
if (input.startsWith$S("<?xml")) {
this.readXML$S(input);
} else {
this.read$S(input);
}}, p$1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_controls_XMLControl', function (control) {
C$.c$.apply(this, []);
this.readXML$S(control.toXML$());
}, 1);

Clazz.newMeth(C$, 'setLockValues$Z', function (lock) {
});

Clazz.newMeth(C$, 'setValue$S$Z', function (name, value) {
if (name == null ) {
return;
}p$1.setXMLProperty$S$S$O$Z.apply(this, [name, "boolean", String.valueOf$Z(value), false]);
});

Clazz.newMeth(C$, 'setValue$S$D', function (name, value) {
if (name == null ) {
return;
}p$1.setXMLProperty$S$S$O$Z.apply(this, [name, "double", String.valueOf$D(value), false]);
});

Clazz.newMeth(C$, 'setValue$S$I', function (name, value) {
if (name == null ) {
return;
}p$1.setXMLProperty$S$S$O$Z.apply(this, [name, "int", String.valueOf$I(value), false]);
});

Clazz.newMeth(C$, 'setValue$S$O', function (name, obj) {
this.setValue$S$O$Z(name, obj, $I$(5).defaultWriteNullFinalArrayElements);
});

Clazz.newMeth(C$, 'setValue$S$O$Z', function (name, obj, writeNullFinalElement) {
if (name == null ) {
return;
}if (obj == null ) {
var it=this.props.iterator$();
while (it.hasNext$()){
var prop=it.next$();
if (name.equals$O(prop.getPropertyName$())) {
it.remove$();
this.propNames.remove$O(name);
break;
}}
return;
}if (Clazz.instanceOf(obj, "java.lang.Boolean")) {
this.setValue$S$Z(name, (obj).booleanValue$());
return;
}var type=$I$(6).getDataType$O(obj);
if (type != null ) {
if (type.equals$O("int") || type.equals$O("double") ) {
obj=obj.toString();
}p$1.setXMLProperty$S$S$O$Z.apply(this, [name, type, obj, writeNullFinalElement]);
}});

Clazz.newMeth(C$, 'getBoolean$S', function (name) {
var prop=p$1.getXMLProperty$S.apply(this, [name]);
if (prop != null  && prop.getPropertyType$().equals$O("boolean") ) {
return "true".equals$O(prop.getPropertyContent$().get$I(0));
} else if (prop != null  && prop.getPropertyType$().equals$O("string") ) {
return "true".equals$O(prop.getPropertyContent$().get$I(0));
}return false;
});

Clazz.newMeth(C$, 'getDouble$S', function (name) {
var prop=p$1.getXMLProperty$S.apply(this, [name]);
if ((prop != null ) && (prop.getPropertyType$().equals$O("double") || prop.getPropertyType$().equals$O("int") || prop.getPropertyType$().equals$O("string")  ) ) {
try {
return Double.parseDouble$S(prop.getPropertyContent$().get$I(0));
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
return NaN;
} else {
throw ex;
}
}
}return NaN;
});

Clazz.newMeth(C$, 'getInt$S', function (name) {
var prop=p$1.getXMLProperty$S.apply(this, [name]);
if ((prop != null ) && (prop.getPropertyType$().equals$O("int") || prop.getPropertyType$().equals$O("string") ) ) {
try {
return Integer.parseInt$S(prop.getPropertyContent$().get$I(0));
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
return -2147483648;
} else {
throw ex;
}
}
} else if ((prop != null ) && prop.getPropertyType$().equals$O("object") ) {
var control=prop.getPropertyContent$().get$I(0);
if (control.getObjectClass$() === Clazz.getClass($I$(7)) ) {
var combo=control.loadObject$O(null);
return combo.getSelectedIndex$();
}}return -2147483648;
});

Clazz.newMeth(C$, 'getString$S', function (name) {
var prop=p$1.getXMLProperty$S.apply(this, [name]);
if ((prop != null ) && prop.getPropertyType$().equals$O("string") ) {
var content=prop.getPropertyContent$().get$I(0);
if (content.indexOf$S("<![CDATA[") != -1) {
content=content.substring$I$I(content.indexOf$S("<![CDATA[") + "<![CDATA[".length$(), content.indexOf$S("]]>"));
}return content;
} else if (name.equals$O("basepath") && (this.getRootControl$() != null ) ) {
return this.getRootControl$().basepath;
} else if ((prop != null ) && prop.getPropertyType$().equals$O("object") ) {
var control=prop.getPropertyContent$().get$I(0);
if (control.getObjectClass$() === Clazz.getClass($I$(7)) ) {
var combo=control.loadObject$O(null);
return combo.toString();
}}return null;
});

Clazz.newMeth(C$, 'getObject$S', function (name) {
var prop=p$1.getXMLProperty$S.apply(this, [name]);
if (prop != null ) {
var type=prop.getPropertyType$();
if (type.equals$O("object")) {
return p$1.objectValue$org_opensourcephysics_controls_XMLProperty.apply(this, [prop]);
} else if (type.equals$O("array")) {
return p$1.arrayValue$org_opensourcephysics_controls_XMLProperty.apply(this, [prop]);
} else if (type.equals$O("collection")) {
return p$1.collectionValue$org_opensourcephysics_controls_XMLProperty.apply(this, [prop]);
} else if (type.equals$O("int")) {
return  new Integer(p$1.intValue$org_opensourcephysics_controls_XMLProperty.apply(this, [prop]));
} else if (type.equals$O("double")) {
return  new Double(p$1.doubleValue$org_opensourcephysics_controls_XMLProperty.apply(this, [prop]));
} else if (type.equals$O("boolean")) {
return  Boolean.from(p$1.booleanValue$org_opensourcephysics_controls_XMLProperty.apply(this, [prop]));
} else if (type.equals$O("string")) {
return p$1.stringValue$org_opensourcephysics_controls_XMLProperty.apply(this, [prop]);
}}return null;
});

Clazz.newMeth(C$, 'getPropertyNames$', function () {
{
return Clazz.new_($I$(2,1).c$$java_util_Collection,[this.propNames]);
}});

Clazz.newMeth(C$, 'getPropertyType$S', function (name) {
var prop=p$1.getXMLProperty$S.apply(this, [name]);
if (prop != null ) {
return prop.getPropertyType$();
}return null;
});

Clazz.newMeth(C$, 'setPassword$S', function (pass) {
this.password=pass;
if (this.getObjectClass$() !== Clazz.getClass($I$(8)) ) {
this.setValue$S$O("xml_password", pass);
}});

Clazz.newMeth(C$, 'getPassword$', function () {
if (this.password == null ) {
this.password=this.getString$S("xml_password");
}return this.password;
});

Clazz.newMeth(C$, 'setDecryptPolicy$I', function (policy) {
if (policy == 5) {
this.decryptPolicy=5;
} else if (policy == 3) {
this.decryptPolicy=3;
} else {
this.decryptPolicy=0;
}});

Clazz.newMeth(C$, 'read$S', function (name) {
$I$(9).finest$S("reading " + name);
var res=$I$(10).getResource$S(name);
if (res != null ) {
this.read$java_io_Reader(res.openReader$());
var path=$I$(6).getDirectoryPath$S(name);
if (!path.equals$O("")) {
$I$(10).addSearchPath$S(path);
this.basepath=path;
} else {
this.basepath=(function(a,f){return f.apply(null,a)})([res.getAbsolutePath$()],$I$(6).getDirectoryPath$S);
}var file=res.getFile$();
this.canWrite=((file != null ) && file.canWrite$() );
return res.getAbsolutePath$();
}this.readFailed=true;
return null;
});

Clazz.newMeth(C$, 'readXML$S', function (xml) {
this.input=Clazz.new_([Clazz.new_($I$(12,1).c$$S,[xml])],$I$(11,1).c$$java_io_Reader);
p$1.readInput.apply(this, []);
if (!this.failedToRead$()) {
this.canWrite=false;
}});

Clazz.newMeth(C$, 'read$java_io_Reader', function ($in) {
if (Clazz.instanceOf($in, "java.io.BufferedReader")) {
this.input=$in;
} else {
this.input=Clazz.new_($I$(11,1).c$$java_io_Reader,[$in]);
}p$1.readInput.apply(this, []);
try {
this.input.close$();
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
ex.printStackTrace$();
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'readForClass$S$Class', function (name, type) {
var res=$I$(10).getResource$S(name);
if (res == null ) {
return null;
}this.input=Clazz.new_([res.openReader$()],$I$(11,1).c$$java_io_Reader);
if (!p$1.isInputForClass$Class.apply(this, [type])) {
return null;
}return this.read$S(name);
});

Clazz.newMeth(C$, 'readXMLForClass$S$Class', function (xml, type) {
this.input=Clazz.new_([Clazz.new_($I$(12,1).c$$S,[xml])],$I$(11,1).c$$java_io_Reader);
if (!p$1.isInputForClass$Class.apply(this, [type])) {
return false;
}this.readXML$S(xml);
return !this.readFailed;
});

Clazz.newMeth(C$, 'failedToRead$', function () {
return this.readFailed;
});

Clazz.newMeth(C$, 'write$S', function (fileName) {
this.canWrite=true;
var n=fileName.lastIndexOf$S("/");
if (n < 0) {
n=fileName.lastIndexOf$S("\\");
}if (n > 0) {
var dir=fileName.substring$I$I(0, n + 1);
var file=Clazz.new_($I$(13,1).c$$S,[dir]);
if (!file.exists$() && !file.mkdirs$() ) {
this.canWrite=false;
return null;
}}try {
var file=Clazz.new_($I$(13,1).c$$S,[fileName]);
if (file.exists$() && !file.canWrite$() ) {
(function(a,f){return f.apply(null,a)})([null, $I$(15).getString$S("Dialog.ReadOnly.Message") + ": " + file.getPath$() , $I$(15).getString$S("Dialog.ReadOnly.Title"), -1],$I$(14).showMessageDialog$java_awt_Component$O$S$I);
this.canWrite=false;
return null;
}var stream=Clazz.new_($I$(16,1).c$$java_io_File,[file]);
var charset=$I$(17).forName$S(C$.encoding);
this.write$java_io_Writer(Clazz.new_($I$(18,1).c$$java_io_OutputStream$java_nio_charset_Charset,[stream, charset]));
if (file.exists$()) {
var path=(function(a,f){return f.apply(null,a)})([file.getCanonicalPath$()],$I$(6).getDirectoryPath$S);
$I$(10).addSearchPath$S(path);
}if (this.isValid$()) {
if (fileName.indexOf$S("/") != -1) {
fileName=fileName.substring$I$I(0, fileName.lastIndexOf$S("/") + 1) + this.getDoctype$();
} else if (fileName.indexOf$S("\\") != -1) {
fileName=fileName.substring$I$I(0, fileName.lastIndexOf$S("\\") + 1) + this.getDoctype$();
} else {
fileName=this.doctype;
}this.writeDocType$java_io_Writer(Clazz.new_($I$(19,1).c$$S,[fileName]));
}if (true ||file.exists$()) {
return $I$(6).getAbsolutePath$java_io_File(file);
}} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
this.canWrite=false;
(function(a,f){return f.apply(null,a)})([ex.getMessage$()],$I$(9).warning$S);
} else {
throw ex;
}
}
return null;
});

Clazz.newMeth(C$, 'write$java_io_Writer', function (out) {
try {
this.output=Clazz.new_($I$(20,1).c$$java_io_Writer,[out]);
var xml=this.toXML$();
if (this.getPassword$() != null ) {
var cryptic=Clazz.new_($I$(8,1).c$$S,[xml]);
var control=Clazz.new_(C$.c$$O,[cryptic]);
xml=control.toXML$();
}this.output.write$S(xml);
this.output.flush$();
this.output.close$();
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
(function(a,f){return f.apply(null,a)})([ex.getMessage$()],$I$(9).info$S);
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'writeDocType$java_io_Writer', function (out) {
try {
this.output=Clazz.new_($I$(20,1).c$$java_io_Writer,[out]);
this.output.write$S((function(a,f){return f.apply(null,a)})([this.getDoctype$()],$I$(6).getDTD$S));
this.output.flush$();
this.output.close$();
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
(function(a,f){return f.apply(null,a)})([ex.getMessage$()],$I$(9).info$S);
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'toXML$', function () {
return this.toString();
});

Clazz.newMeth(C$, 'setValid$Z', function (valid) {
this.valid=valid;
});

Clazz.newMeth(C$, 'isValid$', function () {
return this.valid && ((function(a,f){return f.apply(null,a)})([this.getDoctype$()],$I$(6).getDTD$S) != null ) ;
});

Clazz.newMeth(C$, 'setVersion$S', function (vers) {
this.version=vers;
});

Clazz.newMeth(C$, 'getVersion$', function () {
return this.version;
});

Clazz.newMeth(C$, 'setDoctype$S', function (name) {
if ($I$(6).getDTD$S(name) != null ) {
}});

Clazz.newMeth(C$, 'getDoctype$', function () {
return this.doctype;
});

Clazz.newMeth(C$, 'setObjectClass$Class', function (type) {
if ((this.object != null ) && !type.isInstance$O(this.object) ) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,[this.object + " " + $I$(15).getString$S("XMLControlElement.Exception.NotInstanceOf") + " " + type ]);
}this.className=type.getName$();
this.theClass=type;
});

Clazz.newMeth(C$, 'getObjectClass$', function () {
if (this.className == null ) {
return null;
}if ((this.theClass != null ) && this.theClass.getName$().equals$O(this.className) ) {
return this.theClass;
}this.theClass=null;
try {
this.theClass=Clazz.forName(this.className);
} catch (ex) {
if (Clazz.exceptionOf(ex,"ClassNotFoundException")){
} else {
throw ex;
}
}
var loader=$I$(6).getClassLoader$();
if ((loader != null ) && (this.theClass == null ) ) {
try {
this.theClass=loader.loadClass$S(this.className);
} catch (ex) {
if (Clazz.exceptionOf(ex,"ClassNotFoundException")){
} else {
throw ex;
}
}
}return this.theClass;
});

Clazz.newMeth(C$, 'getObjectClassName$', function () {
return this.className;
});

Clazz.newMeth(C$, 'saveObject$O', function (obj) {
if (obj == null ) {
obj=this.object;
}var type=this.getObjectClass$();
if ((type == null ) || type.equals$O(Clazz.getClass(java.lang.Object)) ) {
if (obj == null ) {
return;
}type=obj.getClass$();
}if (type.isInstance$O(obj)) {
this.object=obj;
this.className=obj.getClass$().getName$();
this.clearValues$();
var loader=$I$(6).getLoader$Class(type);
loader.saveObject$org_opensourcephysics_controls_XMLControl$O(this, obj);
}});

Clazz.newMeth(C$, 'loadObject$O', function (obj) {
return this.loadObject$O$Z$Z(obj, false, false);
});

Clazz.newMeth(C$, 'loadObject$O$Z', function (obj, autoImport) {
return this.loadObject$O$Z$Z(obj, autoImport, false);
});

Clazz.newMeth(C$, 'loadObject$O$Z$Z', function (obj, autoImport, importAll) {
var type=this.getObjectClass$();
if (type == null ) {
if (obj != null ) {
if (!autoImport) {
var result=(function(a,f){return f.apply(null,a)})([null, $I$(15).getString$S("XMLControlElement.Dialog.UnknownClass.Message") + " \"" + this.className + "\"" + $I$(6).NEW_LINE + $I$(15).getString$S("XMLControlElement.Dialog.MismatchedClass.Query") + " \"" + obj.getClass$().getName$() + "\"" , $I$(15).getString$S("XMLControlElement.Dialog.MismatchedClass.Title"), 0, 3],$I$(14).showConfirmDialog$java_awt_Component$O$S$I$I);
if (result != 0) {
return obj;
}}if (!p$1.importInto$O$Z.apply(this, [obj, importAll])) {
return obj;
}type=obj.getClass$();
} else {
return null;
}}try {
if (obj != null  && $I$(6).getLoader$Class(type).getClass$() === (function(a,f){return f.apply(null,a)})([obj.getClass$()],$I$(6).getLoader$Class).getClass$()  ) {
autoImport=true;
importAll=true;
}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
if ((obj != null ) && !type.isInstance$O(obj) ) {
if (!autoImport) {
var result=(function(a,f){return f.apply(null,a)})([null, $I$(15).getString$S("XMLControlElement.Dialog.MismatchedClass.Message") + " \"" + type.getName$() + "\"" + $I$(6).NEW_LINE + $I$(15).getString$S("XMLControlElement.Dialog.MismatchedClass.Query") + " \"" + obj.getClass$().getName$() + "\"" , $I$(15).getString$S("XMLControlElement.Dialog.MismatchedClass.Title"), 0, 2],$I$(14).showConfirmDialog$java_awt_Component$O$S$I$I);
if (result != 0) {
return obj;
}}if (!p$1.importInto$O$Z.apply(this, [obj, importAll])) {
return obj;
}type=obj.getClass$();
}var loader=$I$(6).getLoader$Class(type);
if (obj == null ) {
if (this.object == null ) {
this.object=loader.createObject$org_opensourcephysics_controls_XMLControl(this);
}obj=this.object;
}if (obj == null ) {
return null;
}if (type.isInstance$O(obj)) {
obj=loader.loadObject$org_opensourcephysics_controls_XMLControl$O(this, obj);
this.object=obj;
}return obj;
});

Clazz.newMeth(C$, 'clearValues$', function () {
this.props.clear$();
this.propNames.clear$();
});

Clazz.newMeth(C$, 'println$S', function (s) {
System.out.println$S(s);
});

Clazz.newMeth(C$, 'println$', function () {
System.out.println$();
});

Clazz.newMeth(C$, 'print$S', function (s) {
System.out.print$S(s);
});

Clazz.newMeth(C$, 'clearMessages$', function () {
});

Clazz.newMeth(C$, 'calculationDone$S', function (s) {
});

Clazz.newMeth(C$, 'getPropertyName$', function () {
var parent=this.getParentProperty$();
if (this.className == null ) {
if (parent == null ) {
return "null";
}return parent.getPropertyName$();
} else if (p$1.isArrayOrCollectionItem.apply(this, [])) {
if (this.name == null ) {
var myName=this.getString$S("name");
if (myName != null  && !"".equals$O(myName) ) {
this.name=this.className.substring$I(this.className.lastIndexOf$S(".") + 1);
this.name += " \"" + myName + "\"" ;
} else {
var root=this;
while (root.getParentProperty$() != null ){
root=root.getParentProperty$();
}
if (Clazz.instanceOf(root, "org.opensourcephysics.controls.XMLControlElement")) {
var rootControl=root;
this.name=this.className.substring$I(this.className.lastIndexOf$S(".") + 1);
this.name=rootControl.addNumbering$S(this.name);
}}}return "" + this.name;
} else if (parent != null ) {
return parent.getPropertyName$();
} else {
return this.className.substring$I(this.className.lastIndexOf$S(".") + 1);
}});

Clazz.newMeth(C$, 'getPropertyType$', function () {
return "object";
});

Clazz.newMeth(C$, 'getPropertyClass$', function () {
return this.getObjectClass$();
});

Clazz.newMeth(C$, 'getParentProperty$', function () {
return this.parent;
});

Clazz.newMeth(C$, 'getLevel$', function () {
return this.level;
});

Clazz.newMeth(C$, 'getPropertyContent$', function () {
return Clazz.new_($I$(2,1).c$$java_util_Collection,[this.props]);
});

Clazz.newMeth(C$, 'getChildControl$S', function (name) {
var children=this.getChildControls$();
for (var i=0; i < children.length; i++) {
if (children[i].getPropertyName$().equals$O(name)) {
return children[i];
}}
return null;
});

Clazz.newMeth(C$, 'getChildControls$', function () {
var list=Clazz.new_($I$(2,1));
var it=this.props.iterator$();
while (it.hasNext$()){
var prop=it.next$();
if (prop.getPropertyType$().equals$O("object")) {
list.add$O(prop.getPropertyContent$().get$I(0));
}}
return list.toArray$OA(Clazz.array($I$(21), [0]));
});

Clazz.newMeth(C$, 'getRootControl$', function () {
if (this.parent == null ) {
return this;
}var prop=this.parent;
while (prop.getParentProperty$() != null ){
prop=prop.getParentProperty$();
}
if (Clazz.instanceOf(prop, "org.opensourcephysics.controls.XMLControlElement")) {
return prop;
}return null;
});

Clazz.newMeth(C$, 'addNumbering$S', function (name) {
var count=this.counts.get$O(name);
if (count == null ) {
count= new Integer(0);
}count= new Integer(count.intValue$() + 1);
this.counts.put$O$O(name, count);
return name + " " + count.toString() ;
});

Clazz.newMeth(C$, 'setValue$S', function (stringValue) {
});

Clazz.newMeth(C$, 'toString', function () {
var xml=Clazz.new_($I$(22,1).c$$S,[""]);
if (this.getLevel$() == 0) {
xml.append$S("<?xml version=\"1.0\" encoding=\"" + C$.encoding + "\"?>" );
if (this.isValid$()) {
xml.append$S($I$(6).NEW_LINE + "<!DOCTYPE object SYSTEM \"" + this.doctype + "\">" );
}}xml.append$S($I$(6).NEW_LINE + p$1.indent$I.apply(this, [this.getLevel$()]) + "<object class=\"" + this.className + "\"" );
if ((this.version != null ) && (this.getLevel$() == 0) ) {
xml.append$S(" version=\"" + this.version + "\"" );
}if (this.props.isEmpty$()) {
xml.append$S("/>");
} else {
xml.append$S(">");
var it=this.props.iterator$();
while (it.hasNext$()){
xml.append$S(it.next$().toString());
}
xml.append$S($I$(6).NEW_LINE + p$1.indent$I.apply(this, [this.getLevel$()]) + "</object>" );
}return xml.toString();
});

Clazz.newMeth(C$, 'getObjects$Class', function (type) {
return this.getObjects$Class$Z(type, false);
});

Clazz.newMeth(C$, 'getObjects$Class$Z', function (type, useChooser) {
var props;
if (useChooser) {

alert("XMLControlElement.getObjects with chooser called -- not configured to be asynchronous");
var name=type.getName$();
name=name.substring$I(name.lastIndexOf$S(".") + 1);
var chooser=Clazz.new_([$I$(15).getString$S("XMLControlElement.Chooser.SelectObjectsOfClass.Title"), $I$(15).getString$S("XMLControlElement.Chooser.SelectObjectsOfClass.Label") + " " + name , null],$I$(23,1).c$$S$S$java_awt_Component);
props=chooser.choose$org_opensourcephysics_controls_XMLControl$Class(this, type);
} else {
var tree=Clazz.new_($I$(24,1).c$$org_opensourcephysics_controls_XMLControl,[this]);
tree.setHighlightedClass$Class(type);
tree.selectHighlightedProperties$();
props=tree.getSelectedProperties$();
}var objects=Clazz.new_($I$(2,1));
var it=props.iterator$();
while (it.hasNext$()){
var prop=it.next$();
objects.add$O(type.cast$O(prop.loadObject$O(null)));
}
return objects;
});

Clazz.newMeth(C$, 'clone$', function () {
return Clazz.new_(C$.c$$org_opensourcephysics_controls_XMLControl,[this]);
});

Clazz.newMeth(C$, 'isArrayOrCollectionItem', function () {
var parent=this.getParentProperty$();
if (parent != null ) {
parent=parent.getParentProperty$();
return ((parent != null ) && ("arraycollection".indexOf$S(parent.getPropertyType$()) >= 0) );
}return false;
}, p$1);

Clazz.newMeth(C$, 'importInto$O$Z', function (obj, importAll) {
var control=Clazz.new_(C$.c$$O,[obj]);
var list=control.getPropertyNames$();
list.retainAll$java_util_Collection(this.getPropertyNames$());
var names=Clazz.new_($I$(2,1));
var values=Clazz.new_($I$(2,1));
for (var it=this.props.iterator$(); it.hasNext$(); ) {
var prop=it.next$();
var propName=prop.getPropertyName$();
if (!list.contains$O(propName)) {
continue;
}names.add$O(propName);
if (prop.getPropertyType$().equals$O("object")) {
values.add$O(prop.getPropertyClass$().getSimpleName$());
} else {
values.add$O(prop.getPropertyContent$().get$I(0));
}}
var chooser=Clazz.new_([$I$(15).getString$S("XMLControlElement.Chooser.ImportObjects.Title"), $I$(15).getString$S("XMLControlElement.Chooser.ImportObjects.Label")],$I$(25,1).c$$S$S);
if (names.isEmpty$() || importAll || chooser.choose$java_util_Collection$java_util_Collection$java_util_Collection(names, names, values)  ) {
var it=this.props.iterator$();
while (it.hasNext$()){
var prop=it.next$();
if (!names.contains$O(prop.getPropertyName$())) {
it.remove$();
this.propNames.remove$O(prop.getPropertyName$());
}}
var it2=control.getPropertyNames$().iterator$();
while (it2.hasNext$()){
var name=it2.next$();
if (names.contains$O(name)) {
continue;
}var propType=control.getPropertyType$S(name);
if (propType.equals$O("int")) {
this.setValue$S$I(name, control.getInt$S(name));
} else if (propType.equals$O("double")) {
this.setValue$S$D(name, control.getDouble$S(name));
} else if (propType.equals$O("boolean")) {
this.setValue$S$Z(name, control.getBoolean$S(name));
} else if (propType.equals$O("string")) {
this.setValue$S$O(name, control.getString$S(name));
} else {
this.setValue$S$O(name, control.getObject$S(name));
}}
return true;
}return false;
}, p$1);

Clazz.newMeth(C$, 'setXMLProperty$S$S$O$Z', function (name, type, value, writeNullFinalArrayElement) {
var i=-1;
if (this.propNames.contains$O(name)) {
var it=this.props.iterator$();
while (it.hasNext$()){
i++;
var prop=it.next$();
if (prop.getPropertyName$().equals$O(name)) {
it.remove$();
break;
}}
} else {
this.propNames.add$O(name);
}if (i > -1) {
this.props.add$I$O(i, Clazz.new_($I$(5,1).c$$org_opensourcephysics_controls_XMLProperty$S$S$O$Z,[this, name, type, value, writeNullFinalArrayElement]));
} else {
this.props.add$O(Clazz.new_($I$(5,1).c$$org_opensourcephysics_controls_XMLProperty$S$S$O$Z,[this, name, type, value, writeNullFinalArrayElement]));
}}, p$1);

Clazz.newMeth(C$, 'getXMLProperty$S', function (name) {
if (name == null ) {
return null;
}var it=this.props.iterator$();
while (it.hasNext$()){
var prop=it.next$();
if (name.equals$O(prop.getPropertyName$())) {
return prop;
}}
return null;
}, p$1);

Clazz.newMeth(C$, 'readInput', function () {
this.readFailed=false;
try {
var openingTag=this.input.readLine$();
var count=0;
while (openingTag != null  && openingTag.indexOf$S("<object class=") == -1 ){
count++;
if (count > 9) {
this.readFailed=true;
return;
}openingTag=this.input.readLine$();
}
if (openingTag != null ) {
var xml=openingTag;
var i=xml.indexOf$S("version=");
if (i != -1) {
xml=xml.substring$I(i + 9);
this.version=xml.substring$I$I(0, xml.indexOf$S("\""));
}p$1.readObject$org_opensourcephysics_controls_XMLControlElement$S.apply(this, [this, openingTag]);
} else {
this.readFailed=true;
return;
}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
this.readFailed=true;
(function(a,f){return f.apply(null,a)})(["Failed to read xml: " + ex.getMessage$()],$I$(9).warning$S);
return;
} else {
throw ex;
}
}
if (Clazz.getClass($I$(8)).equals$O(this.getObjectClass$())) {
var cryptic=this.loadObject$O(null);
var xml=cryptic.decrypt$();
var test=Clazz.new_(C$.c$$S,[xml]);
if (test.failedToRead$()) {
return;
}var pass=this.password;
this.password=test.getString$S("xml_password");
switch (this.decryptPolicy) {
case 5:
return;
case 3:
if ((this.password != null ) && !this.password.equals$O("") && !this.password.equals$O(pass)  ) {
if (!$I$(26).verify$S$S(this.password, null)) {
return;
}}}
this.clearValues$();
this.object=null;
this.className=Clazz.getClass(java.lang.Object).getName$();
this.theClass=null;
this.readXML$S(xml);
}}, p$1);

Clazz.newMeth(C$, 'isInputForClass$Class', function (type) {
try {
var xml=this.input.readLine$();
while ((xml != null ) && (xml.indexOf$S("<object") == -1) ){
xml=this.input.readLine$();
}
if (xml != null ) {
xml=xml.substring$I(xml.indexOf$S("class=") + 7);
var className=xml.substring$I$I(0, xml.indexOf$S("\""));
if (className.equals$O(type.getName$())) {
return true;
}}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
ex.printStackTrace$();
} else {
throw ex;
}
}
return false;
}, p$1);

Clazz.newMeth(C$, 'readObject$org_opensourcephysics_controls_XMLControlElement$S', function (control, xml) {
control.clearValues$();
xml=xml.substring$I(xml.indexOf$S("class=") + 7);
var className=xml.substring$I$I(0, xml.indexOf$S("\""));
var i=className.lastIndexOf$S(".");
if (i > -1) {
var packageName=className.substring$I$I(0, i);
if (packageName.endsWith$S("org.opensourcephysics.media")) {
className=packageName + ".core" + className.substring$I(i) ;
}}control.className=className;
if (xml.indexOf$S("/>") != -1) {
this.input.readLine$();
return control;
}var prop=control;
xml=this.input.readLine$();
while (xml != null ){
if (xml.indexOf$S("</object>") != -1) {
this.input.readLine$();
return control;
} else if (xml.indexOf$S("<property") != -1) {
var child=p$1.readProperty$org_opensourcephysics_controls_XMLPropertyElement$S.apply(this, [Clazz.new_($I$(5,1).c$$org_opensourcephysics_controls_XMLProperty,[prop]), xml]);
control.props.add$O(child);
control.propNames.add$O(child.getPropertyName$());
}xml=this.input.readLine$();
}
return control;
}, p$1);

Clazz.newMeth(C$, 'readProperty$org_opensourcephysics_controls_XMLPropertyElement$S', function (prop, xml) {
prop.name=xml.substring$I$I(xml.indexOf$S("name=") + 6, xml.indexOf$S("type=") - 2);
xml=xml.substring$I(xml.indexOf$S("type=") + 6);
prop.type=xml.substring$I$I(0, xml.indexOf$S("\""));
if (prop.type.equals$O("array") || prop.type.equals$O("collection") ) {
xml=xml.substring$I(xml.indexOf$S("class=") + 7);
var className=xml.substring$I$I(0, xml.indexOf$S("\""));
var i=className.lastIndexOf$S(".");
if (i > -1) {
var packageName=className.substring$I$I(0, i);
if (packageName.endsWith$S("org.opensourcephysics.media")) {
className=packageName + ".core" + className.substring$I(i) ;
}}prop.className=className;
if (xml.indexOf$S("/>") != -1) {
return prop;
}xml=this.input.readLine$();
while (xml.indexOf$S("<property") != -1){
prop.content.add$O(p$1.readProperty$org_opensourcephysics_controls_XMLPropertyElement$S.apply(this, [Clazz.new_($I$(5,1).c$$org_opensourcephysics_controls_XMLProperty,[prop]), xml]));
xml=this.input.readLine$();
}
} else if (prop.type.equals$O("object")) {
if (xml.indexOf$S(">null</property") == -1) {
var control=p$1.readObject$org_opensourcephysics_controls_XMLControlElement$S.apply(this, [Clazz.new_(C$.c$$org_opensourcephysics_controls_XMLProperty,[prop]), this.input.readLine$()]);
prop.content.add$O(control);
prop.className=control.className;
}} else {
if (xml.indexOf$S("<![CDATA[") != -1) {
var s=xml.substring$I(xml.indexOf$S("<![CDATA["));
while (s.indexOf$S("]]></property>") == -1){
s += $I$(6).NEW_LINE + this.input.readLine$();
}
xml=s.substring$I$I(0, s.indexOf$S("]]></property>") + "]]>".length$());
} else {
var s=xml.substring$I(xml.indexOf$S(">") + 1);
while (s.indexOf$S("</property>") == -1){
s += $I$(6).NEW_LINE + this.input.readLine$();
}
xml=s.substring$I$I(0, s.indexOf$S("</property>"));
}prop.content.add$O(xml);
}return prop;
}, p$1);

Clazz.newMeth(C$, 'indent$I', function (level) {
var space="";
for (var i=0; i < 4 * level; i++) {
space += " ";
}
return space;
}, p$1);

Clazz.newMeth(C$, 'objectValue$org_opensourcephysics_controls_XMLProperty', function (prop) {
if (!prop.getPropertyType$().equals$O("object")) {
return null;
}if (prop.getPropertyContent$().isEmpty$()) return null;
var control=prop.getPropertyContent$().get$I(0);
return control.loadObject$O(null);
}, p$1);

Clazz.newMeth(C$, 'doubleValue$org_opensourcephysics_controls_XMLProperty', function (prop) {
if (!prop.getPropertyType$().equals$O("double")) {
return NaN;
}return Double.parseDouble$S(prop.getPropertyContent$().get$I(0));
}, p$1);

Clazz.newMeth(C$, 'intValue$org_opensourcephysics_controls_XMLProperty', function (prop) {
if (!prop.getPropertyType$().equals$O("int")) {
return -2147483648;
}return Integer.parseInt$S(prop.getPropertyContent$().get$I(0));
}, p$1);

Clazz.newMeth(C$, 'booleanValue$org_opensourcephysics_controls_XMLProperty', function (prop) {
return prop.getPropertyContent$().get$I(0).equals$O("true");
}, p$1);

Clazz.newMeth(C$, 'stringValue$org_opensourcephysics_controls_XMLProperty', function (prop) {
if (!prop.getPropertyType$().equals$O("string")) {
return null;
}var content=prop.getPropertyContent$().get$I(0);
if (content.indexOf$S("<![CDATA[") != -1) {
content=content.substring$I$I(content.indexOf$S("<![CDATA[") + "<![CDATA[".length$(), content.indexOf$S("]]>"));
}return content;
}, p$1);

Clazz.newMeth(C$, 'arrayValue$org_opensourcephysics_controls_XMLProperty', function (prop) {
if (!prop.getPropertyType$().equals$O("array")) {
return null;
}var componentType=prop.getPropertyClass$().getComponentType$();
var content=prop.getPropertyContent$();
if (content.isEmpty$()) {
return Clazz.array(componentType, 0);
}var first=content.get$I(0);
if (first.getPropertyName$().equals$O("array")) {
var obj=first.getPropertyContent$().get$I(0);
if (Clazz.instanceOf(obj, "java.lang.String")) {
return p$1.arrayValue$S$Class.apply(this, [obj, componentType]);
}return null;
}var last=content.get$I(content.size$() - 1);
var index=last.getPropertyName$();
var n=Integer.parseInt$S(index.substring$I$I(1, index.indexOf$S("]")));
var array=Clazz.array(componentType, n + 1);
var it=content.iterator$();
while (it.hasNext$()){
var next=it.next$();
index=next.getPropertyName$();
n=Integer.parseInt$S(index.substring$I$I(1, index.indexOf$S("]")));
var type=next.getPropertyType$();
if (type.equals$O("object")) {
(function(a,f){return f.apply(null,a)})([array, n, p$1.objectValue$org_opensourcephysics_controls_XMLProperty.apply(this, [next])],$I$(27).set$O$I$O);
} else if (type.equals$O("int")) {
var val=p$1.intValue$org_opensourcephysics_controls_XMLProperty.apply(this, [next]);
if (Clazz.getClass(java.lang.Object).isAssignableFrom$Class(componentType)) {
(function(a,f){return f.apply(null,a)})([array, n,  new Integer(val)],$I$(27).set$O$I$O);
} else {
$I$(27).setInt$O$I$I(array, n, val);
}} else if (type.equals$O("double")) {
var val=p$1.doubleValue$org_opensourcephysics_controls_XMLProperty.apply(this, [next]);
if (Clazz.getClass(java.lang.Object).isAssignableFrom$Class(componentType)) {
(function(a,f){return f.apply(null,a)})([array, n,  new Double(val)],$I$(27).set$O$I$O);
} else {
$I$(27).setDouble$O$I$D(array, n, val);
}} else if (type.equals$O("boolean")) {
var val=p$1.booleanValue$org_opensourcephysics_controls_XMLProperty.apply(this, [next]);
if (Clazz.getClass(java.lang.Object).isAssignableFrom$Class(componentType)) {
(function(a,f){return f.apply(null,a)})([array, n,  Boolean.from(val)],$I$(27).set$O$I$O);
} else {
$I$(27).setBoolean$O$I$Z(array, n, val);
}} else if (type.equals$O("string")) {
(function(a,f){return f.apply(null,a)})([array, n, p$1.stringValue$org_opensourcephysics_controls_XMLProperty.apply(this, [next])],$I$(27).set$O$I$O);
} else if (type.equals$O("array")) {
(function(a,f){return f.apply(null,a)})([array, n, p$1.arrayValue$org_opensourcephysics_controls_XMLProperty.apply(this, [next])],$I$(27).set$O$I$O);
} else if (type.equals$O("collection")) {
(function(a,f){return f.apply(null,a)})([array, n, p$1.collectionValue$org_opensourcephysics_controls_XMLProperty.apply(this, [next])],$I$(27).set$O$I$O);
}}
return array;
}, p$1);

Clazz.newMeth(C$, 'arrayValue$S$Class', function (arrayString, componentType) {
if (!(arrayString.startsWith$S("{") && arrayString.endsWith$S("}") )) {
return null;
}var trimmed=arrayString.substring$I$I(1, arrayString.length$() - 1);
if (componentType.isArray$()) {
var list=Clazz.new_($I$(2,1));
var isNull=Clazz.new_($I$(2,1));
var arrayType=componentType.getComponentType$();
var i=trimmed.indexOf$S("{");
var j=p$1.indexOfClosingBrace$S$I.apply(this, [trimmed, i]);
var k=trimmed.indexOf$S(",");
while (j > 0){
if (k > -1 && k < i ) {
isNull.add$O(new Boolean(true));
trimmed=trimmed.substring$I(k + 1);
} else {
var nextArray=trimmed.substring$I$I(i, j + 1);
var obj=p$1.arrayValue$S$Class.apply(this, [nextArray, arrayType]);
list.add$O(obj);
isNull.add$O(new Boolean(false));
trimmed=trimmed.substring$I(j + 1);
if (trimmed.startsWith$S(",")) trimmed=trimmed.substring$I(1);
}i=trimmed.indexOf$S("{");
j=p$1.indexOfClosingBrace$S$I.apply(this, [trimmed, i]);
k=trimmed.indexOf$S(",");
}
while (k > -1){
isNull.add$O(new Boolean(true));
trimmed=trimmed.substring$I(k + 1);
k=trimmed.indexOf$S(",");
}
if (trimmed.length$() > 0) {
isNull.add$O(new Boolean(true));
}var array=Clazz.array(componentType, isNull.size$());
var hasNoElement=isNull.toArray$OA(Clazz.array($I$(28), [0]));
var it=list.iterator$();
for (var n=0; n < hasNoElement.length; n++) {
if (!(hasNoElement[n]).valueOf() && it.hasNext$() ) {
var obj=it.next$();
$I$(27).set$O$I$O(array, n, obj);
}}
return array;
}var list=Clazz.new_($I$(2,1));
while (!trimmed.equals$O("")){
var i=trimmed.indexOf$S(",");
if (i > -1) {
list.add$O(trimmed.substring$I$I(0, i));
trimmed=trimmed.substring$I(i + 1);
} else {
list.add$O(trimmed);
break;
}}
var array=Clazz.array(componentType, list.size$());
var it=list.iterator$();
var n=0;
while (it.hasNext$()){
if (componentType === Integer.TYPE ) {
var i=Integer.parseInt$S(it.next$());
$I$(27).setInt$O$I$I(array, n++, i);
} else if (componentType === Double.TYPE ) {
var x=Double.parseDouble$S(it.next$());
$I$(27).setDouble$O$I$D(array, n++, x);
} else if (componentType === $I$(28).TYPE ) {
var bool=it.next$().equals$O("true");
$I$(27).setBoolean$O$I$Z(array, n++, bool);
}}
return array;
}, p$1);

Clazz.newMeth(C$, 'collectionValue$org_opensourcephysics_controls_XMLProperty', function (prop) {
if (!prop.getPropertyType$().equals$O("collection")) {
return null;
}var classType=prop.getPropertyClass$();
try {
var c=classType.newInstance$();
var content=prop.getPropertyContent$();
var it=content.iterator$();
while (it.hasNext$()){
var next=it.next$();
var type=next.getPropertyType$();
if (type.equals$O("object")) {
c.add$O(p$1.objectValue$org_opensourcephysics_controls_XMLProperty.apply(this, [next]));
} else if (type.equals$O("string")) {
c.add$O(p$1.stringValue$org_opensourcephysics_controls_XMLProperty.apply(this, [next]));
} else if (type.equals$O("array")) {
c.add$O(p$1.arrayValue$org_opensourcephysics_controls_XMLProperty.apply(this, [next]));
} else if (type.equals$O("collection")) {
c.add$O(p$1.collectionValue$org_opensourcephysics_controls_XMLProperty.apply(this, [next]));
}}
return c;
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
ex.printStackTrace$();
} else {
throw ex;
}
}
return null;
}, p$1);

Clazz.newMeth(C$, 'indexOfClosingBrace$S$I', function (arrayString, indexOfOpeningBrace) {
var pointer=indexOfOpeningBrace + 1;
var n=1;
var opening=arrayString.indexOf$S$I("{", pointer);
var closing=arrayString.indexOf$S$I("}", pointer);
while (n > 0){
if (opening > -1 && opening < closing ) {
n++;
pointer=opening + 1;
opening=arrayString.indexOf$S$I("{", pointer);
} else if (closing > -1) {
n--;
pointer=closing + 1;
closing=arrayString.indexOf$S$I("}", pointer);
} else return -1;
}
return pointer - 1;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.compactArraySize=0;
C$.encoding="UTF-8";
};
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-20 00:04:04 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
