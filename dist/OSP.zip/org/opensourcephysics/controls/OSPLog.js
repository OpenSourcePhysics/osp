(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),I$=[[0,'java.awt.Color','java.util.logging.Level','org.opensourcephysics.controls.ConsoleLevel','java.util.logging.LogRecord','org.opensourcephysics.display.OSPRuntime','org.opensourcephysics.js.JSUtil','java.io.PrintStream','org.opensourcephysics.controls.LoggerOutputStream','org.opensourcephysics.controls.MessageFrame','org.opensourcephysics.controls.OSPLog','java.awt.EventQueue','java.io.BufferedWriter','java.io.FileWriter','javax.swing.JOptionPane','org.opensourcephysics.controls.ControlsRes','org.opensourcephysics.controls.XML','javax.swing.JPanel','java.awt.BorderLayout','java.awt.Dimension','java.awt.RenderingHints','javax.swing.JTextPane','javax.swing.JScrollPane','javax.swing.text.StyleContext','javax.swing.text.StyleConstants','org.opensourcephysics.tools.FontSizer','java.awt.event.MouseAdapter','java.util.logging.Logger','org.opensourcephysics.controls.OSPLogHandler','org.opensourcephysics.controls.ConsoleFormatter','java.util.logging.FileHandler','java.util.logging.XMLFormatter','javax.swing.JPopupMenu','javax.swing.JMenu','javax.swing.ButtonGroup','javax.swing.JRadioButtonMenuItem','javax.swing.AbstractAction','javax.swing.JMenuBar','javax.swing.JCheckBoxMenuItem','javax.swing.JFileChooser','java.io.File','java.io.BufferedReader','java.io.FileReader','StringBuffer','Throwable','java.io.StringWriter','java.io.PrintWriter','org.opensourcephysics.controls.XMLControlElement']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "OSPLog", null, 'javax.swing.JFrame');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.hasPermission=true;
},1);

C$.$fields$=[['Z',['hasPermission'],'S',['logFileName','tempFileName','pkgName','bundleName'],'O',['logger','java.util.logging.Logger','fileHandler','java.util.logging.Handler','logHandler','org.opensourcephysics.controls.OSPLogHandler','textPane','javax.swing.JTextPane','logPanel','javax.swing.JPanel','popup','javax.swing.JPopupMenu','popupGroup','javax.swing.ButtonGroup','+menubarGroup','logToFileItem','javax.swing.JMenuItem']]
,['Z',['logConsole'],'I',['messageIndex'],'S',['eol','logdir','slash'],'O',['OSPLOG','org.opensourcephysics.controls.OSPLog','chooser','javax.swing.JFileChooser','black','javax.swing.text.Style','+red','+blue','+green','+magenta','+gray','DARK_GREEN','java.awt.Color','+DARK_BLUE','+DARK_RED','levels','java.util.logging.Level[]','defaultLevel','java.util.logging.Level','messageStorage','java.util.logging.LogRecord[]']]]

Clazz.newMeth(C$, 'getOSPLog$', function () {
if (C$.OSPLOG == null ) {
if (!$I$(5).appletMode && ($I$(5).applet == null ) ) {
C$.OSPLOG=Clazz.new_(C$.c$$S$S,["org.opensourcephysics", null]);
if (!$I$(6).isJS) {
try {
System.setOut$java_io_PrintStream(Clazz.new_([Clazz.new_([$I$(3).OUT_CONSOLE, System.out],$I$(8,1).c$$org_opensourcephysics_controls_ConsoleLevel$java_io_OutputStream)],$I$(7,1).c$$java_io_OutputStream));
System.setErr$java_io_PrintStream(Clazz.new_([Clazz.new_([$I$(3).ERR_CONSOLE, System.err],$I$(8,1).c$$org_opensourcephysics_controls_ConsoleLevel$java_io_OutputStream)],$I$(7,1).c$$java_io_OutputStream));
} catch (ex) {
if (Clazz.exceptionOf(ex,"SecurityException")){
} else {
throw ex;
}
}
}C$.setLevel$java_util_logging_Level(C$.defaultLevel);
}}return C$.OSPLOG;
}, 1);

Clazz.newMeth(C$, 'setLogDir$S', function (dir) {
C$.logdir=dir;
});

Clazz.newMeth(C$, 'getLogDir$', function () {
return C$.logdir;
});

Clazz.newMeth(C$, 'isLogVisible$', function () {
if (($I$(5).appletMode || ($I$(5).applet != null ) ) && ($I$(9).APPLET_MESSAGEFRAME != null ) ) {
return $I$(9).APPLET_MESSAGEFRAME.isVisible$();
} else if (C$.OSPLOG != null ) {
return C$.OSPLOG.isVisible$();
}return false;
}, 1);

Clazz.newMeth(C$, 'setVisible$Z', function (visible) {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
$I$(9).showLog$Z(visible);
} else {
C$.superclazz.prototype.setVisible$Z.apply(this, [visible]);
}});

Clazz.newMeth(C$, 'isVisible$', function () {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
return $I$(9).isLogVisible$();
}return C$.superclazz.prototype.isVisible$.apply(this, []);
});

Clazz.newMeth(C$, 'showLog$', function () {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
return $I$(9).showLog$Z(true);
}C$.getOSPLog$().setVisible$Z(true);
var logger=C$.OSPLOG.getLogger$();
for (var i=0, n=C$.messageStorage.length; i < n; i++) {
var record=C$.messageStorage[(i + C$.messageIndex) % n];
if (record != null ) {
logger.log$java_util_logging_LogRecord(record);
}}
C$.messageIndex=0;
return C$.getOSPLog$();
}, 1);

Clazz.newMeth(C$, 'showLogInvokeLater$', function () {
var doLater=((P$.OSPLog$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPLog$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
$I$(10).showLog$();
});
})()
), Clazz.new_(P$.OSPLog$1.$init$,[this, null]));
$I$(11).invokeLater$Runnable(doLater);
}, 1);

Clazz.newMeth(C$, 'getLevelValue$', function () {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
return $I$(9).getLevelValue$();
}try {
var level=C$.getOSPLog$().getLogger$().getLevel$();
if (level != null ) return level.intValue$();
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
return -1;
}, 1);

Clazz.newMeth(C$, 'setLevel$java_util_logging_Level', function (level) {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
$I$(9).setLevel$java_util_logging_Level(level);
} else {
try {
C$.getOSPLog$().getLogger$().setLevel$java_util_logging_Level(level);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
if ((C$.getOSPLog$() == null ) || (C$.getOSPLog$().menubarGroup == null ) ) {
return;
}for (var i=0; i < 2; i++) {
var e=C$.getOSPLog$().menubarGroup.getElements$();
if (i == 1) {
e=C$.getOSPLog$().popupGroup.getElements$();
}while (e.hasMoreElements$()){
var item=e.nextElement$();
if (C$.getOSPLog$().getLogger$().getLevel$().toString().equals$O(item.getActionCommand$())) {
item.setSelected$Z(true);
break;
}}
}
}}, 1);

Clazz.newMeth(C$, 'parseLevel$S', function (level) {
for (var i=0; i < C$.levels.length; i++) {
if (C$.levels[i].getName$().equals$O(level)) {
return C$.levels[i];
}}
return null;
}, 1);

Clazz.newMeth(C$, 'severe$S', function (msg) {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
$I$(9).severe$S(msg);
} else {
C$.log$java_util_logging_Level$S($I$(2).SEVERE, msg);
}}, 1);

Clazz.newMeth(C$, 'warning$S', function (msg) {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
$I$(9).warning$S(msg);
} else {
C$.log$java_util_logging_Level$S($I$(2).WARNING, msg);
}}, 1);

Clazz.newMeth(C$, 'info$S', function (msg) {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
$I$(9).info$S(msg);
} else {
C$.log$java_util_logging_Level$S($I$(2).INFO, msg);
}}, 1);

Clazz.newMeth(C$, 'config$S', function (msg) {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
$I$(9).config$S(msg);
} else {
C$.log$java_util_logging_Level$S($I$(2).CONFIG, msg);
}}, 1);

Clazz.newMeth(C$, 'fine$S', function (msg) {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
$I$(9).fine$S(msg);
} else {
C$.log$java_util_logging_Level$S($I$(2).FINE, msg);
}}, 1);

Clazz.newMeth(C$, 'clearLog$', function () {
C$.messageIndex=0;
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
$I$(9).clear$();
} else {
C$.OSPLOG.clear$();
}}, 1);

Clazz.newMeth(C$, 'finer$S', function (msg) {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
$I$(9).finer$S(msg);
} else {
C$.log$java_util_logging_Level$S($I$(2).FINER, msg);
}}, 1);

Clazz.newMeth(C$, 'finest$S', function (msg) {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
$I$(9).finest$S(msg);
} else {
C$.log$java_util_logging_Level$S($I$(2).FINEST, msg);
}}, 1);

Clazz.newMeth(C$, 'setConsoleMessagesLogged$Z', function (log) {
C$.logConsole=log;
}, 1);

Clazz.newMeth(C$, 'isConsoleMessagesLogged$', function () {
return C$.logConsole;
}, 1);

Clazz.newMeth(C$, 'c$$Package', function (pkg) {
C$.c$$S$S.apply(this, [pkg.getName$(), null]);
}, 1);

Clazz.newMeth(C$, 'c$$Package$S', function (pkg, resourceBundleName) {
C$.c$$S$S.apply(this, [pkg.getName$(), resourceBundleName]);
}, 1);

Clazz.newMeth(C$, 'c$$Class', function (type) {
C$.c$$Class$S.apply(this, [type, null]);
}, 1);

Clazz.newMeth(C$, 'c$$Class$S', function (type, resourceBundleName) {
C$.c$$S$S.apply(this, [type.getPackage$().getName$(), resourceBundleName]);
}, 1);

Clazz.newMeth(C$, 'getLogPanel$', function () {
return this.logPanel;
});

Clazz.newMeth(C$, 'clear$', function () {
this.textPane.setText$S(null);
});

Clazz.newMeth(C$, 'saveLog$S', function (fileName) {
if ((fileName == null ) || fileName.trim$().equals$O("") ) {
return this.saveLogAs$();
}try {
var out=Clazz.new_([Clazz.new_($I$(13,1).c$$S,[fileName])],$I$(12,1).c$$java_io_Writer);
out.write$S(this.textPane.getText$());
out.flush$();
out.close$();
return fileName;
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
return null;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'saveLogAs$', function () {
var result=C$.getChooser$().showSaveDialog$java_awt_Component(null);
if (result == 0) {
var file=C$.getChooser$().getSelectedFile$();
if (file.exists$()) {
var selected=$I$(14,"showConfirmDialog$java_awt_Component$O$S$I",[this, $I$(15).getString$S("OSPLog.ReplaceExisting_dialog_message") + file.getName$() + $I$(15).getString$S("OSPLog.question_mark") , $I$(15).getString$S("OSPLog.ReplaceFile_dialog_title"), 1]);
if (selected != 0) {
return null;
}}var fileName=$I$(16,"getRelativePath$S",[file.getAbsolutePath$()]);
return this.saveLog$S(fileName);
}return null;
});

Clazz.newMeth(C$, 'saveXML$S', function (fileName) {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
this.logger.log$java_util_logging_Level$S($I$(2).FINE, "Cannot save XML file when running as an applet.");
return null;
}if ((fileName == null ) || fileName.trim$().equals$O("") ) {
return this.saveXMLAs$();
}var xml=this.read$S(this.tempFileName);
var fileHandler=this.getFileHandler$();
var tail=fileHandler.getFormatter$().getTail$java_util_logging_Handler(fileHandler);
xml=xml + tail;
try {
var out=Clazz.new_([Clazz.new_($I$(13,1).c$$S,[fileName])],$I$(12,1).c$$java_io_Writer);
out.write$S(xml);
out.flush$();
out.close$();
return fileName;
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
return null;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'saveXMLAs$', function () {
var result=C$.getChooser$().showSaveDialog$java_awt_Component(null);
if (result == 0) {
var file=C$.getChooser$().getSelectedFile$();
if (file.exists$()) {
var selected=$I$(14,"showConfirmDialog$java_awt_Component$O$S$I",[this, $I$(15).getString$S("OSPLog.ReplaceExisting_dialog_message") + file.getName$() + $I$(15).getString$S("OSPLog.question_mark") , $I$(15).getString$S("OSPLog.ReplaceFile_dialog_title"), 1]);
if (selected != 0) {
return null;
}}this.logFileName=$I$(16,"getRelativePath$S",[file.getAbsolutePath$()]);
return this.saveXML$S(this.logFileName);
}return null;
});

Clazz.newMeth(C$, 'open$', function () {
var result=C$.getChooser$().showOpenDialog$java_awt_Component(null);
if (result == 0) {
var file=C$.getChooser$().getSelectedFile$();
var fileName=$I$(16,"getRelativePath$S",[file.getAbsolutePath$()]);
return this.open$S(fileName);
}return null;
});

Clazz.newMeth(C$, 'open$S', function (fileName) {
this.textPane.setText$S(this.read$S(fileName));
return fileName;
});

Clazz.newMeth(C$, 'getLogger$', function () {
return this.logger;
});

Clazz.newMeth(C$, 'setLogToFile$Z', function (enable) {
if ($I$(5).appletMode || ($I$(5).applet != null ) ) {
this.logger.log$java_util_logging_Level$S($I$(2).FINE, "Cannot log to file when running as an applet.");
return;
}if (enable) {
this.logToFileItem.setSelected$Z(true);
this.logger.addHandler$java_util_logging_Handler(this.getFileHandler$());
} else {
this.logToFileItem.setSelected$Z(false);
this.logger.removeHandler$java_util_logging_Handler(this.fileHandler);
}});

Clazz.newMeth(C$, 'firePropertyChange$S$O$O', function (propertyName, oldValue, newValue) {
C$.superclazz.prototype.firePropertyChange$S$O$O.apply(this, [propertyName, oldValue, newValue]);
});

Clazz.newMeth(C$, 'createGUI$', function () {
this.logPanel=Clazz.new_([Clazz.new_($I$(18,1))],$I$(17,1).c$$java_awt_LayoutManager);
this.logPanel.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(19,1).c$$I$I,[480, 240]));
this.setContentPane$java_awt_Container(this.logPanel);
this.textPane=((P$.OSPLog$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPLog$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.JTextPane'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
if (($I$(5).antiAliasText).valueOf()) {
var g2=g;
var rh=g2.getRenderingHints$();
rh.put$O$O($I$(20).KEY_TEXT_ANTIALIASING, $I$(20).VALUE_TEXT_ANTIALIAS_ON);
rh.put$O$O($I$(20).KEY_ANTIALIASING, $I$(20).VALUE_ANTIALIAS_ON);
}C$.superclazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
});
})()
), Clazz.new_($I$(21,1),[this, null],P$.OSPLog$2));
this.textPane.setEditable$Z(false);
this.textPane.setAutoscrolls$Z(true);
var textScroller=Clazz.new_($I$(22,1).c$$java_awt_Component,[this.textPane]);
textScroller.setWheelScrollingEnabled$Z(true);
this.logPanel.add$java_awt_Component$O(textScroller, "Center");
C$.black=$I$(23).getDefaultStyleContext$().getStyle$S("default");
C$.red=this.textPane.addStyle$S$javax_swing_text_Style("red", C$.black);
$I$(24).setForeground$javax_swing_text_MutableAttributeSet$java_awt_Color(C$.red, C$.DARK_RED);
C$.blue=this.textPane.addStyle$S$javax_swing_text_Style("blue", C$.black);
$I$(24).setForeground$javax_swing_text_MutableAttributeSet$java_awt_Color(C$.blue, C$.DARK_BLUE);
C$.green=this.textPane.addStyle$S$javax_swing_text_Style("green", C$.black);
$I$(24).setForeground$javax_swing_text_MutableAttributeSet$java_awt_Color(C$.green, C$.DARK_GREEN);
C$.magenta=this.textPane.addStyle$S$javax_swing_text_Style("magenta", C$.black);
$I$(24,"setForeground$javax_swing_text_MutableAttributeSet$java_awt_Color",[C$.magenta, $I$(1).MAGENTA]);
C$.gray=this.textPane.addStyle$S$javax_swing_text_Style("gray", C$.black);
$I$(24,"setForeground$javax_swing_text_MutableAttributeSet$java_awt_Color",[C$.gray, $I$(1).GRAY]);
this.createLogger$();
this.createMenus$();
this.pack$();
this.textPane.addMouseListener$java_awt_event_MouseListener(((P$.OSPLog$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPLog$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
try {
if ($I$(5).isPopupTrigger$java_awt_event_InputEvent(e)) {
if (this.b$['org.opensourcephysics.controls.OSPLog'].popup != null ) {
$I$(25,"setFonts$O$I",[this.b$['org.opensourcephysics.controls.OSPLog'].popup, $I$(25).getLevel$()]);
this.b$['org.opensourcephysics.controls.OSPLog'].popup.show$java_awt_Component$I$I(this.b$['org.opensourcephysics.controls.OSPLog'].textPane, e.getX$(), e.getY$() + 8);
}}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
System.err.println$S("Error in mouse action.");
System.err.println$S(ex.toString());
ex.printStackTrace$();
} else {
throw ex;
}
}
});
})()
), Clazz.new_($I$(26,1),[this, null],P$.OSPLog$3)));
});

Clazz.newMeth(C$, 'createLogger$', function () {
if (this.bundleName != null ) {
try {
this.logger=$I$(27).getLogger$S$S(this.pkgName, this.bundleName);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
this.logger=$I$(27).getLogger$S(this.pkgName);
} else {
throw ex;
}
}
} else {
this.logger=$I$(27).getLogger$S(this.pkgName);
}try {
this.logger.setLevel$java_util_logging_Level(C$.defaultLevel);
this.logHandler=Clazz.new_($I$(28,1).c$$javax_swing_JTextPane$org_opensourcephysics_controls_OSPLog,[this.textPane, this]);
this.logHandler.setFormatter$java_util_logging_Formatter(Clazz.new_($I$(29,1)));
this.logHandler.setLevel$java_util_logging_Level($I$(2).ALL);
Clazz.getClass($I$(5)).getClass$();
this.logger.setUseParentHandlers$Z(false);
this.logger.addHandler$java_util_logging_Handler(this.logHandler);
} catch (ex) {
if (Clazz.exceptionOf(ex,"SecurityException")){
this.hasPermission=false;
} else {
throw ex;
}
}
return this.logger;
});

Clazz.newMeth(C$, 'getFileHandler$', function () {
if (this.fileHandler != null ) {
return this.fileHandler;
}try {
var i=this.pkgName.lastIndexOf$S(".");
if (i > -1) {
this.pkgName=this.pkgName.substring$I(i + 1);
}if (C$.logdir.endsWith$S(C$.slash)) {
this.tempFileName=C$.logdir + this.pkgName + ".log" ;
} else {
this.tempFileName=C$.logdir + C$.slash + this.pkgName + ".log" ;
}this.fileHandler=Clazz.new_($I$(30,1).c$$S,[this.tempFileName]);
this.fileHandler.setFormatter$java_util_logging_Formatter(Clazz.new_($I$(31,1)));
this.fileHandler.setLevel$java_util_logging_Level($I$(2).ALL);
this.logger.addHandler$java_util_logging_Handler(this.fileHandler);
this.logger.log$java_util_logging_Level$S($I$(2).INFO, "Logging to file enabled. File = " + this.tempFileName);
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
ex.printStackTrace$();
} else {
throw ex;
}
}
return this.fileHandler;
});

Clazz.newMeth(C$, 'createMenus$', function () {
if (!this.hasPermission) {
return;
}this.popup=Clazz.new_($I$(32,1));
var menu=Clazz.new_([$I$(15).getString$S("OSPLog.Level_menu")],$I$(33,1).c$$S);
this.popup.add$javax_swing_JMenuItem(menu);
this.popupGroup=Clazz.new_($I$(34,1));
for (var i=0; i < C$.levels.length; i++) {
var item=Clazz.new_([C$.levels[i].getName$()],$I$(35,1).c$$S);
menu.add$java_awt_Component$I(item, 0);
this.popupGroup.add$javax_swing_AbstractButton(item);
if (this.logger.getLevel$().toString().equals$O(C$.levels[i].toString())) {
item.setSelected$Z(true);
}item.setActionCommand$S(C$.levels[i].getName$());
item.addActionListener$java_awt_event_ActionListener(((P$.OSPLog$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPLog$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.controls.OSPLog'].logger.setLevel$java_util_logging_Level($I$(2,"parse$S",[e.getActionCommand$()]));
var e2=this.b$['org.opensourcephysics.controls.OSPLog'].menubarGroup.getElements$();
while (e2.hasMoreElements$()){
var item=e2.nextElement$();
if (this.b$['org.opensourcephysics.controls.OSPLog'].logger.getLevel$().toString().equals$O(item.getActionCommand$())) {
item.setSelected$Z(true);
break;
}}
});
})()
), Clazz.new_(P$.OSPLog$4.$init$,[this, null])));
}
this.popup.addSeparator$();
var openAction=((P$.OSPLog$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPLog$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.controls.OSPLog'].open$.apply(this.b$['org.opensourcephysics.controls.OSPLog'], []);
});
})()
), Clazz.new_([this, null, $I$(15).getString$S("OSPLog.Open_popup")],$I$(36,1).c$$S,P$.OSPLog$5));
openAction.setEnabled$Z(!$I$(5).appletMode && ($I$(5).applet == null ) );
this.popup.add$javax_swing_Action(openAction);
var saveAsAction=((P$.OSPLog$6||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPLog$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.controls.OSPLog'].saveLogAs$.apply(this.b$['org.opensourcephysics.controls.OSPLog'], []);
});
})()
), Clazz.new_([this, null, $I$(15).getString$S("OSPLog.SaveAs_popup")],$I$(36,1).c$$S,P$.OSPLog$6));
saveAsAction.setEnabled$Z(!$I$(5).appletMode && ($I$(5).applet == null ) );
this.popup.add$javax_swing_Action(saveAsAction);
this.popup.addSeparator$();
var clearAction=((P$.OSPLog$7||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPLog$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.controls.OSPLog'].clear$.apply(this.b$['org.opensourcephysics.controls.OSPLog'], []);
});
})()
), Clazz.new_([this, null, $I$(15).getString$S("OSPLog.Clear_popup")],$I$(36,1).c$$S,P$.OSPLog$7));
this.popup.add$javax_swing_Action(clearAction);
var menubar=Clazz.new_($I$(37,1));
this.setJMenuBar$javax_swing_JMenuBar(menubar);
menu=Clazz.new_([$I$(15).getString$S("OSPLog.File_menu")],$I$(33,1).c$$S);
menubar.add$javax_swing_JMenu(menu);
menu.add$javax_swing_Action(openAction);
menu.add$javax_swing_Action(saveAsAction);
menu=Clazz.new_([$I$(15).getString$S("OSPLog.Edit_menu")],$I$(33,1).c$$S);
menubar.add$javax_swing_JMenu(menu);
menu.add$javax_swing_Action(clearAction);
menu=Clazz.new_([$I$(15).getString$S("OSPLog.Level_menu")],$I$(33,1).c$$S);
menubar.add$javax_swing_JMenu(menu);
this.menubarGroup=Clazz.new_($I$(34,1));
for (var i=0; i < C$.levels.length; i++) {
var item=Clazz.new_([C$.levels[i].getName$()],$I$(35,1).c$$S);
menu.add$java_awt_Component$I(item, 0);
this.menubarGroup.add$javax_swing_AbstractButton(item);
if (this.logger.getLevel$().toString().equals$O(C$.levels[i].toString())) {
item.setSelected$Z(true);
}item.setActionCommand$S(C$.levels[i].getName$());
item.addActionListener$java_awt_event_ActionListener(((P$.OSPLog$8||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPLog$8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.controls.OSPLog'].logger.setLevel$java_util_logging_Level($I$(2,"parse$S",[e.getActionCommand$()]));
var e2=this.b$['org.opensourcephysics.controls.OSPLog'].popupGroup.getElements$();
while (e2.hasMoreElements$()){
var item=e2.nextElement$();
if (this.b$['org.opensourcephysics.controls.OSPLog'].logger.getLevel$().toString().equals$O(item.getActionCommand$())) {
item.setSelected$Z(true);
break;
}}
});
})()
), Clazz.new_(P$.OSPLog$8.$init$,[this, null])));
}
var prefMenu=Clazz.new_([$I$(15).getString$S("OSPLog.Options_menu")],$I$(33,1).c$$S);
menubar.add$javax_swing_JMenu(prefMenu);
this.logToFileItem=Clazz.new_([$I$(15).getString$S("OSPLog.LogToFile_check_box")],$I$(38,1).c$$S);
this.logToFileItem.setSelected$Z(false);
this.logToFileItem.setEnabled$Z(!$I$(5).appletMode && ($I$(5).applet == null ) );
this.logToFileItem.addActionListener$java_awt_event_ActionListener(((P$.OSPLog$9||
(function(){/*a*/var C$=Clazz.newClass(P$, "OSPLog$9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var item=e.getSource$();
this.b$['org.opensourcephysics.controls.OSPLog'].setLogToFile$Z.apply(this.b$['org.opensourcephysics.controls.OSPLog'], [item.isSelected$()]);
});
})()
), Clazz.new_(P$.OSPLog$9.$init$,[this, null])));
prefMenu.add$javax_swing_JMenuItem(this.logToFileItem);
});

Clazz.newMeth(C$, 'getChooser$', function () {
if (C$.chooser == null ) {
C$.chooser=Clazz.new_([Clazz.new_([$I$(5).chooserDir],$I$(40,1).c$$S)],$I$(39,1).c$$java_io_File);
}$I$(25,"setFonts$O$I",[C$.chooser, $I$(25).getLevel$()]);
return C$.chooser;
}, 1);

Clazz.newMeth(C$, 'read$S', function (fileName) {
var file=Clazz.new_($I$(40,1).c$$S,[fileName]);
var buffer=null;
try {
var $in=Clazz.new_([Clazz.new_($I$(42,1).c$$java_io_File,[file])],$I$(41,1).c$$java_io_Reader);
buffer=Clazz.new_($I$(43,1));
var line=$in.readLine$();
while (line != null ){
buffer.append$S(line + $I$(16).NEW_LINE);
line=$in.readLine$();
}
$in.close$();
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
this.logger.warning$S(ex.toString());
} else {
throw ex;
}
}
return buffer.toString();
});

Clazz.newMeth(C$, 'c$$S$S', function (name, resourceBundleName) {
;C$.superclazz.c$$S.apply(this,[$I$(15).getString$S("OSPLog.DefaultTitle")]);C$.$init$.apply(this);
this.setName$S("LogTool");
this.bundleName=resourceBundleName;
this.pkgName=name;
Clazz.getClass($I$(3)).getName$();
this.createGUI$();
this.setDefaultCloseOperation$I(1);
}, 1);

Clazz.newMeth(C$, 'log$java_util_logging_Level$S', function (level, msg) {
if ($I$(6).isJS) {
System.out.println$S("OSPLog " + level + " " + msg );
return;
}var record=Clazz.new_($I$(4,1).c$$java_util_logging_Level$S,[level, msg]);
var stack=(Clazz.new_($I$(44,1))).getStackTrace$();
for (var i=0; i < stack.length; i++) {
var el=stack[i];
var className=el.getClassName$();
if (!className.equals$O("org.opensourcephysics.controls.OSPLog")) {
record.setSourceClassName$S(className);
record.setSourceMethodName$S(el.getMethodName$());
break;
}}
if (C$.OSPLOG != null ) {
C$.OSPLOG.getLogger$().log$java_util_logging_LogRecord(record);
} else {
C$.messageStorage[C$.messageIndex]=record;
C$.messageIndex++;
C$.messageIndex=C$.messageIndex % C$.messageStorage.length;
}}, 1);

C$.$static$=function(){C$.$static$=0;
C$.DARK_GREEN=Clazz.new_($I$(1,1).c$$I$I$I,[0, 128, 0]);
C$.DARK_BLUE=Clazz.new_($I$(1,1).c$$I$I$I,[0, 0, 128]);
C$.DARK_RED=Clazz.new_($I$(1,1).c$$I$I$I,[128, 0, 0]);
C$.levels=Clazz.array($I$(2), -1, [$I$(2).OFF, $I$(2).SEVERE, $I$(2).WARNING, $I$(2).INFO, $I$(3).ERR_CONSOLE, $I$(3).OUT_CONSOLE, $I$(2).CONFIG, $I$(2).FINE, $I$(2).FINER, $I$(2).FINEST, $I$(2).ALL]);
C$.defaultLevel=$I$(3).OUT_CONSOLE;
C$.logConsole=true;
C$.messageStorage=Clazz.array($I$(4), [128]);
C$.messageIndex=0;
C$.eol="\n";
C$.logdir=".";
C$.slash="/";
{
try {
C$.eol=System.getProperty$S$S("line.separator", C$.eol);
C$.logdir=System.getProperty$S$S("user.dir", C$.logdir);
C$.slash=System.getProperty$S$S("file.separator", "/");
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
};
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:20 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
