SwingJS distribution -- site-resources directory

This directory can be used to hold non-Java files that your program 
needs to run -- data files, for instance. Files in it will be copied to 
the site/ directory by build-site.xml.

