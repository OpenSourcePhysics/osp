(function(){var P$=Clazz.newPackage("_"),I$=[[0,'javax.swing.SwingUtilities','javax.swing.JFrame','javax.swing.JTabbedPane','javax.swing.JPanel','javax.swing.JLabel','javax.swing.JTextField','javax.swing.JButton']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TabbedPaneDemo");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
$I$(1,"invokeLater$Runnable",[((P$.TabbedPaneDemo$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "TabbedPaneDemo$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$',  function () /*block*/{
var frame=Clazz.new_($I$(2,1).c$$S,["JTabbedPane Example"]);
frame.setDefaultCloseOperation$I.apply(frame, [3]);
frame.setSize$I$I.apply(frame, [420, 250]);
var tabbedPane=Clazz.new_($I$(3,1));
var profilePanel=Clazz.new_($I$(4,1));
profilePanel.add$java_awt_Component.apply(profilePanel, [Clazz.new_($I$(5,1).c$$S,["Name:"])]);
profilePanel.add$java_awt_Component.apply(profilePanel, [Clazz.new_($I$(6,1).c$$I,[15])]);
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S.apply(tabbedPane, ["Profile", null, profilePanel, "Edit user profile"]);
tabbedPane.setMnemonicAt$I$I.apply(tabbedPane, [0, 49]);
var actionsPanel=Clazz.new_($I$(4,1));
actionsPanel.add$java_awt_Component.apply(actionsPanel, [Clazz.new_($I$(7,1).c$$S,["Save Changes"])]);
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S.apply(tabbedPane, ["Actions", null, actionsPanel, "Perform actions"]);
tabbedPane.setMnemonicAt$I$I.apply(tabbedPane, [1, 50]);
var infoPanel=Clazz.new_($I$(4,1));
infoPanel.add$java_awt_Component.apply(infoPanel, [Clazz.new_($I$(5,1).c$$S,["Application version 1.0"])]);
tabbedPane.addTab$S$javax_swing_Icon$java_awt_Component$S.apply(tabbedPane, ["Info", null, infoPanel, "View app information"]);
tabbedPane.setMnemonicAt$I$I.apply(tabbedPane, [2, 51]);
frame.add$java_awt_Component.apply(frame, [tabbedPane]);
frame.setLocationRelativeTo$java_awt_Component.apply(frame, [null]);
frame.setVisible$Z.apply(frame, [true]);
});
})()
), Clazz.new_(P$.TabbedPaneDemo$lambda1.$init$,[this, null]))]);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-11-21 08:09:01 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
