(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.bmp"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "BMPMetadataFormatResources", null, 'java.util.ListResourceBundle');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getContents$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, ["BMPVersion", "BMP version string"]), Clazz.array(java.lang.Object, -1, ["Width", "The width of the image"]), Clazz.array(java.lang.Object, -1, ["Height", "The height of the image"]), Clazz.array(java.lang.Object, -1, ["BitsPerPixel", ""]), Clazz.array(java.lang.Object, -1, ["PixelsPerMeter", "Resolution in pixels per unit distance"]), Clazz.array(java.lang.Object, -1, ["X", "Pixels Per Meter along X"]), Clazz.array(java.lang.Object, -1, ["Y", "Pixels Per Meter along Y"]), Clazz.array(java.lang.Object, -1, ["ColorsUsed", "Number of color indexes in the color table actually used"]), Clazz.array(java.lang.Object, -1, ["ColorsImportant", "Number of color indexes considered important for display"]), Clazz.array(java.lang.Object, -1, ["Mask", "Color masks; present for BI_BITFIELDS compression only"]), Clazz.array(java.lang.Object, -1, ["Intent", "Rendering intent"]), Clazz.array(java.lang.Object, -1, ["Palette", "The color palette"]), Clazz.array(java.lang.Object, -1, ["Red", "Red Mask/Color Palette"]), Clazz.array(java.lang.Object, -1, ["Green", "Green Mask/Color Palette/Gamma"]), Clazz.array(java.lang.Object, -1, ["Blue", "Blue Mask/Color Palette/Gamma"]), Clazz.array(java.lang.Object, -1, ["Alpha", "Alpha Mask/Color Palette/Gamma"]), Clazz.array(java.lang.Object, -1, ["ColorSpaceType", "Color Space Type"]), Clazz.array(java.lang.Object, -1, ["X", "The X coordinate of a point in XYZ color space"]), Clazz.array(java.lang.Object, -1, ["Y", "The Y coordinate of a point in XYZ color space"]), Clazz.array(java.lang.Object, -1, ["Z", "The Z coordinate of a point in XYZ color space"])]);
});
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-11-02 10:30:19 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
