(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.bmp"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "BMPConstants");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-09-20 18:32:08 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
