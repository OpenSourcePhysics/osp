(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.common"),I$=[[0,'com.sun.imageio.plugins.common.I18NImpl']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "I18N", null, 'com.sun.imageio.plugins.common.I18NImpl');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getString$S', function (key) {
return $I$(1).getString$S$S$S("com.sun.imageio.plugins.common.I18N", "iio-plugin.properties", key);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-13 20:36:09 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
