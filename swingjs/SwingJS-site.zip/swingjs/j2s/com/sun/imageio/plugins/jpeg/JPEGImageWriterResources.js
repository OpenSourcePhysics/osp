(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.jpeg"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JPEGImageWriterResources", null, 'java.util.ListResourceBundle');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getContents$', function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [Integer.toString$I(0), "Only Rasters or band subsets may be written with a destination type. Destination type ignored."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(1), "Stream metadata ignored on write"]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(2), "Metadata component ids incompatible with destination type. Metadata modified."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(3), "Metadata JFIF settings incompatible with destination type. Metadata modified."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(4), "Metadata Adobe settings incompatible with destination type. Metadata modified."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(5), "Metadata JFIF settings incompatible with image type. Metadata modified."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(6), "Metadata Adobe settings incompatible with image type. Metadata modified."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(7), "Metadata must be JPEGMetadata when writing a Raster. Metadata ignored."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(8), "Band subset not allowed for an IndexColorModel image.  Band subset ignored."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(9), "Thumbnails must be simple (possibly index) RGB or grayscale.  Incompatible thumbnail ignored."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(10), "Thumbnails ignored for non-JFIF-compatible image."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(11), "Thumbnails require JFIF marker segment.  Missing node added to metadata."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(12), "Thumbnail clipped."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(13), "Metadata adjusted (made JFIF-compatible) for thumbnail."]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(14), "RGB thumbnail can\'t be written as indexed.  Written as RGB"]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(15), "Grayscale thumbnail can\'t be written as indexed.  Written as JPEG"])]);
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-06-30 16:15:55 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
