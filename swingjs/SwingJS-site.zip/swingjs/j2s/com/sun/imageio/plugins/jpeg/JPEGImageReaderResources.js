(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.jpeg"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JPEGImageReaderResources", null, 'java.util.ListResourceBundle');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getContents$',  function () {
return Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, [Integer.toString$I(0), "Truncated File - Missing EOI marker"]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(1), "JFIF markers not allowed in JFIF JPEG thumbnail; ignored"]), Clazz.array(java.lang.Object, -1, [Integer.toString$I(2), "Embedded color profile is invalid; ignored"])]);
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-09-23 15:00:35 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
