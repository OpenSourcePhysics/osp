(function(){var P$=Clazz.newPackage("com.sun.jna"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Library");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-09-20 18:32:12 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
