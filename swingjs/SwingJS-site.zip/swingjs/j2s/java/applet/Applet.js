(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Applet", null, 'swingjs.a2s.Applet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-20 12:13:02 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
