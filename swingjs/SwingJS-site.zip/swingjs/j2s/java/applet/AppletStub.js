(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "AppletStub");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-07-08 18:16:12 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
