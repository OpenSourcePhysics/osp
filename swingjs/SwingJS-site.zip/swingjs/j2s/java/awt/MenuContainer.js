(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "MenuContainer");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-06-01 14:51:32 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
