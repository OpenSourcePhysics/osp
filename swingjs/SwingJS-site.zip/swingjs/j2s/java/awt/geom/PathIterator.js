(function(){var P$=Clazz.newPackage("java.awt.geom"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "PathIterator");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-10-27 11:22:58 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
