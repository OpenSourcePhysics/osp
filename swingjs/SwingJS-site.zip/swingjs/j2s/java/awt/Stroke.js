(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Stroke");
})();
;Clazz.setTVer('3.3.1-v1');//Created 2021-01-14 18:17:04 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
