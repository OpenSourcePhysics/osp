(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ClipboardOwner");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-11-07 11:08:19 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
