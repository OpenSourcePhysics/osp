(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Transferable");
})();
;Clazz.setTVer('3.3.1-v6');//Created 2023-03-20 19:03:53 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
