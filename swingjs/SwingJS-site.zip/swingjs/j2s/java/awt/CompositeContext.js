(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "CompositeContext");
})();
;Clazz.setTVer('3.2.8-v1');//Created 2020-02-05 16:08:18 Java2ScriptVisitor version 3.2.8-v1 net.sf.j2s.core.jar version 3.2.8-v1
