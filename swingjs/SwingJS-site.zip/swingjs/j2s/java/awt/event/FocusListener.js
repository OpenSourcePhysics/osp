(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "FocusListener", null, null, 'java.util.EventListener');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-09-26 09:45:13 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
