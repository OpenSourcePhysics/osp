(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "NativeLibLoader");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'loadLibraries$',  function () {
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v6');//Created 2023-03-20 19:03:55 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
