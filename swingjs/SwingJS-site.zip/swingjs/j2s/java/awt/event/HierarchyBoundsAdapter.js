(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "HierarchyBoundsAdapter", null, null, 'java.awt.event.HierarchyBoundsListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'ancestorMoved$java_awt_event_HierarchyEvent',  function (e) {
});

Clazz.newMeth(C$, 'ancestorResized$java_awt_event_HierarchyEvent',  function (e) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-10-27 11:22:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
