(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "WindowPeer", null, null, 'java.awt.peer.ContainerPeer');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-10-27 11:23:02 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
