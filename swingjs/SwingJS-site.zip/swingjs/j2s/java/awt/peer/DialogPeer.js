(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DialogPeer", null, null, 'java.awt.peer.WindowPeer');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-09-23 15:01:02 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
