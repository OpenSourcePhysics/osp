(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "KeyboardFocusManagerPeer");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-20 12:13:17 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
