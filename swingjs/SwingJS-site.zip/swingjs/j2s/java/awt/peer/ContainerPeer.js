(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ContainerPeer", null, null, 'java.awt.peer.ComponentPeer');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-02-23 09:51:14 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
