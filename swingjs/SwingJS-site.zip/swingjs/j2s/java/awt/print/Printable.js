(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Printable");

C$.$fields$=[[]
,['I',['PAGE_EXISTS','NO_SUCH_PAGE']]]

C$.$static$=function(){C$.$static$=0;
C$.PAGE_EXISTS=0;
C$.NO_SUCH_PAGE=1;
};
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-13 20:36:45 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
