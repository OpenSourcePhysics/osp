(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ItemSelectable");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-08-25 10:00:59 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
