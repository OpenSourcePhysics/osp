(function(){var P$=Clazz.newPackage("java.awt.im.spi"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "InputMethodContext", null, null, 'java.awt.im.InputMethodRequests');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-20 12:13:15 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
