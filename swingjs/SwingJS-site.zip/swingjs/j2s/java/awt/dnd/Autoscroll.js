(function(){var P$=Clazz.newPackage("java.awt.dnd"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Autoscroll");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-09-23 15:00:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
