(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DropTargetPeer");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-06-30 11:35:21 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
