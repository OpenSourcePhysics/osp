(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DragSourceContextPeer");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-10-27 11:22:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
