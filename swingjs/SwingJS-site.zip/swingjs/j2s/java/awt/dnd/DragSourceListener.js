(function(){var P$=Clazz.newPackage("java.awt.dnd"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DragSourceListener", null, null, 'java.util.EventListener');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.8-v1');//Created 2020-02-11 05:48:39 Java2ScriptVisitor version 3.2.8-v1 net.sf.j2s.core.jar version 3.2.8-v1
