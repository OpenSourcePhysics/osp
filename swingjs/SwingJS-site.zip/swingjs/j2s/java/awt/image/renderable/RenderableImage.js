(function(){var P$=Clazz.newPackage("java.awt.image.renderable"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "RenderableImage");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-10-27 11:23:01 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
