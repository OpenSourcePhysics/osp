(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "RenderedImage");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-02-25 19:41:51 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
