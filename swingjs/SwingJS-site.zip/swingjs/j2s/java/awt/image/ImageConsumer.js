(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ImageConsumer");

C$.$fields$=[[]
,['I',['RANDOMPIXELORDER','TOPDOWNLEFTRIGHT','COMPLETESCANLINES','SINGLEPASS','SINGLEFRAME','IMAGEERROR','SINGLEFRAMEDONE','STATICIMAGEDONE','IMAGEABORTED']]]

C$.$static$=function(){C$.$static$=0;
C$.RANDOMPIXELORDER=1;
C$.TOPDOWNLEFTRIGHT=2;
C$.COMPLETESCANLINES=4;
C$.SINGLEPASS=8;
C$.SINGLEFRAME=16;
C$.IMAGEERROR=1;
C$.SINGLEFRAMEDONE=2;
C$.STATICIMAGEDONE=3;
C$.IMAGEABORTED=4;
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-10-27 11:23:00 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
