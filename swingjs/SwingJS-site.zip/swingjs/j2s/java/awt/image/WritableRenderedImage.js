(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "WritableRenderedImage", null, null, 'java.awt.image.RenderedImage');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-11-22 22:09:48 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
