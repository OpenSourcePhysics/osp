(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "WritableRenderedImage", null, null, 'java.awt.image.RenderedImage');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-08-25 10:01:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
