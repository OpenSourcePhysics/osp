(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "WritableRenderedImage", null, null, 'java.awt.image.RenderedImage');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-07-19 08:46:56 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
