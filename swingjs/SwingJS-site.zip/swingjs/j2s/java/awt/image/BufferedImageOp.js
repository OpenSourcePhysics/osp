(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "BufferedImageOp");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-11-22 22:09:46 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
