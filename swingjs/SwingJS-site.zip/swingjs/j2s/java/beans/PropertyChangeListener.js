(function(){var P$=Clazz.newPackage("java.beans"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "PropertyChangeListener", null, null, 'java.util.EventListener');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-09-11 08:13:00 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
