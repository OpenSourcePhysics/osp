(function(){var P$=Clazz.newPackage("java.beans"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "PropertyEditor");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-20 12:13:18 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
