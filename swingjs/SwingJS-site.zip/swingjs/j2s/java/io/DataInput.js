(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DataInput");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-08-25 10:01:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
