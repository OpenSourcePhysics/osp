(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DataInput");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-07-13 18:27:27 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
