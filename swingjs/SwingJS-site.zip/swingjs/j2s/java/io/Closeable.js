(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Closeable", null, null, 'AutoCloseable');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-09-11 08:13:01 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
