(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "FileFilter");
})();
;Clazz.setTVer('3.3.1-v4');//Created 2022-01-25 06:29:30 Java2ScriptVisitor version 3.3.1-v4 net.sf.j2s.core.jar version 3.3.1-v4
