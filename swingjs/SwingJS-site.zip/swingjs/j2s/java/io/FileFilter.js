(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "FileFilter");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-11-13 20:33:28 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
